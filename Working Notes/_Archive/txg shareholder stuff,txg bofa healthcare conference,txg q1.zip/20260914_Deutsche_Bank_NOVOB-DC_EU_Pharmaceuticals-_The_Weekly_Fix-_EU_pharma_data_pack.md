This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. Deutsche Bank Research 

Europe Industry Date 7 September 2026 Pharmaceuticals EU Pharmaceuticals Pharmaceuticals Periodical 

### The Weekly Fix: EU pharma data pack 

###### Summary 

**Our weekly EU pharma data pack incorporates a set of updated** rolling valuation and price performance charts/tables alongside a set of Symphony-based prescription tracker charts intended to complement our IQVIA and Rx company trackers published (mostly) on Mondays, plus ancillary information such as catalyst calendars and a rolling list of DB Pharma research links published within the past week. 

###### **Key events next week include:** 

Emmanuel Papadakis, Ph.D., CFA Research Analyst +44-20-754-18522 Niall Alexander Research Analyst +44-20-754-12185 Henrietta Boeg Research Associate +44-20-754-10119 Kate Farrelly Research Associate 

###### Company events 

- n **SDZ Capital Markets Day** : 8<sup>th</sup> Sep @ 13:30-17:00 UK - <u>REGISTER</u> 

- n **AZN Meet the Management at ERS:** 8<sup>th</sup> Sep @ 16:00 UK - <u>REGISTER</u> 

###### Conference events 

- n **European Respiratory Society (ERS):** 5<sup>th</sup> - 9<sup>th</sup> Sep - Barcelona, Spain - <u>LINK</u> 

Shashindra Seresinhe Research Associate Supun Ukwatta Research Associate 

- n **World Conference on Lung Cancer (WCLC):** 12<sup>th</sup> - 15<sup>th</sup> Sep - Seoul, Korea - <u>LINK</u> 

###### Deutsche Bank AG 

IMPORTANT RESEARCH DISCLOSURES AND ANALYST CERTIFICATIONS LOCATED IN APPENDIX 1. Deutsche Bank does and seeks to do business with companies covered in its research reports. Thus, investors should be aware that the firm may have a conflict of interest that could affect the objectivity of this report. Investors should consider this report as only a single factor in making their investment decision. 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

|Table Of Contents|
|---|
|DB Pharma research published in the past week...............3|
|European pharmaceutical valuation summary...................4|
|Global pharmaceutical valuation comparisons...................5|
|Sector price performance summary...................................6|
|Quarterly BEAT/MISS table.................................................7|
|Share price performance (absolute/relative).......................9|
|Company share price performance....................................................................9|
|Index share price performance........................................................................16|
|Index P/E vs. Dividend yield.............................................................................17|
|Relative valuation performance........................................19|
|P/E performance - sector.................................................................................19|
|P/E performance - individual stocks.................................................................21|
|Price vs. EPS - individual stocks......................................................................27|
|P/E - Individual stocks......................................................................................31|
|EV/EBITDA performance - individual stocks....................................................34|
|US gov bond performance...............................................................................37|
|US prescription drug trends (updated weekly).................38|
|Diabetes...........................................................................................................38|
|Heart disease...................................................................................................43|
|Respiratory......................................................................................................46|
|Eye disease......................................................................................................49|
|HIV...................................................................................................................49|
|Immunology....................................................................................................53|
|Rheumatoid arthritis........................................................................................55|
|Vaccination......................................................................................................56|
|Migraine..........................................................................................................56|
|Injectable biosimilars.......................................................................................57|
|Insulin biosimilars............................................................................................58|
|Humira biosimilars...........................................................................................58|
|Remicade biosimilars.......................................................................................59|
|EU Large cap patent expiry..............................................60|
|Company catalyst calendars............................................62|
|Large Cap companies......................................................................................62|
|Mid-Cap Companies........................................................................................68|



Page 2 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

## DB Pharma research published in the past week 

- n _<u>AZN : Weekly retail rx tracker (01/09/26)</u>_ 

- n _<u>NOVN: REMODELling expectations indeed? Remi headline + YTB takes (+RO) (01/09/26)</u>_ 

- n _<u>NOVN: Weekly retail Rx tracker</u> (01/09/26)_ 

- n _<u>GSK: Weekly retail rx tracker</u> (01/09/26)_ 

- n _<u>NOVO: Weekly retail rx tracker</u> (01/09/26)_ 

- n _<u>SAN: Weekly retail rx tracker</u> (01/09/26)_ 

- n <u>SOBI: Closer inspection of Mount Shasta view: brief ESC x-reads(01/09/26)</u> 

- n _<u>Weekly EU Pharma US Biosimilars Tracker (IQVIA)</u> (01/09/26)_ 

- n _<u>EU Pharma: Weekly SMID Tracker</u> (01/09/26)_ 

- n _<u>Weekly EU Pharma US hospital/Roche tracker (IQVIA)</u> (01/09/26)_ 

- n _<u>EU Pharma Weekly Vaccine tracker (01/09/26)</u>_ 

- n _<u>GSK: Flu mRNA takes/x-reads: no chicken relief just yet (MRNA/SAN/BNTX)</u> (03/09/26)_ 

Deutsche Bank AG 

Page 3 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 

## European pharmaceutical valuation summary 

###### Figure 1: European pharmaceutical Valuation Summary 

||||||||||||||||**Cons Cor**|**e P/**|**E**|**DB Ad**|**j. P/**|**E**|||**DB IFRS P**|**E**|**EV/**|**EBI**|**TDA**|**EV/**|**Sale**|**s**<br>**EV/FCF**<br>**Dividend yield**|**FCF yld**||**DB EPS CAGR**<br>**Cons EPS**<br>**CAGR**|**DB Sa**<br>**CAG**|**les**<br>**R**|**Cons Sal**<br>**CAGR**|**3**<br>**PE**<br>**es**|**yr**<br>**G**<br>**Net Debt /**<br>**EBITDA**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||<br>**P**|**T**|||<br>|||||||||||||||||||||||||**FW**|**D**|
|**Stock**|**Ticker**|**Cty**|**FX**<br>**Rating**|**Closing**<br>**price**<br>**T**<br>|**arg**<br>**pric**|**et**<br>**e**<br>**Up**<br>**dow**<br>**(%)**|**side**<br>**nsi**<br>**to P**|**/**<br>**de**<br>**T**<br>**imp**<br>**2026**<br>**(**|**N**<br>**lied**<br>**P/E**<br>**x)**|**PV/ sh**|**NPV U**<br>**down**<br>**side**|**p/**<br>**-**<br>**N**<br>**imp**<br>**'26**|**PV**<br>**lied**<br>**P/E**|<br>**Mc**<br>**(US**|**2026E**<br>**2**<br>**ap**<br>**$bn)**|**027**|**E**<br>|**2026E**|**202**|**7E**|**prem**<br>**disc to**<br>**P/E**|**/**<br>**'26**<br>|**2026E**<br>**202**|**7E**<br>**2**|**026E**||**2027E**|**2026E**|**20**|**27E**<br>**2026E**<br>**2027E**<br>**2026E**<br>**2027E**<br>|**2026E**<br>**20**|**26E**|**25-'27E**<br>**25-**<br>**'29E**<br>**25-**<br>**'27E**<br>**25-**<br>**'29E**|**25-**<br>**'27E**|**25-**<br>**'29E**|**25-**<br>**'27E**<br>**2**<br>**'2**|**5-**<br>**9E**|**2026E**<br>**2027E**|
|**EU major Pharma**|||||||||||||||||||||||||||||||||||||||
|**AstraZeneca**|AZN.L<br>UK||US$ **Sell**|12,146|11,5|00|-5|%|14.9|14,193|1|7%|18.|4|255<br>16.0|14|.4|15.8||14.8||1%|20.8<br>|18.1|12|.3|11.2|4.4||4.1<br>20.2<br>16.8<br>2.0%<br>2.1%|5.3%|6.2|%<br>10%<br>9%<br>12%<br>8%|5%|4|%<br>7%|7%|1.8<br>0.9<br>0.4|
|**GlaxoSmithKline**|GSK.L<br>UK||GBP **Hold**|1,867|2,0|00|7|%|10.8|2,110|1|3%|11.|4|101<br>10.5|9|.9|10.1||9.6|-3|6%|17.1<br>|10.7|8|.1|7.7|2.7||2.6<br>11.3<br>11.7<br>3.8%<br>4.0%|10.8%<br>1|0.1|%<br>6%<br>8%<br>5%<br>4%|4%|4|%<br>4%|3%|1.7<br>1.7<br>1.4|
|**Novartis**|NOVN.S<br>SWI||US$ **Buy**|131|1|40|7|%|20.0|129|-|2%|18.|4|310<br>18.4|16|.6|18.7||16.9|2|0%|22.1<br>|19.6|15|.0|14.0|6.1||5.8<br>19.5<br>18.8<br>2.2%<br>2.5%|5.6%|5.7|%<br>4%<br>7%<br>4%<br>5%|4%|5|%<br>5%|6%|4.4<br>1.4<br>1.1|
|**Novo Nordisk**|NOVOb.CO<br>DEN||DKK **Sell**|302|2|65|-12|%|11.2|535|7|7%|22.|7|209<br>13.8|13|.8|12.8||12.8|-1|8%|10.8<br>|12.8|9|.6|9.4|4.4||4.7<br>26.4<br>17.9<br>4.0%<br>4.2%|4.1%|6.0|%<br>-5%<br>0%<br>-3%<br>0%|0%|2|%<br>0%|3%<br>|-2.2<br>0.8<br>0.7|
|**Roche**|RO.S<br>SWI||CHF<br>**Hold**|367|3|40|-7|%|16.7|346|-|6%|17.|0|364<br>17.5|16|.4|18.0||16.7|1|5%|20.3<br>|17.0|12|.1|11.1|5.0||4.6<br>17.3<br>16.2<br>2.7%<br>2.8%|6.2%|6.4|%<br>6%<br>8%<br>5%<br>5%|3%|4|%<br>3%|4%|3.0<br>0.7<br>0.3|
|**Sanofi**|SASY.PA<br>FRA||EUR **Buy**|76||95|25|%|11.0|116|5|2%|13.|4|105<br>8.9|8|.4|8.8||8.3|-4|4%|13.6|9.7|6|.8|6.1|2.1||1.9<br>11.3<br>9.9<br>5.7%<br>5.9%|9.5%<br>1|0.4|%<br>9%<br>11%<br>8%<br>6%|9%|7|%<br>8%|6%|1.1<br>0.7<br>0.4|
|**Group average**|||||||||**14.1**||||**16.**|**9**|**14.2**|**13**|**.2**|**14.0**||**13.2**|**-1**|**0%**|**17.5**<br>|**14.7**|**10**|**.7**|**9.9**|**4.1**||**3.9**<br>**17.7**<br>**15.2**<br>**3.4%**<br>**3.6%**|**7%**|**7**|**%**<br>**5%**<br>**7%**<br>**5%**<br>**5%**|**4%**|**4**|**%**<br>**5%**|**5%**|**1.6**<br>**1.0**<br>**0.7**|
|**SXDP (STOXX Healthcare)**|||||||||||||||**15.5**|**15**|**.5**|||||||||||||**2.6%**<br>**2.6%**|||||||||
|**SXXP (STOXX 600)**|||||||||||||||**14.4**|**14**|**.4**|||||||||||||**3.4%**<br>**3.4%**|||||||||
|**EU smid-cap Pharma/Biotec**|**h**||||||||||||||||||||||||||||||||||||||
|**Almirall**|ALM.MC<br>BEL||EUR **Hold**|10||13|25|%|28.6|14|3|5%|30.|8|2.6<br>27.2|20|.0|22.9||17.6||1%|25.5<br>|17.6|8|.2|6.8|1.9||1.7<br>13.5<br>10.7<br>2.0%<br>2.1%|7.6%|9.3|%<br>55%<br>41%<br>55%<br>33%|10%|10|%<br>10%|9%|0.8<br>0.2<br>0.0|
|**Argenx**|ARGX.BR<br>BEL||USD **Hold**|912|9|25|1|%|0.4|934||2%|33.|4|70.0<br>40.9|n|a|37.9||26.8|6|8%|37.9<br>|26.8|32|.2|21.6|10.8||8.0<br>32.8<br>22.6<br>0.0%<br>0.0%|2.9%|4.0|%<br>47%<br>28%|||35%<br>2|6%|1.2<br>-2.0<br>-2.3|
|**Lakefront**|LKFT.AS<br>NED||EUR **Sell**|25||19|-24|%|-3.4|19|-2|4%|||1.9|||na||na|||||-3|.7|-5.9|53.6||57.9<br>-6.8<br>-6.0<br>0.0%<br>0.0%|-13.7%<br>-1|6.7|%<br>-24%<br>-11%|-84%|-51|%<br>-34%<br>-4|0%|0.0<br>0.0<br>0.0|
|**Galderma**|GALD.S<br>SWI||US$ **Buy**|163|1|95|20|%|40.7|190|1|7%|39.|7|48.0<br>42.0|30|.9|42.1||31.3|8|6%|53.7<br>|39.2|29|.7|23.0|7.6||6.4<br>41.0<br>31.4<br>0.2%<br>0.3%|2.5%|3.2|%<br>32%<br>27%<br>44%<br>28%|19%|16|%<br>20%<br>1|7%|1.6<br>0.6<br>-0.1|
|**Genmab**|GMAB.CO<br>DEN||DKK **Buy**|2,197|2,5|00|14|%|0.3|2,423|1|0%|181.|7|21.3<br>27.7|19|.8|25.6||14.1|1|3%|25.6<br>|14.1|93|.5|63.7|31.7||26.4<br>122.0<br>72.2<br>0.0%<br>0.0%|5.3%|8.9|%<br>26%<br>12%<br>0%<br>10%|18%|11|%<br>19%<br>1|5%|0.8<br>1.7<br>0.4|
|**Grifols**|GRLS.MC<br>ESP||EUR **Hold**|10||10|1|%|12.4|14|4|5%|17.|9|7.8<br>11.7|8|.9|12.3||9.5|-4|5%|12.6|9.8|7|.9|7.0|2.0||1.8<br>25.1<br>26.9<br>0.0%<br>0.0%|8.9%|8.1|%<br>20%<br>18%<br>23%<br>19%|4%|5|%<br>4%|5%|0.7<br>4.4<br>3.8|
|**Idorsia**|IDIA.S<br>SWI||CHF<br>**Hold**|5||5.5|6|%||5|-1|3%|||1.3|||||||||na|-29|.0|132.2|8.9||6.9<br>-32.6<br>-112.0<br>0.0%<br>0.0%|-6.2%<br>|-1.8|%<br>-13%<br>-34%|||18%<br>1|9%|-14.6<br>66.3|
|**Ipsen**|IPN.PA<br>FRA||EUR **Buy**|169|1|83|9|%|12.2|224|3|3%|15.|0|16.4<br>11.8|12|.2|11.3||11.2|-5|0%|14.6<br>|13.6|5|.5|5.0|2.8||2.5<br>8.1<br>7.0<br>0.0%<br>0.0%|11.4%<br>1|2.0|%<br>12%<br>9%<br>9%<br>4%|10%|7|%<br>10%|6%|1.2<br>-0.5<br>-0.9|
|**Lundbeck**|HLUNb.CO<br>DEN||DKK **Hold**|44||40|-10|%|6.5|64|4|3%|10.|4|6.9<br>8.2|8|.2|7.2||7.0|-6|8%|8.9|9.0|5|.4|5.0|1.7||1.5<br>8.6<br>7.5<br>3.3%<br>2.9%|11.5%<br>1|1.9|%<br>9%<br>0%<br>1%<br>-1%|3%|-2|%<br>3%<br>-|1%|0.9<br>-0.1<br>-0.5|
|**Sandoz**|SDZ.S<br>US||US$ **Hold**|70||65|-8|%|16.3|70|-|1%|17.|5|37.6<br>21.3|18|.9|21.8||19.3|3|9%|24.9<br>|22.5|12|.2|10.6|2.8||2.6<br>36.4<br>18.0<br>0.7%<br>0.8%|2.4%|4.8|%<br>17%<br>11%|7%|6|%<br>7%|6%|2.0<br>1.2<br>0.6|
|**SOBI**|SOBIV.ST<br>SW|E|SEK<br>**Buy**|460|5|15|12|%|29.1|512|1|1%|28.|9|17.5<br>23.8|20|.5|26.0||22.4|1|5%|26.0<br>|22.4|14|.6|12.5|5.4||4.8<br>19.4<br>16.1<br>0.0%<br>0.0%|5.5%|6.3|%<br>11%<br>13%<br>13%<br>11%|12%|11|%<br>14%<br>1|3%|2.6<br>0.8<br>0.1|
|**UCB**|UCB.BR<br>BEL||EUR **Buy**|221|2|95|34|%|25.3|295|3|4%|25.|3|48.8<br>18.7|16|.1|18.9||16.8|-1|6%|23.0<br>|20.3|13|.9|11.8|4.7||4.1<br>15.1<br>14.2<br>0.6%<br>0.7%|6.6%|6.6|%<br>15%<br>13%<br>29%<br>18%|12%|10|%<br>12%<br>1|1%|1.5<br>0.0<br>-0.7|
|**Zealand**|ZELA.CO<br>BEL||DKK **Hold**|311|3|00|-3|%|9.4|759|||||3.5|||9.7||8.4|-5|7%|||||||||||||||||
|**EU smid-cap Pharma averag**|**e***||||||||**16.5**||||||**22.7**|**17**|**.0**|**21.4**||**16.8**|**3**|**7%**|**25.0**<br>|**19.5**|**22**|**.3**|**27.2**|**11.2**||**10.4**<br>**32.2**<br>**22.7**<br>**1%**<br>**1%**|**6%**|**8**|**%**<br>**22%**<br>**19%**<br>**16%**<br>**10%**|**2%**|**3**|**%**<br>**10%**|**7%**|**1.4**<br>**1.5**<br>**12.1**|
|**US Coverage**<br>**Alvotech**|ALVO.OQ<br>US||US$ **Hold**|5||4|-26|%<br>|447.4|4|-2|1%|474.|2|1.2|24|.3|na||18.3||na|12.0|6.9|10|.6|6.9|3.4||2.3<br>13.9<br>12.2<br>0.0%<br>0.0%|13.2%<br>1|4.2|%|25%|19|%<br>14%<br>1|7%|4.8<br>2.9|
|**BioNTech**|BNTX.OQ<br>US||US$ **Buy**|103|1|40|36|%|-23.6|140|3|6%|-23.|6|24.1|||||||||na|-14|.6|-16.8|11.0||11.5<br>-13.2<br>-14.1<br>0.0%<br>0.0%|-7.1%<br>|-7.2|%<br>12%<br>30%<br>7%|-19%|-17|%<br>-17%<br>-|7%|3.2<br>2.0|
|**Moderna**|MRNA.OQ<br>US||US$ **Hold**|149|1|25|-16|%|-15.2|45|-7|0%|-5.|5|57.9|||||||0%|0.0|0.0|-17|.4|-25.9|26.5||21.0<br>-16.0<br>-20.1<br>0.0%<br>0.0%|-6.0%<br>|-4.8|%<br>-10%<br>-26%<br>-23%<br>-22%|18%|21|%<br>13%<br>2|2%|0.6<br>0.7|
|**US coverage average***|||||||||**447.4**||||||||||||||**12.0**|**6.9**|**10**|**.6**|**6.9**|**13.6**||**11.6**<br>**13.9**<br>**12.2**|**13.2%**<br>**1**|**4.2**|**%**<br>**0.1**<br>**0.3**<br>**0.1**|**8%**|**8**|**%**<br>**3%**<br>**1**|**1%**|**2.9**<br>**1.9**|



_Source : Deutsche Bank, Bloomberg Finance LP, Prices as of 04/09/2026_ 



This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 

## Global pharmaceutical valuation comparisons 

###### Figure 2: Global pharmaceuticals summary valuation 

|**Stock**<br>**EU major Pharma**<br>**EU major Pharma (ex-Novo)**|**Ticker**|**Cty**<br>**FX**<br>**% Free**<br>**float**<br>**Rating**<br>|**Price**<br>**T**|**arge**|**t pric**|**e**<br>**(lc; bn)**<br>**(US**<br>**Mc**|**$bn)**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**20**<br>**1,400**<br>**15.9**<br>**15.5**<br>**14.4**<br>**13.2**<br>**12.**<br>**1,191**<br>**16.4**<br>**15.7**<br>**14.5**<br>**13.2**<br>**12.**<br>**Cons Core P/E**<br>**ap**|**29**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**202**<br>**1**<br>**15.7**<br>**15.4**<br>**14.4**<br>**13.1**<br>**12.1**<br>**2**<br>**16.4**<br>**15.9**<br>**14.7**<br>**13.3**<br>**12.2**<br>**DB Adj. P/E**|**P/E**<br>**prem/**<br>**disc**<br>**P/E**<br>**prem/**<br>**disc**<br>**9**<br>**2025**<br>**2026**<br>**#REF!**<br>**2026**<br>**2027**<br>**2028**<br>**2029**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**2029**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**2**<br><br>**12.1**<br>**11.6**<br>**10.7**<br>**9.8**<br>**9.1**<br>**4.7**<br>**4.5**<br>**4.3**<br>**4.0**<br><br><br>**12.6**<br>**11.9**<br>**10.9**<br>**9.9**<br>**9.3**<br>**4.7**<br>**4.5**<br>**4.2**<br>**3.9**<br>**EV/EBITDA**<br>**DB IFRS PE**<br>**EV/Sales**|**029**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**2029**<br>**3.8**<br>**20.9**<br>**16.6**<br>**17.0**<br>**14.9**<br>**13.6**<br>**3.7**<br>**20.4**<br>**14.9**<br>**16.9**<br>**14.9**<br>**13.7**<br>**EV/FCF**|**2025**<br>**2026**<br>**2027**<br>**2028**<br>**2029**<br>**2025**<br>**2026**<br>**2027**<br>**2028**<br>**20**<br>**2.8%**<br>**2.9%**<br>**3.1%**<br>**3.3%**<br>**3.6%**<br>**5.7%**<br>**5.7%**<br>**6.6%**<br>**7.4%**<br>**8.0**<br>**2.6%**<br>**2.7%**<br>**2.9%**<br>**3.1%**<br>**3.4%**<br>**5.9%**<br>**6.0%**<br>**6.8%**<br>**7.4%**<br>**8.0**<br>**Dividend yield**<br>**FCFyield**|**29**<br>**25-27E**<br>**25-29E**<br>**%**<br>**4.7%**<br>**7.0%**<br>**%**<br>**6.5%**<br>**8.2%**<br>**DB EPS CAGR**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|AstraZeneca|AZN.L|UK<br>US$ 97%<br>**Sell**|12,146|**1**|**1,50**|**0**<br>188|255<br>17.9<br>16.0<br>14.4<br>13.0<br>11|.5<br>17.5<br>15.8<br>14.8<br>13.8<br>12.|9<br>5%<br>1%<br>24.3<br>20.8<br>18.1<br>16.5<br>15.1<br>14.4<br>12.3<br>11.2<br>10.1<br>9.4<br>4.7<br>4.4<br>4.1<br>3.8|3.6<br>21.3<br>20.2<br>16.8<br>14.8<br>13.6|2.0%<br>2.0%<br>2.1%<br>2.2%<br>2.4%<br>5.3%<br>5.3%<br>6.2%<br>6.8%<br>7.2|%<br>10%<br>9%|
|Bayer|BAYGn.DE|GER EUR<br>97%<br>**Buy**|49||**6**|**0**<br>48|56<br>10.4<br>10.9<br>10.4<br>9.3<br>8|.6<br>10.1<br>10.8<br>9.9<br>8.8<br>7.|6<br>-40%<br>-31%<br>-13.4<br>27.5<br>21.2<br>16.9<br>13.2<br>8.1<br>8.0<br>7.2<br>6.5<br>5.7<br>1.7<br>1.7<br>1.6<br>1.5|1.4<br>47.3<br>-35.6<br>33.2<br>25.8<br>19.3|0.2%<br>0.2%<br>1.0%<br>2.0%<br>3.0%<br>3.4%<br>-4.5%<br>4.7%<br>5.9%<br>7.6|%<br>1%<br>7%|
|GSK<br>|GSK.L<br>|UK<br>GBP<br>100%<br>**Hold**<br><br><br><br>|1,867<br>||**2,00**<br>|**0**<br>75<br>|101<br>11.0<br>10.5<br>9.9<br>9.4<br>8|.7<br>10.8<br>10.1<br>9.6<br>8.9<br>7.|9<br>-35%<br>-36%<br>13.2<br>17.1<br>10.7<br>9.8<br>8.8<br>8.4<br>8.1<br>7.7<br>7.2<br>7.0<br>2.7<br>2.7<br>2.6<br>2.4<br><br><br><br><br><br><br>|2.4<br>13.9<br>11.3<br>11.7<br>10.2<br>9.6|3.5%<br>3.8%<br>4.0%<br>4.2%<br>4.5%<br>8.3%<br>10.8%<br>10.1%<br>11.3%<br>12.0<br><br><br><br><br><br><br><br><br><br>|%<br>6%<br>8%<br><br><br>|
|Novartis<br>Novo Nordisk|NOVN.S<br>NOVOb.CO|SWI<br>US$ 93%<br>**Buy**<br>DEN DKK<br>99%<br>**Sell**|131<br>302||**14**<br>**26**|250<br>**5**<br>1,341|310<br>18.1<br>18.4<br>16.6<br>15.0<br>13<br>209<br>13.0<br>13.8<br>13.8<br>12.7<br>11|.9<br>17.8<br>18.7<br>16.9<br>14.9<br>13.<br>.6<br>11.5<br>12.8<br>12.8<br>12.2<br>11.|7<br>7%<br>20%<br>22.1<br>22.1<br>19.6<br>17.2<br>15.8<br>14.4<br>15.0<br>14.0<br>12.5<br>11.7<br>6.1<br>6.1<br>5.8<br>5.2<br>5<br>-31%<br>-18%<br>13.1<br>10.8<br>12.8<br>12.2<br>11.5<br>9.2<br>9.6<br>9.4<br>8.9<br>8.4<br>4.7<br>4.4<br>4.7<br>4.5|4.9<br>18.3<br>19.5<br>18.8<br>16.7<br>15.8<br>4.2<br>23.7<br>26.4<br>17.9<br>14.9<br>12.7|2.3%<br>2.2%<br>2.5%<br>2.9%<br>3.1%<br>6.0%<br>5.6%<br>5.7%<br>6.3%<br>6.5<br>3.9%<br>4.0%<br>4.2%<br>4.4%<br>4.6%<br>4.6%<br>4.1%<br>6.0%<br>7.2%<br>8.3|%<br>4%<br>7%<br>%<br>-5%<br>0%|
|Roche<br>|RO.S<br>|SWI<br>CHF<br>100%<br>**Hold**<br><br><br><br>|367<br>76||**34**<br>**9**|**0**<br>294<br><br>|364<br>18.1<br>17.5<br>16.4<br>15.2<br>14<br><br><br><br><br><br>|.2<br>18.9<br>18.0<br>16.7<br>15.2<br>13.<br><br><br><br><br><br>|8<br>13%<br>15%<br>22.9<br>20.3<br>17.0<br>15.5<br>14.1<br>13.0<br>12.1<br>11.1<br>10.1<br>9.6<br>5.2<br>5.0<br>4.6<br>4.3<br><br>-41%<br>-44%<br>120<br>136<br>97<br>85<br>76<br><br><br><br><br><br><br><br><br>|4.2<br>21.2<br>17.3<br>16.2<br>14.9<br>14.1<br><br><br><br><br><br>|2.7%<br>2.7%<br>2.8%<br>3.0%<br>3.1%<br>5.2%<br>6.2%<br>6.4%<br>6.8%<br>7.2<br><br><br><br><br><br><br><br><br><br>|%<br>6%<br>8%<br><br><br>|
|Sanofi<br>|SASY.PA|FRA<br>EUR<br>89%<br>**Buy**||||90|105<br>9.8<br>8.9<br>8.4<br>7.8<br><br><br><br><br><br><br>|.2<br>9.8<br>8.8<br>8.3<br>7.3<br>6.<br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>7.6<br>6.8<br>6.1<br>5.4<br>4.9<br>2.4<br>2.1<br>1.9<br>1.7<br><br><br><br><br><br><br><br><br><br>|1.6<br>13.0<br>11.3<br>9.9<br>8.5<br>7.5<br><br><br><br><br><br>|5.4%<br>5.7%<br>5.9%<br>6.3%<br>6.7%<br>8.5%<br>9.5%<br>10.4%<br>11.8%<br>12.9<br><br><br><br><br><br><br><br><br><br>|9%<br>11%<br><br><br>|
|**EU smid-cap Pharma**<br>Almirall|ALM.MC|BEL<br>EUR<br>35%<br>**Hold**|10||**1**|**3**<br>2|**269**<br>**23.2**<br>**22.1**<br>**18.5**<br>**15.0**<br>**22**<br>3<br>47.7<br>27.2<br>20.0<br>15.0<br>11|**.6**<br>**22.6**<br>**24.5**<br>**15.8**<br>**15.5**<br>**12.**<br>.4<br>42.3<br>22.9<br>17.6<br>12.8<br>10.|**7**<br>**-11.5**<br>**17.8**<br>**29.7**<br>**18.4**<br>**11.6**<br>**8.2**<br>**10.2**<br>**9.6**<br>**7.1**<br>8<br>11%<br>1%<br>48.2<br>25.5<br>17.6<br>12.8<br>10.8<br>9.4<br>8.2<br>6.8<br>5.6<br>4.6<br>2.0<br>1.9<br>1.7<br>1.4|**5.9**<br>**8.6**<br>**24.5**<br>**15.2**<br>**27.1**<br>**16.3**<br>1.2<br>15.7<br>13.5<br>10.7<br>8.8<br>7.2|**0.7%**<br>**0.8%**<br>**0.8%**<br>**0.8%**<br>**0.6%**<br>**-1.5%**<br>**1.0%**<br>**4.3%**<br>**6.0%**<br>**7.1**<br>1.9%<br>2.0%<br>2.1%<br>2.2%<br>2.3%<br>6.2%<br>7.6%<br>9.3%<br>10.8%<br>12.4|**%**<br>**11.3%**<br>**17.7%**<br>%<br>55%<br>41%|
|Argenx|ARGX.BR|BEL<br>USD<br>99%<br>**Hold**|912||**92**|**5**<br>60|70<br>58.9<br>40.9<br>na<br>na<br>|na<br>52.6<br>37.9<br>26.8<br>20.0<br>16.|8<br>38%<br>68%<br>52.6<br>37.9<br>26.8<br>20.0<br>16.8<br>60.6<br>32.2<br>21.6<br>15.4<br>12.1<br>15.8<br>10.8<br>8.0<br>6.2|5.0<br>114.4<br>32.8<br>22.6<br>16.8<br>12.2|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.8%<br>2.9%<br>4.0%<br>5.1%<br>6.4|%<br>42%<br>34%|
|Evotec<br>Lakefront|EVTG.DE<br>LKFT.AS|GER EUR<br>87%<br>**Hold**<br>NED EUR<br>57%<br>**Sell**|3<br>25||**1**|**4**<br>1<br>**9**<br>2|1<br>47<br>2|.4<br>na<br>na<br>na<br>27.2<br>8.<br>5.2<br>na<br>na<br>na<br>n|6<br>na<br>na<br>na<br>27.2<br>8.6<br>12.0<br>-8.4<br>17.4<br>6.5<br>3.4<br>0.6<br>1.3<br>1.1<br>1.0<br>a<br>-86%<br>5.2<br>4.6<br>-3.7<br>-5.9<br>-6.0<br>-5.9<br>1.4<br>53.6<br>57.9<br>32.8<br>2|0.7<br>-5.3<br>-3.0<br>-36.6<br>23.8<br>8.7<br>3.2<br>-5.8<br>-6.8<br>-6.0<br>-6.1<br>-6.1|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-16.0%<br>-43.4%<br>-3.6%<br>5.3%<br>12.0<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-16.7%<br>-13.7%<br>-16.7%<br>-15.5%<br>-15.0|%<br>-47%<br>%|
|Galderma<br>Genmab<br>Grifols<br>Hikma<br>Hutchison China MediTech|GALD.S<br>GMAB.CO<br>GRLS.MC<br>HIK.L<br>HCM.OQ|SWI<br>US$ 79%<br>**Buy**<br>DEN DKK<br>95%<br>**Buy**<br>ESP<br>EUR<br>66%<br>**Hold**<br>UK<br>GBP<br>54%<br>**Buy**<br>CHN US$ **Buy**|163<br>2,197<br>10<br>1,605<br>14||**19**<br>**2,50**<br>**1**<br>**2,05**<br>**2**|**5**<br>39<br>**0**<br>137<br>**0**<br>7<br>**0**<br>3<br>**1**<br>12|48<br>64.6<br>42.0<br>30.9<br>24.4<br>19<br>21<br>19.6<br>27.7<br>19.8<br>13.5<br>14<br>8<br>13.5<br>11.7<br>8.9<br>6.6<br>6<br>5<br>9.6<br>9.5<br>8.8<br>8.1<br>7<br>12<br>7.1<br>57.4<br>49.0<br>41.4<br>17|.4<br>53.4<br>42.1<br>31.3<br>25.3<br>21.<br>.1<br>21.6<br>25.6<br>14.1<br>11.0<br>14.<br>.2<br>13.6<br>12.3<br>9.5<br>8.0<br>6.<br>.4<br>9.4<br>9.4<br>8.8<br>8.3<br>.4<br>26.5<br>79.3<br>na<br>na|0<br>41%<br>86%<br>75.9<br>53.7<br>39.2<br>30.5<br>24.6<br>41.3<br>29.7<br>23.0<br>18.3<br>14.8<br>9.5<br>7.6<br>6.4<br>5.4<br>2<br>-43%<br>13%<br>21.6<br>25.6<br>14.1<br>11.0<br>14.2<br>123.4<br>93.5<br>63.7<br>50.2<br>63.7<br>37.7<br>31.7<br>26.4<br>22.6<br>2<br>9<br>-64%<br>-45%<br>16.8<br>12.6<br>9.8<br>8.4<br>7.3<br>8.4<br>7.9<br>7.0<br>6.2<br>5.5<br>2.1<br>2.0<br>1.8<br>1.6<br>-75%<br>-59%<br>11.7<br>10.9<br>10.0<br>9.3<br>5.6<br>5.6<br>5.2<br>4.7<br>na<br>1.4<br>1.4<br>1.3<br>1.2<br>-30%<br>251%<br>26.5<br>79.3<br>na<br>na<br>-469.3<br>81.1<br>130.9<br>106.9<br>na<br>22.1<br>16.5<br>16.0<br>14.6|4.6<br>42.9<br>41.0<br>31.4<br>25.1<br>20.2<br>3.6<br>-23.1<br>122.0<br>72.2<br>55.1<br>61.2<br>1.5<br>19.9<br>25.1<br>26.9<br>19.8<br>16.9<br>na<br>40.5<br>12.0<br>9.9<br>8.8<br>na<br>na -154.0<br>93.7<br>144.9<br>111.0<br>na|0.2%<br>0.2%<br>0.3%<br>0.4%<br>0.4%<br>2.5%<br>2.5%<br>3.2%<br>3.9%<br>4.6<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-29.2%<br>5.3%<br>8.9%<br>11.5%<br>10.2<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>11.6%<br>8.9%<br>8.1%<br>10.6%<br>11.9<br>3.3%<br>3.9%<br>4.2%<br>4.4%<br>2.5%<br>8.5%<br>9.9%<br>10.7%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>na<br>-0.7%<br>1.1%<br>0.7%<br>0.9%<br>n|%<br>32%<br>27%<br>%<br>26%<br>12%<br>%<br>20%<br>18%<br>5%<br>a<br>-52%|
|Idorsia A shares|IDIA.S|SWI<br>CHF<br>75%<br>**Hold**|5|||**6**<br>1|1<br>139|.7<br>na<br>na<br>na<br>na<br>n|a<br>na<br>na<br>na<br>-26.3<br>-29.0<br>132.2<br>29.0<br>18.7<br>9.9<br>8.9<br>6.9<br>5.5|4.5<br>-13.7<br>-32.6 -112.0<br>87.2<br>41.9|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-14.6%<br>-6.2%<br>-1.8%<br>2.2%<br>4.4|%<br>4%|
|Indivior PLC|INDVL|99%<br>**NR**|35|||0|0<br>143<br>82<br>75<br>69<br>6|4<br>na<br>na<br>na<br>na<br>n|a<br>na<br>na<br>na<br>na<br>na|na||38%<br>22%|
|<br>Ipsen|.<br>IPN.PA|FRA<br>EUR<br>59%<br>**Buy**|169||**18**|**3**<br>14|.<br>.<br>.<br>.<br><br>16<br>14.4<br>11.8<br>12.2<br>12.2<br>11|.<br><br><br><br><br><br>.8<br>13.9<br>11.3<br>11.2<br>10.3<br>9.|9<br>-63%<br>-50%<br>31.6<br>14.6<br>13.6<br>12.7<br>12.2<br>9.8<br>5.5<br>5.0<br>4.2<br>3.6<br>3.4<br>2.8<br>2.5<br>2.1|1.8<br>13.1<br>8.1<br>7.0<br>5.9<br>5.1|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>7.3%<br>11.4%<br>12.0%<br>12.8%<br>13.3|%<br>12%<br>9%|
|Lundbeck<br>Merck KGaA<br>SOBI<br>|HLUNb.CO<br>MRCG.DE<br>SOBIV.ST<br>|DEN DKK<br>34%<br>**Hold**<br>GER EUR<br>100%<br>**Hold**<br>SWE SEK<br>62%<br>**Buy**<br><br><br><br>|44<br>138<br>460<br>||**4**<br>**14**<br>**51**<br>|**0**<br>44<br>**1**<br>60<br>**5**<br>167<br><br>|7<br>8.4<br>8.2<br>8.2<br>8.6<br>8<br>70<br>16.5<br>16.6<br>15.6<br>14.2<br>12<br>18<br>25.9<br>23.8<br>20.5<br>17.3<br>14<br><br><br><br><br><br>|.3<br>8.4<br>7.2<br>7.0<br>7.8<br>8.<br>.7<br>16.5<br>16.4<br>15.9<br>15.2<br>14.<br>.5<br>27.4<br>26.0<br>22.4<br>19.2<br>16.<br><br><br><br><br><br>|4<br>-78%<br>-68%<br>13.8<br>8.9<br>9.0<br>10.0<br>10.8<br>6.0<br>5.4<br>5.0<br>5.1<br>5.0<br>1.9<br>1.7<br>1.5<br>1.5<br>0<br>-57%<br>-28%<br>23.0<br>22.6<br>19.7<br>18.3<br>16.6<br>11.2<br>10.7<br>10.1<br>9.3<br>8.3<br>3.2<br>3.1<br>2.9<br>2.6<br>6<br>-28%<br>15%<br>na<br>26.0<br>22.4<br>19.2<br>16.6<br>15.5<br>14.6<br>12.5<br>10.7<br>9.1<br>6.3<br>5.4<br>4.8<br>4.1<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>|1.4<br>9.7<br>8.6<br>7.5<br>7.5<br>7.6<br>2.4<br>31.6<br>18.5<br>19.2<br>17.3<br>15.0<br>3.6<br>20.9<br>19.4<br>16.1<br>13.8<br>11.6<br><br><br><br><br><br>|2.6%<br>3.3%<br>2.9%<br>2.7%<br>2.5%<br>11.1%<br>11.5%<br>11.9%<br>11.0%<br>9.9<br>1.3%<br>1.3%<br>1.3%<br>1.4%<br>1.5%<br>3.6%<br>5.9%<br>5.5%<br>5.8%<br>6.4<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>5.1%<br>5.5%<br>6.3%<br>7.1%<br>8.0<br><br><br><br><br><br><br><br><br><br>|%<br>9%<br>0%<br>%<br>2%<br>4%<br>%<br>11%<br>13%<br><br><br>|
|UCB<br>Zealand Pharma|UCB.BR<br>ZELA.CO|BEL<br>EUR<br>63%<br>**Buy**<br>BEL<br>DKK<br>89%<br>**Hold**|221<br>311||**29**<br>**30**|42<br>**0**<br>22|49<br>26.6<br>18.7<br>16.1<br>13.7<br>11<br>3<br>3.5<br>12.2<br>27.2|.6<br>22.1<br>18.9<br>16.8<br>14.9<br>13.<br>3.4<br>9.7<br>8.4<br>21.7<br>11.|4<br>-42%<br>-16%<br>27.0<br>23.0<br>20.3<br>17.9<br>15.9<br>15.9<br>13.9<br>11.8<br>9.8<br>8.2<br>5.4<br>4.7<br>4.1<br>3.5<br>4<br>-91%<br>-57%<br>3.4<br>9.7<br>8.4<br>21.7<br>11.4<br>2.6<br>7.8<br>6.1<br>14.8<br>6.8<br>2.0<br>3.2<br>2.2<br>4.7|3.0<br>22.8<br>15.1<br>14.2<br>11.8<br>9.9<br>2.3<br>2.9<br>8.2<br>6.7<br>15.1<br>7.6|0.6%<br>0.6%<br>0.7%<br>0.7%<br>0.7%<br>4.4%<br>6.6%<br>6.6%<br>7.4%<br>8.2<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>28.3%<br>9.5%<br>10.1%<br>4.2%<br>7.4|%<br>15%<br>13%<br>%<br>-36%<br>-26%|
|**German Health Care**|||||||**17.6**<br>**17.0**<br>**14.6**<br>**12.8**<br>**11**|**.1**|**9.4**<br>**8.8**<br>**7.9**<br>**7.0**<br>**6.1**<br>**2.4**<br>**2.3**<br>**2.1**<br>**1.9**|**1.7**<br>**-29.9**<br>**16.0**<br>**26.0**<br>**24.4**<br>**19.3**|**1.5%**<br>**1.9%**<br>**2.1%**<br>**2.3%**<br>**2.5%**<br>**2.1%**<br>**4.4%**<br>**6.9%**<br>**7.6%**<br>**8.6**|**%**<br>**7.6%**<br>**11.5%**|
|**EU MedTech**|||||||**192**<br>**22.8**<br>**25.1**<br>**18.8**<br>**16.3**<br>**14**|**.5**|**12.0**<br>**11.2**<br>**10.1**<br>**9.0**<br>**7.8**<br>**3.2**<br>**3.0**<br>**2.7**<br>**2.5**|**2.3**<br>**27.8**<br>**21.5**<br>**20.2**<br>**16.4**<br>**14.2**|**23.3%**<br>**25.7%**<br>**29.4%**<br>**33.3%**<br>**36.1%**<br>**5.9%**<br>**4.5%**<br>**7.8%**<br>**7.4%**<br>**7.9**|**%**<br>**7.1%**<br>**9.4%**|
|**US Major Pharma**|||||||**3,414**<br>**21.3**<br>**22.4**<br>**16.0**<br>**15.0**<br>**14**|**.1**<br>**20.1**<br>**19.2**<br>**16.5**<br>**14.8**<br>**13.**|**2**<br>**20.1**<br>**19.2**<br>**16.5**<br>**14.8**<br>**13.2**<br>**16.7**<br>**18.9**<br>**12.5**<br>**11.6**<br>**10.6**<br>**7.0**<br>**6.2**<br>**5.7**<br>**5.3**|**4.9**<br>**28.5**<br>**25.9**<br>**18.2**<br>**16.7**<br>**16.2**|**0.9%**<br>**1.0%**<br>**0.8%**<br>**0.9%**<br>**0.9%**<br>**4.9%**<br>**5.0%**<br>**6.4%**<br>**6.7%**<br>**6.7**|**%**<br>**16.1%**<br>**10.9%**|
|AbbVie, Inc.|ABBV.N|US<br>US$ 100%<br>**NR**|260|||462|462<br>26.2<br>18.5<br>16.0<br>14.4<br>13|.3|20.6<br>14.3<br>12.4<br>11.1<br>10.1<br>8.5<br>7.7<br>6.9<br>6.2|5.7<br>26.7<br>22.7<br>18.0<br>16.7<br>16.1|na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n|a<br>28%<br>18%|
|Amgen|AMGN.OQ|US<br>US$ 100%<br>**NR**|444|||240|240<br>20.9<br>19.3<br>18.2<br>17.4<br>16|.3|13.4<br>13.6<br>12.9<br>12.5<br>11.4<br>7.9<br>7.2<br>6.9<br>6.5|6.2<br>37.5<br>29.5<br>22.5<br>21.8<br>21.3|na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n|a<br>7%<br>6%|
|Biogen Inc.<br>Bristol-Myers Squibb<br>Gilead|BIIB.OQ<br>BMY.N<br>GILD.OQ|US<br>US$ 100%<br>**NR**<br>US<br>US$ 100%<br>**NR**<br>US<br>US$ 100%<br>**NR**|225<br>68<br>151|||33<br>139<br>189|33<br>15.1<br>18.0<br>13.6<br>12.3<br>11<br>139<br>11.3<br>9.8<br>10.3<br>12.0<br>13<br>189<br>18.7<br>15.4<br>14.4<br>12|.4<br>15.1<br>18.0<br>13.6<br>12.3<br>11.<br>.2<br>.9|4<br>-9%<br>15%<br>15.1<br>18.0<br>13.6<br>12.3<br>11.4<br>11.6<br>14.4<br>10.8<br>9.5<br>7.6<br>3.5<br>3.7<br>3.4<br>3.0<br>10.1<br>8.1<br>7.9<br>8.8<br>9.5<br>3.6<br>3.3<br>3.3<br>3.6<br>13.5<br>42.9<br>11.9<br>11.2<br>9.3<br>6.9<br>6.8<br>6.2<br>5.7|2.7<br>17.4<br>18.6<br>13.9<br>11.7<br>10.6<br>3.9<br>13.4<br>12.0<br>11.1<br>11.0<br>10.7<br>5.1<br>19.3<br>43.1<br>15.9<br>15.3<br>14.7|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>6.0%<br>6.3%<br>7.9%<br>8.6%<br>8.6<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n|%<br>a<br>5%<br>-4%<br>a<br>10%<br>10%|
|Johnson & Johnson|JNJ.N|US<br>US$ 100%<br>**NR**|278|||674|674<br>25.8<br>24.1<br>21.9<br>19.6<br>17|.2<br>25.8<br>24.1<br>21.9<br>19.6<br>17.|2<br>55%<br>54%<br>25.8<br>24.1<br>21.9<br>19.6<br>17.2<br>19.5<br>18.4<br>16.6<br>14.9<br>13.1<br>7.3<br>6.9<br>6.3<br>5.7|5.2<br>31.3<br>27.9<br>23.7<br>22.0<br>21.6|1.9%<br>1.9%<br>2.0%<br>2.1%<br>2.1%<br>3.2%<br>3.7%<br>4.3%<br>4.5%<br>4.5|%|
|<br>Eli Lilly and Company<br>Merck|LLY.N<br>MRK.N|US<br>US$ 90%<br>**NR**<br>US<br>US$ 100%<br>**NR**|1,160<br>152|||1,032<br>383|1,032<br>49.6<br>31.6<br>24.6<br>21.3<br>18<br>383<br>17.0<br>55.4<br>16.0<br>14.6<br>14|.9<br>.7|37.4<br>24.4<br>19.2<br>16.3<br>14.0<br>16.6<br>12.0<br>10.2<br>8.8<br>14.4<br>29.5<br>13.3<br>12.2<br>12.4<br>6.5<br>6.5<br>6.1<br>5.7|7.8<br>86.4<br>43.0<br>31.5<br>24.7<br>23.9<br>5.7<br>22.0<br>29.9<br>20.8<br>18.9<br>19.2|na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n|a<br>42%<br>27%<br>a<br>3%<br>4%|
|Pfizer, Inc.<br>Regeneron Pharmaceuticals<br>|PFE.N<br>REGN.OQ|US<br>US$ 99%<br>**NR**<br>US<br>US$ 98%<br>**NR**|29<br>843|||164<br>97|164<br>9.2<br>9.7<br>9.9<br>11.8<br>12<br>97<br>19.4<br>15.6<br>14.0<br>12.4<br>11<br><br><br><br><br>|.4<br>.1<br>19.4<br>15.6<br>14.0<br>12.4<br>11.<br>|9.5<br>9.6<br>8.8<br>10.0<br>11.5<br>3.5<br>3.5<br>3.6<br>3.8<br>1<br>16%<br>0%<br>19.4<br>15.6<br>14.0<br>12.4<br>11.1<br>17.2<br>13.5<br>11.0<br>9.3<br>7.5<br>5.9<br>4.7<br>4.1<br>3.7<br><br><br><br><br>|3.8<br>13.9<br>15.6<br>12.4<br>13.1<br>12.9<br>3.2<br>16.7<br>16.6<br>11.7<br>11.5<br>10.9<br><br><br><br><br>|na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>n<br>0.5%<br>0.6%<br>0.6%<br>5.4%<br>5.2%<br>7.1%<br>6.8%<br>6.8<br><br><br><br><br><br><br><br><br><br>|a<br>%<br>18%<br>15%<br>|
|US vs EU major multiple<br>|||||||34%<br>45%<br>11%<br>14%<br>17<br><br><br><br><br><br>|%<br>|38%<br>63%<br>17%<br>19%<br>16%<br><br><br><br><br><br><br><br><br>|36%<br>56%<br>7%<br>12%<br>19%<br><br><br><br><br><br>|-2%<br>-2%<br>-2%<br>-2%<br>-3%<br>-1%<br>-1%<br>0%<br>-1%<br>-1<br><br><br><br><br><br><br><br><br><br>|%<br><br><br>|
|**US MedTech**|||||||**637**<br>**18.4**<br>**17.5**<br>**16.2**<br>**14.8**<br>**13**|**.6**|**14.3**<br>**13.3**<br>**12.3**<br>**11.4**<br>**12.1**<br>**4.3**<br>**4.0**<br>**3.7**<br>**3.4**|**3.2**<br>**31.6**<br>**25.5**<br>**21.8**<br>**20.1**<br>**19.8**|**1.7%**<br>**1.7%**<br>**1.8%**<br>**1.8%**<br>**2.4%**<br>**4.2%**<br>**4.9%**<br>**5.5%**<br>**5.9%**<br>**5.9**|**%**<br>**6.5%**<br>**#DIV/0!**|
|**US Spec and Drug Delivery**|||||||**1.98**<br>**13.0**<br>**9.1**<br>**7.3**<br>**6.6**<br>**6**|**.1**|**-0.2**<br>**3.5**<br>**2.6**<br>**1.8**<br>**-1.1**<br>**1.0**<br>**0.7**<br>**0.5**<br>**0.3**<br>|**-0.4**<br>**7.7**<br>**6.5**<br>**5.4**<br>**4.5**<br>**-2.2**|**na**<br>**na**<br>**na**<br>**10.7%**<br>**15.0%**<br>**17.1%**<br>**19.1%**<br>**19.5**|**%**|
|<br>**US mid-biotech**|||||||**330**<br>**44.6**<br>**30.3**<br>**21.7**<br>**22.9**<br>**15**|**.5**<br>**47.0**<br>**30.9**|**14.5**<br>**10.5**<br>**4.0**<br>**-1.3**<br>**-15.2**<br>**8.2**<br>**8.1**<br>**7.1**<br>**5.5**|**4.9**<br>**-49.5**<br>**5.2**<br>**6.5**<br>**4.0**<br>**-4.5**|**0.0%**<br>**0.0%**<br>**0.0%**<br>**0.0%**<br>**0.0%**<br>**-0.9%**<br>**1.3%**<br>**2.2%**<br>**6.5%**<br>**7.9**|**%**<br>**13.6%**<br>**-16.9%**|
|Alnylam Pharmaceuticals<br>Alvotech<br>BioMarin<br>Beone Medicines<br>BioNTech<br>Incyte Corporation|ALNY.OQ<br>ALVO.OQ<br>BMRN.OQ<br>ONC.OQ<br>BNTX.OQ<br>INCY.OQ|US<br>US$ 100%<br>**NR**<br>US<br>US$ 39%<br>**Hold**<br>US<br>US$ 99%<br>**NR**<br>US<br>US$ na<br>**NR**<br>US<br>US$ na<br>**Buy**<br>US<br>US$ 84%<br>**NR**|265<br>5<br>66<br>363<br>103<br>128||**14**|41<br>**4**<br>1<br>13<br>44<br>**0**<br>24<br>26|41<br>32.2<br>23.7<br>17.9<br>16<br>1<br>24.3<br>12.1<br>7<br>13<br>20.7<br>13.2<br>10.3<br>8.8<br>7<br>44<br>108.1<br>46.1<br>30.5<br>25.3<br>18<br>24<br>na<br>18.9<br>30.7<br>14.9<br>13.6<br>26|.7<br>63.4<br>32.2<br>23.7<br>17.9<br>16.<br>.1<br>na<br>na<br>18.3<br>10.2<br>7.<br>.6<br>.7<br>.0|7<br>281%<br>106%<br>63.4<br>32.2<br>23.7<br>17.9<br>16.7<br>71.4<br>33.3<br>23.9<br>18.6<br>14.8<br>11.2<br>7.7<br>6.0<br>5.1<br>6<br>na<br>na<br>na<br>12.0<br>6.9<br>5.3<br>4.5<br>17.1<br>10.6<br>6.9<br>5.0<br>3.8<br>4.0<br>3.4<br>2.3<br>1.7<br>19.4<br>17.2<br>11.8<br>6.1<br>4.8<br>3.9<br>4.4<br>3.6<br>2.0<br>-16.8<br>-14.6<br>-16.8<br>2.8<br>2.5<br>6.0<br>11.0<br>11.5<br>2.0<br>15.3<br>20.6<br>8.6<br>7.5<br>na<br>5.4<br>3.6<br>3.1<br>2.6|4.5<br>111.2<br>36.2<br>21.8<br>18.6<br>18.6<br>1.4<br>-40.2<br>13.9<br>12.2<br>7.7<br>5.2<br>1.6<br>18.8<br>13.6<br>7.7<br>6.7<br>1.8 -379.8<br>-13.2<br>-14.1<br>2.9<br>2.5<br>na<br>20.1<br>-16.0<br>11.9<br>8.6<br>na|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.9%<br>2.8%<br>4.7%<br>5.5%<br>5.5<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-4.8%<br>13.2%<br>14.2%<br>20.5%<br>26.1<br>na<br>na<br>na<br>na<br>na<br>n<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-0.2%<br>-7.1%<br>-7.2%<br>4.9%<br>4.7<br>na<br>na<br>na<br>na<br>n|%<br>%<br>a<br>%<br>12%<br>a<br>13%<br>-8%|
|<br>Moderna<br>|MRNA.OQ<br>|US<br>US$ 92%<br>**Hold**<br><br><br><br>|149<br>||**12**|**5**<br>58<br>|58<br><br><br>||-19.6<br>-17.4<br>-25.9<br>-64.9 -129.6<br>28.8<br>26.5<br>21.0<br>17.5<br>1|4.2<br>-27.1<br>-16.0<br>-20.1<br>-34.8<br>-75.8|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>-3.6%<br>-6.0%<br>-4.8%<br>-2.9%<br>-1.3|%<br>-10%<br>-26%|
|Novavax<br>Vertex Pharmaceuticals<br>**Glbl i/biiil**|NVAX.OQ<br>VRTX.OQ<br>|US<br>US$ 99%<br>**NR**<br>US<br>US$ 100%<br>**NR**|10<br>558|||2<br>146|2<br>60.1<br>12<br>146<br>30.5<br>29.5<br>26.5<br>22.7<br>19<br>**136**<br>**485**<br>**360**<br>**239**<br>**183**<br>**1**|.9<br>.2<br>30.5<br>29.5<br>26.5<br>22.7<br>19.<br>**4**<br>**292**<br>**228**<br>**282**<br>**214**<br>**19**|2<br>83%<br>88%<br>30.5<br>29.5<br>26.5<br>22.7<br>19.2<br>na<br>23.8<br>19.5<br>15.6<br>12.6<br>na<br>10.1<br>8.6<br>7.3<br>**2**<br>**158**<br>**132**<br>**108**<br>**93**<br>**85**<br>**46**<br>**38**<br>**34**<br>**30**|6.1<br>na<br>26.0<br>20.2<br>17.3<br>16.0<br>**27**<br>**320**<br>**599**<br>**233**<br>**181**<br>**172**|0.0%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>3.3%<br>3.5%<br>4.3%<br>4.7%<br>4.7<br>**03%**<br>**04%**<br>**04%**<br>**08%**<br>**08%**<br>**19%**<br>**19%**<br>**40%**<br>**51%**<br>**52**|%<br>**%**|
|**oa genercsosmar co**<br>Biocon Biologics<br>Coherus BioSciences<br>Sandoz<br>T|**ps**<br>BION.BO<br>CHRS.OQ<br>SDZ.S<br>TEVAN|US<br>US$ 46%<br>**NR**<br>US<br>US$ 82%<br>**NR**<br>US<br>US$ 96%<br>**Hold**<br>US<br>US$ **NR**|402<br>1<br>70<br>37||**6**|316<br>0<br>**5**<br>30<br>42|**.**<br>**.**<br>**.**<br>**.**<br><br>3<br>144.9<br>105.3<br>57.8<br>36.7<br>28<br>0<br>38<br>25.7<br>21.3<br>18.9<br>16.8<br>15<br>42<br>140<br>185<br>120<br>107<br>9|**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>.4<br>na<br>na<br>57.6<br>36.5<br>28.<br>na<br>na<br>na<br>na<br>n<br>.1<br>23.3<br>21.8<br>19.3<br>17.1<br>16.<br>8<br>140<br>185<br>120<br>107<br>9|**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>3<br>na<br>na<br>na<br>na<br>57.6<br>36.5<br>28.3<br>15.0<br>12.4<br>9.7<br>7.6<br>6.6<br>3.0<br>2.5<br>2.1<br>1.8<br>a<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>na<br>1<br>40%<br>39%<br>27.0<br>24.9<br>22.5<br>19.9<br>18.6<br>14.1<br>12.2<br>10.6<br>9.3<br>8.4<br>3.1<br>2.8<br>2.6<br>2.3<br>8<br>-16%<br>18%<br>140<br>185<br>120<br>107<br>98<br>113<br>127<br>92<br>80<br>70<br>33<br>33<br>30<br>27|**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>1.6<br>28.3<br>140.4<br>25.0<br>15.1<br>15.0<br>na<br>na<br>na<br>na<br>na<br>2.1<br>32.6<br>36.4<br>18.0<br>15.3<br>13.5<br>24<br>294<br><br><br><br>|**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>**.**<br>0.3%<br>0.1%<br>0.2%<br>0.2%<br>0.2%<br>5.0%<br>1.0%<br>5.2%<br>8.3%<br>8.3<br>-5.0%<br>na<br>3.1%<br>3.1%<br>3.1<br>0.8%<br>1.0%<br>1.2%<br>1.6%<br>1.7%<br>2.8%<br>2.4%<br>4.8%<br>5.4%<br>5.8<br>00%<br>00%<br>00%<br><br><br>45%<br><br><br><br>|%<br>%<br>%<br>|
|eva<br>|.<br>||||||.<br>.<br>.<br>.<br><br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>.<br>|.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br><br><br><br><br><br><br><br><br>|.<br>.<br>na<br>na<br>na<br>na<br><br><br><br><br><br>|.<br>.<br>.<br>na<br>na<br>.<br>na<br>na<br>na<br>|a|
|Viatris|VTRS.OQ|US<br>US$ 100%<br>**NR**|17|||19|19<br>7.3<br>6.8<br>6.4<br>6.0<br>5|.7|7.9<br>7.1<br>6.6<br>6.1<br>5.5<br>2.3<br>2.1<br>2.0<br>1.9|1.7<br>16.9<br>16.4<br>13.7<br>12.6<br>11.6|||
|**China Pharma**|||||||**141.9**|**27.0**<br>**20.0**<br>**18.9**<br>**16.7**|**12.6**<br>**11.8**<br>**12.0**<br>**10.0**<br>**28.8**|**14.9**<br>**13.6**<br>**18.1**<br>**16.5**<br>**61.4**|**2%**<br>**1%**<br>**2%**<br>**2%**<br>**2%**<br>**4%**<br>**7%**<br>**7%**<br>**7%**<br>**6**|**%**<br>**4%**<br>**#DIV/0!**|
|**Japan Pharma**|||||||**191.7**|**29.5**<br>**16.4**<br>**14.8**<br>**13.6**<br>**13.**|**1**<br>**11.0**<br>**9.6**<br>**9.1**<br>**8.3**<br>**7.7**<br>**3.8**<br>**3.5**<br>**3.2**<br>**3.1**|**3.0**<br>**25.4**<br>**21.4**<br>**15.5**<br>**13.8**<br>**13.8**|**3%**<br>**3%**<br>**3%**<br>**3%**<br>**3%**<br>**4%**<br>**7%**<br>**9%**<br>**9%**<br>**9**|**%**<br>**#DIV/0!**<br>**#DIV/0!**|
|**Australian Pharma**<br>CSL Limited|CSL.AX (AUD|) AUS AUD<br>100%<br>**NR**|220.70|||83.8|60.3<br>19.3<br>20.0<br>20.0<br>18.6<br>17|.5<br>24.3<br>25.2<br>25.2<br>23.5<br>22.|1<br>24.3<br>25.2<br>25.2<br>23.5<br>22.1<br>15.9<br>15.4<br>16.5<br>15.8<br>15.0<br>5.3<br>5.4<br>5.3<br>5.1|4.9<br>31.5<br>31.4<br>33.7<br>34.1<br>34.1|1.8%<br>0.0%<br>1.9%<br>2.1%<br>2.1%<br>3.4%<br>3.4%<br>3.2%<br>3.2%<br>3.2|%|
|**Consumer**|||||||**1,103.4**||||||
|Beiersdorf<br>Haleon|BEIG.DE (EUR<br>HLNL (GBP)|) GER EUR<br>37%<br>**Hold**<br>UK<br>GBp<br>100%<br>**Sell**|76.4p<br>3576p||**7**<br>**33**|**0**<br>16.5<br>**5**<br>317|19.2<br>17.4<br>19.9<br>19.0<br>17.8<br>16<br>429<br>193<br>170<br>156<br>144<br>13|.8<br>17.2<br>17.7<br>16.8<br>15.8<br>15.<br>2<br>190<br>169<br>159<br>152<br>14|1<br>3%<br>13%<br>18.0<br>17.7<br>16.8<br>15.8<br>15.1<br>8.4<br>8.8<br>8.5<br>7.9<br>7.3<br>1.5<br>1.5<br>1.4<br>1.3<br>4<br>14%<br>8%<br>19.4<br>18.3<br>15.9<br>15.2<br>14.4<br>137<br>124<br>115<br>108<br>101<br>35<br>34<br>32<br>30|1.2<br>15.4<br>19.1<br>18.9<br>18.8<br>18.1<br>28<br>244<br>235<br>201<br>179<br>174|1.3%<br>0.0%<br>0.0%<br>0.0%<br>0.0%<br>5.5%<br>4.4%<br>4.4%<br>4.3%<br>4.3<br>20%<br>23%<br>24%<br>26%<br>27%<br>50%<br>51%<br>58%<br>63%<br>63|%<br>1%<br>3%<br>%<br>9%<br>7%|
||.<br>|<sup>UK</sup><br><br><br>|.<br>||**1**|.<br><br>|.<br>.<br>.<br>.<br>.<br><br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>.<br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br><br>5%<br>2%<br>248<br>191<br>160<br>153<br>146<br><br><br><br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>.<br><br><br><br><br><br>|.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br><br><br><br><br><br><br><br><br><br>||
|Kenvue Inc.<br>L'Oreal|KVUE.N (USD<br>OREP.PA (EU|) <br>US$ 99%<br>**Hold**<br>R) FRA<br>EUR<br>45%<br>**Sell**|19.0p<br>378.5p||**34**|14.5<br>**0**<br>202.2|14.5<br>18.4<br>16.1<br>15.2<br>14.5<br>14<br>235.0<br>29.4<br>27.7<br>25.4<br>23.3<br>21|.1<br>17.6<br>15.4<br>14.7<br>14.1<br>13.<br>.5<br>29.8<br>27.6<br>25.5<br>23.1|5<br><br>-<br>.<br>.<br>.<br>.<br>.<br>6.4<br>5.6<br>5.1<br>4.7<br>4.3<br>3.5<br>1.4<br>1.3<br>1.2<br>79%<br>76%<br>33.1<br>29.3<br>27.1<br>24.5<br>#N/A<br>19.4<br>18.5<br>17.2<br>15.7<br>na<br>4.7<br>4.5<br>4.2<br>3.8|1.1<br>24.4<br>23.5<br>20.1<br>17.9<br>17.4<br>na<br>31.1<br>30.4<br>25.7<br>23.6<br>na|0.0<br>0.0<br>0.0<br>0.0<br>0.0<br>0.0<br>0.1<br>0.1<br>0.1<br>0<br>1.9%<br>2.1%<br>2.3%<br>2.5%<br>na<br>3.3%<br>3.4%<br>4.0%<br>4.3%<br>4.3|.1<br>9%<br>7%<br>%<br>8%|
|Nestle<br>Oranon & Co|NESN.S (CHF<br>OGNN (USD)|)<br>SWI<br>CHF<br>100%<br>**Hold**<br>US<br>US$ 100%<br>**NR**|77.8p<br>13.77||**8**|**2**<br>200.4<br>36|248.1<br>18.1<br>17.5<br>16.5<br>15.5<br>14<br>36<br>37<br>37<br>37<br>37<br>3|.5<br>18.1<br>17.5<br>16.5<br>15.5<br>14.<br>7|5<br>9%<br>12%<br>22.2<br>21.1<br>16.9<br>15.9<br>14.9<br>13.4<br>13.4<br>13.1<br>13.0<br>12.8<br>2.8<br>2.8<br>2.7<br>2.6<br>18<br>18<br>18<br>18<br>18<br>06<br>06<br>06<br>06|2.5<br>29.1<br>26.5<br>23.8<br>22.6<br>22.3<br>06<br>54<br>49<br>39<br>35<br>35|4.0%<br>4.0%<br>4.1%<br>4.3%<br>4.3%<br>4.4%<br>4.8%<br>5.2%<br>5.4%<br>5.4<br>na<br>40%<br>41%<br>43%<br>43%<br>na<br>na<br>na<br>|%<br>5%<br>6%<br>a|
|g<br>Procter & Gamble|.<br>PG.N (USD)|US<br>US$ 100%<br>**Buy**<br>|146.9p||**16**|.<br>**2**<br>355.9|.<br>.<br>.<br>.<br>.<br><br>355.9<br>21.8<br>21.4<br>21.1<br>19.9<br>18|.<br>.8<br>21.8<br>21.4<br>21.1<br>19.9<br>18.|.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>.<br>8<br>31%<br>37%<br>21.8<br>21.4<br>21.1<br>19.9<br>18.8<br>16.5<br>16.5<br>16.6<br>16.5<br>16.4<br>4.5<br>4.4<br>4.3<br>4.1|.<br>.<br>.<br>.<br>.<br>.<br>3.9<br>25.4<br>25.4<br>24.6<br>22.2<br>22.0|.<br>.<br>.<br>.<br><br><br><br><br>2.8%<br>2.9%<br>3.0%<br>3.1%<br>3.1%<br>4.2%<br>4.2%<br>4.3%<br>4.8%<br>4.8|%<br>2%<br>4%|
|Reckitt<br>Unilever Plc|RKT.L (GBP)<br>ULVR.L (GBP)|UK<br>GBp<br>100%<br>**Hold**<br> <br>UK<br>GBp<br>99%<br>**Hold**|5,080.0p<br>4,733.0p||**5,40**<br>**5,15**|**0**<br>32.7<br>**0**<br>103.3|44.3<br>14.0<br>15.0<br>14.1<br>13.3<br>12<br>139.9<br>18.3<br>17.1<br>16.3<br>15.3<br>14|.6<br>0.1<br>0.2<br>0.1<br>0.1<br>.7<br>17.9<br>17.2<br>16.4<br>15.4<br>14.|-99%<br>-99%<br>0.1<br>0.2<br>0.1<br>0.1<br>#N/A<br>9.7<br>11.2<br>10.4<br>9.8<br>na<br>2.8<br>3.2<br>3.0<br>2.8<br>4<br>8%<br>10%<br>17.9<br>17.2<br>16.4<br>15.4<br>14.4<br>10.5<br>10.2<br>9.6<br>9.0<br>8.5<br>2.4<br>2.3<br>2.2<br>2.1|na<br>19.3<br>21.8<br>20.9<br>17.6<br>na <br>2.0<br>19.6<br>20.1<br>18.0<br>17.2<br>17.0|417.7% 438.6% 460.5% 483.6%<br>na<br>3.3%<br>3.4%<br>3.6%<br>3.8%<br>3.9%<br>5.1%<br>5.0%<br>5.5%<br>5.7%<br>5.7|0%<br>%<br>5%<br>6%|



_Source : Deutsche Bank; Bloomberg Finance LP, Prices as of 04/09/2026_ 



This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 

## Sector price performance summary 

Figure 3: Global summary valuation comparison 

|**~~04 September 2026~~**||**Price R**<br>**% Local**|**eturns**<br>**currency**|||**12m fwd PE**<br>**x**|||**Earnings Growt**<br>**%**|**h**|**Earnin**<br>|**gs MOM**<br>**%**||**Div Yield**<br>**%**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Sector Name**|**-1m**|**-3m**|**-12m**|**YTD**|**Latest**|**5yr med**|**10yr med**|**2025**|**2026**|**2027**|**-1m**|**-3m**|**2025**|**2026**|**2027**|
|Energy|7.7|7.3|42.5|39.3|12.7|11.3|24.8|-90.2|-70.1|-89.4|5.3|8.2|3.9|2.9|3.1|
|Chemicals|1.9|3.9|9.5|16.4|21.6|19.0|18.7|-89.8|-79.0|-91.3|-0.1|0.1|2.3|2.0|2.1|
|Construction Material|-6.3|-11.3|-12.5|-19.0|17.1|16.7|16.7|-86.9|-77.2|-89.2|-1.7|-3.3|1.5|1.7|1.8|
|Metals & Mining|13.4|4.5|62.3|29.0|15.4|12.1|12.8|-87.3|-63.6|-82.8|-1.2|-5.3|1.9|2.0|2.0|
|Capital Goods|-5.7|-1.8|20.4|13.0|23.5|20.2|19.0|-88.5|-76.2|-88.6|0.8|2.6|1.5|1.4|1.6|
|Commercial svs & supplies|-0.4|4.2|-9.3|-3.4|24.0|27.9|26.1|-93.7|-88.1|-94.5|0.5|-0.2|1.2|1.5|1.6|
|Transportation|-1.3|2.0|16.7|11.6|17.9|17.6|19.5|-85.2|-77.7|-89.6|3.8|6.4|2.2|2.0|2.1|
|Automobiles|11.0|-5.1|7.3|-13.2|24.9|17.8|15.2|-92.4|-87.2|-93.5|2.4|2.0|1.1|1.2|1.3|
|Cons. Durables & Apparel|-3.7|2.3|-6.0|-9.0|19.4|19.5|19.7|-92.2|-86.2|-93.8|-0.5|7.4|1.5|2.0|2.2|
|Hotels⁄Rests⁄Leis|0.0|6.7|-5.8|-1.3|21.5|26.7|44.4|-88.4|-77.4|-89.5|1.2|2.5|1.4|1.6|1.7|
|Retail|-6.8|1.4|0.7|4.7|22.3|26.5|27.7|-79.0|-42.2|-77.5|1.0|23.1|0.6|0.6|0.7|
|Food Retail|-1.8|-1.4|5.6|3.7|25.7|23.4|21.3|-95.2|-90.6|-95.9|4.0|4.3|1.4|1.5|1.5|
|Food⁄Bev⁄Tob|-0.5|4.3|7.9|8.7|16.9|17.4|18.2|-89.8|-81.5|-91.7|0.4|1.1|3.7|3.5|3.7|
|HPC|-0.6|8.6|-5.9|2.2|19.6|22.1|22.4|-91.7|-85.9|-93.5|-0.1|-2.8|3.0|3.0|3.0|
|HCare Eq. & Svs|1.4|7.2|-1.2|-3.3|18.0|19.8|19.8|-78.4|-61.7|-82.2|0.9|2.6|1.4|1.5|1.6|
|Pharma & Biotech|7.5|13.3|30.6|13.0|18.9|17.2|16.8|-90.5|-84.0|-91.8|1.0|-2.8|2.0|1.9|2.0|
|Banks|1.2|13.6|35.2|20.2|12.9|10.5|10.9|-92.3|-83.9|-92.7|2.2|4.8|3.2|3.2|3.5|
|Div Financials|1.7|11.3|4.9|4.8|18.1|17.5|16.4|-92.0|-84.0|-92.8|2.1|6.2|1.2|1.6|1.8|
|Insurance|1.0|14.1|12.5|9.7|12.7|12.3|12.1|-90.5|-81.9|-92.2|3.4|2.7|3.0|3.2|3.4|
|Software & Services|5.2|11.2|-1.8|1.0|24.7|29.7|28.2|-86.6|-75.6|-86.7|-1.4|-5.8|0.6|0.7|0.7|
|Technology HW|1.6|-1.1|45.1|29.7|27.5|25.4|22.0|-86.3|-66.4|-83.3|11.0|12.9|0.6|0.5|0.5|
|Semiconductors|-2.0|-7.6|63.6|39.0|20.0|25.7|21.5|-65.6|40.8|-6.0|1.6|9.8|0.4|0.5|0.6|
|Media & Ent'ment|-4.0|-4.9|8.7|0.5|21.7|21.0|21.1|-88.0|-66.6|-87.7|-0.7|19.4|0.4|0.4|0.4|
|Telecoms|5.9|0.9|-1.9|6.7|14.4|12.4|12.7|-96.8|-94.4|-97.7|1.4|-5.0|3.9|3.7|3.8|
|Utilities|-2.7|-1.9|9.0|2.6|16.3|16.5|16.5|-93.9|-88.5|-94.8|1.7|2.1|3.3|3.4|3.6|
|MSCI Europe|-1.1|4.0|18.0|9.8|15.2|14.1|14.7|-93.4|-86.9|-94.1|0.4|1.7|3.0|3.0|3.3|
|Stoxx 600|-1.2|4.0|18.0|9.6|15.0|14.1|14.9|-80.0|-60.2|-81.9|0.3|1.6|3.0|3.1|3.4|
|Large Cap|0.7|2.9|20.4|13.2|19.1|18.9|18.2|-31.7|52.2|-27.6|1.8|5.7|1.5|1.5|1.6|
|Mid Cap|-0.5|2.0|13.8|11.2|17.2|16.8|17.9|-34.7|28.8|-40.1|0.7|2.3|2.0|2.1|2.3|
|Small Cap|0.2|2.3|21.6|16.4|17.8|17.0|19.3|-81.9|-61.9|-81.2|-4.8|-4.2|2.0|2.3|2.5|



_Source : Deutsche Bank, Bloomberg Finance LP, Prices as of 04/09/2026_ 



This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 

## Quarterly BEAT/MISS table 

The following table shows quarterly company reported revenue and net income vs DB estimates 

Figure 4: Quarterly BEAT/MISS table (Reported vs DB estimates) 



<!-- Start of picture text -->
Reported  v s  D B  e stimates Reported  v s  D B  e stimates<br>Revenue Core EPS/Core Net  i ncome<br>AZN in-line +1% -4% in-line -1% -4% +3% +3% +1% +7% -1% -2% +4% +5% AZN +1% -1% -2% +7% +1% +6% +3% -3% -3% +5% -10% -3% +12% +10%<br>GSK +1% -2% in-line +3% in-line +1% +3% -1% +6% +2% +6% +6% +4% +2% GSK in-line +10% +7% +16% +2% +2% +1% +11% +15% +23% +1% +16% +3% +7%<br>NOVN +3% -3% -4% +1% +3% +1% +1% -2% in-line +6% +2% +9% +4% +4% NOVN +6% -9% +1% -1% +4% +11% +8% 7% +3% +9% -9% +12% +9% +10%<br>NOVO +8% -2% -3% -4% -1% -4% +8% -5% -1% -3% +6% in-line -4% in-line NOVO -10% +18% +4% -15% -1% +3% +1% +1% +3% +5% +10% +3% -7% in-line<br>ROG in-line -4% +1% -2% -1% in-line -1% +1% +3% -5% -3% -1% -3% +3% ROG +5% n/a -3% n/a +1% n/a +5% n/a +7% n/a -3% n/a -3% n/a<br>SAN  +6% +3% +1% in-line +1% +1% in-line +5% +2% -1% -6% -3% -4% -2% SAN  +8% +3% +5% +8% -7% +1% -2% +18% in-line -11% +8% -1% in-line +2%<br>ALM in-line -6% -1% +2% in-line +2% +3% +2% +4% +2% in-line +2% +6% +4% ALM +48% -49% +282% +5136% -39% +33% -84% -242% -5% -21% in-line -131% +35% +34%<br>ARGX +5% -2% -1% +8% +5% -4% in-line +9% +3% -4% +14% +11% +4% +20% ARGX +16% -17% +112% +14% +12% -7% +581% +92% +1781% -1011% +53% -21% -7% +67%<br>GMAB +8% +5% +8% +6% +5% +7% -6% in-line -2% +18% +3% +3% in-line +3% GMAB +30% -64% -89% +34% +63% +169% +51% -12% +10% +116% -45% +37% in-line -66%<br>GRFS -4% -8% -4% -1% in-line +7% +3% +5% +3% -2% -4% -2% -2% +12% GRFS -11% -9% -16% +16% +168% +49% +13% +71% -83% -12% -67% -54% -55% -109%<br>IDIA +6% +5% +18% -5% +4% +28% +177% +93% +37% -36% -42% +68% -15% -46% IDIA +88% +115% +434% -29% +98% -46% -22% -43% -33% -122% -41% -245% -1% +22%<br>IPN +7% +7% +2% +5% in-line in-line +3% +3% -2% +5% -10% -6% in-line -13% IPN +16% n/a 9% n/a +9% n/a +20% n/a +3% n/a -14% n/a +15% n/a<br>LUND +5% +13% +3% +6% +4% +12% -7% +5% +4% +5% -1% in-line +6% +6% LUND +10% +30% in-line +10% +11% +1% +3% -14% +31% +37% -15% +71% +43% +25%<br>SDZ +1% +3% in-line -1% +2% -7% -1% +2% +4% +1% +2% n/a n/a n/a SDZ -5% n/a +28% n/a +20% n/a +1% n/a +11% n/a n/a n/a n/a n/a<br>SOBI +6% +2% -2% +1% +1% in-line in-line +22% +7% +20% +7% +8% +9% +1% SOBI +9% +27% +42% +18% +2% -6% +50% +68% -38% -18% -6% -74% -28% -4%<br>+5% n/a +3% n/a +14% n/a +7% n/a in-line n/a +4% n/a +1% n/a +36% n/a +19% n/a +14% n/a +231% n/a +4% n/a +10% n/a 36% n/a<br>ALVO +9% +18% -52% -4% +65% +4% +1% -6% +39% +24% -53% -49% n/a n/a ALVO +159% +29% -93% -334% -114% -81% +19% -67% in-line +793% -488% +184% n/a n/a<br>BNTX -49% -14% +39% 109% +85% -8% +2% +580% +49% -46% -8% +9% -82% n/a BNTX -73% -11% +1043% +80% +31% +12% -56% -165% +779% +33% -2% -363% -238% n/a<br>MRNA  -27% +219% -10% +20% -62% -21% -1% +61% +71% +112% +27% +23% +3% +1% MRNA  -5% -68% +26% +74% +22% -100% +93% -103% +2% -15% -130% +10143% +25% in-line<br>ZEAL -1% +164% -33% -26% +17148% -73% -9% -78% ZEAL -37% +715% +149% +43% +1802% +3% -42% -7%<br>*Unless stated otherwise 1Q23-2Q25 reflects Core net income; 3Q25 onwards Core EPS<br>**ALM/GRFLS reflects  Core Net income (Core EPS is not provided)<br>***NOVN 1Q23-3Q25 reflects Core EPS<br>Source : Deutsche Bank; Company data<br>Updated post-Q2'26 results<br><!-- End of picture text -->



This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 



<!-- Start of picture text -->
Figure 5: Quarterly BEAT/MISS table (Reported vs company consensus estimates)<br>Reported vs  c ompany  c onsensus  e stimates Reported vs  c ompany  c onsensus  e stimates<br>Revenue Core  E PS/Core  Ne t  i ncome<br>AZN in-line +2% +1% +3% +2% -2% +5% +4% +3% +7% in-line in-line +4% +3% AZN +6% +2% in-line +4% +1% +10% +1% +2% in-line +7% -3% +3% +8% +12%<br>GSK +2% +1% +1% +4% +2% +1% +4% in-line +5% +4% +5% +5% +5% +5% GSK +7% +7% +11% +17% +9% +10% +14% +14% +12% +26% +2% +9% +1% +1%<br>NOVN +3% -2% -3% in-line in-line +1% +3% +1% +2% +3% -1% +5% +3% +3% NOVN +12% -5% in-line -3% +2% +7% +9% +6% +5% +7% -4% +3% +8% +11%<br>NOVO +10% +1% -2% -2% in-line in-line +5% -1% -1% +2% +4% +2% -2% +2% NOVO -6% n/a +4% -1% -3% +5% +6% +2% -2% +8% +5% +5% -5% +4%<br>ROG +1% -1% in-line -2% +1% +1% +2% +1% +3% in-line -2% in-line -1% +3% ROG +7% n/a -2% n/a +5% n/a +2% n/a +10% n/a in-line n/a -1% n/a<br>SAN +7% +3% +1% +2% +2% +3% +2% +6% +3% +2% -1% -1% -1% in-line SAN +10% +6% +3% +8% -3% +6% +1% +15% +4% +2% -3% -2% +4% +7%<br>ALM in-line -1% +2% +1% +1% in-line +4% in-line +1% +3% -4% in-line +4% +3% ALM n/a n/a n/a n/a -36% +10% -73% +8100% +10% +42% -1235% -153% -12% -8%<br>ARGX +6% +1% +2% +7% +6% +1% in-line +7% +8% in-line +18% +11% +4% +6% ARGX +22% +3% +36% +17% +28% in-line +709% +1340% -148% +46% +28% -14% +3% +44%<br>GMAB +5% -2% +4% +6% +5% +169% +1% -1% +9% +7% in-line +7% +4% +3% GMAB +46% n/a n/a n/a +31% +52% +131% -10% +4% +69% -60% +52% +14% -54%<br>GRFS in-line -1% +2% +1% in-line +1% +3% +2% +2% -1% +1% -1% +1% +2% GRFS +2% n/a +9% n/a +44% n/a +36% +22% +21% -23% -22% -26% -18% -114%<br>IDIA n/a n/a n/a +3% in-line +28% -1% +69% +11% -47% n/a -14% +8% -37% IDIA +36% +24% n/a -17% -98% n/a -13% -40% -16% -125% n/a -223% -3% +6%<br>IPN +6% +7% +2% +3% in-line +1% +3% +1% in-line +4% -1% -2% +3% +1% IPN +4% n/a +8% n/a +9% n/a +11% n/a -2% n/a +6% n/a +4% n/a<br>LUND +4% +7% -16% +3% +1% +8% -2% +4% +4% +2% -2% -3% +2% +5% LUND +3% +22% -20% +7% +5% +1% +68% -1% +9% +24% in-line +22% +32% n/a<br>in-line +1% in-line in-line +2% -2% -1% +2% +2% -1% -2% n/a n/a n/a in-line n/a +17% n/a +13% n/a +1% n/a +1% n/a n/a n/a n/a n/a<br>SOBI +6% +2% in-line in-line in-line +3% in-line +15% +6% +9% in-line +12% +10% in-line SOBI +14% +15% +21% +20% +2% +17% +25% +96% -8% +39% -23% +67% -25% +10%<br>+4% n/a +6% n/a +9% n/a +10% n/a +4% n/a +2% n/a +1% n/a +37% n/a +31% n/a +1% n/a +175% n/a +41% n/a +11% n/a +78% n/a<br>ALVO +3% -17% -43% -2% +52% +25% +31% +7% +17% -1% -43% -49% -90% -54% ALVO +96% +232% -42% +627% -128% -79% +77% -41% +100% +325% -1128% +359% -723% +2581%<br>BNTX -31% -30% +20% +94% +89% -2% +8% +168% +18% -54% -21% +3% -73% +16% BNTX -6% +5% -552% +87% -21% +20% +69% -155% +67% +119% -17% -289% +31% +252%<br>MRNA -4% +69% +8% +18% +31% -2% +2% +52% +84% +68% +12% +31% +7% +58% MRNA +52% n/a n/a +76% +29% +19% +6% -102% in-line -15% -145% +439% -9% -111%<br>ZEAL -1% +112% -13% +42% -2% -59% -48% -76% ZEAL -19% +32% -17% +29% -9% +9% -23% -11%<br>****IDIA/ALVO/BNTX/MRNA/ZEAL/ARGX/GLPG: Compares BBG consensus *Unless stated otherwise 1Q23-2Q25 reflects Core net income; 3Q25 onwards Core EPS<br>**ALM/GRFLS reflects  Core Net income (Core EPS is not provided)<br>***NOVN 1Q23-3Q25 reflects Core EPS<br>****IDIA/ALVO/BNTX/MRNA/ZEAL/ARGX/GLPG: Compares BBG consensus<br><!-- End of picture text -->

_Source : Deutsche Bank; Company data Updated post-Q2'26 results_ 



This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

## Share price performance (absolute/relative) 

#### Company share price performance 

Company share price performance - 1 month (Large Cap) 

Figure 6: 1m FX-adjusted (into $) performance 



<!-- Start of picture text -->
Figure 7: 1m FX-adjusted (into €) performance<br><!-- End of picture text -->



<!-- Start of picture text -->
112 110<br>106 105<br>100 100<br>95<br>94<br>90<br>88<br>85<br>82 80<br>76 75<br>70 70<br>AZN BAYN GSK NOVN AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 3 months (Large Cap)<br>Figure 8: 3m FX-adjusted (into $) performance Figure 9: 3m FX-adjusted (into €) performance<br>120 170<br>115 150<br>110<br>130<br>105<br>100 110<br>95 90<br>90<br>70<br>85<br>80 50<br>AZN GSK NOVN NOVOB AZN BAYN GSK NOVN<br>ROG SAN SXXP Index NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>10-Aug-26 11-Aug-26 19-Aug-26 28-Aug-26 5-Aug-26 13-Aug-26 22-Aug-26 31-Aug-26<br>8-Jun-26 14-Jun-26 20-Jun-26 5-Jun-26 12-Jun-26 10-Jul-26 17-Jul-26 21-Aug-26<br>5-Aug-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 12-Aug-26 13-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 20-Aug-26 21-Aug-26 22-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 29-Aug-26 30-Aug-26 31-Aug-26 1-Sep-26 2-Sep-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 10-Aug-26 11-Aug-26 12-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 19-Aug-26 20-Aug-26 21-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 28-Aug-26 29-Aug-26 30-Aug-26 1-Sep-26 2-Sep-26<br>4-Jun-26 6-Jun-26 10-Jun-26 12-Jun-26 16-Jun-26 18-Jun-26 22-Jun-26 24-Jun-26 26-Jun-26 28-Jun-26 30-Jun-26 2-Jul-26 19-Jun-26 26-Jun-26 3-Jul-26 24-Jul-26 31-Jul-26 7-Aug-26 14-Aug-26 28-Aug-26<br><!-- End of picture text -->

Deutsche Bank AG 

Page 9 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Company share price performance - 6 months (Large Cap) 

Figure 10: 6m FX-adjusted (into $) performance 



<!-- Start of picture text -->
160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 1 year (Large Cap)<br>Figure 12: 1yr FX-adjusted (into $) performance<br>165<br>150<br>135<br>120<br>105<br>90<br>75<br>60<br>45<br>30<br>15<br>0<br>AZN GSK NOVN NOVOB<br>ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 5 years (Large Cap)<br>Figure 14: 5yr FX-adjusted (into $) performance<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>AZN GSK NOVN NOVOB<br>ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>11-Jun-26 25-Jun-26 9-Jul-26<br>27-Nov-25 5-Mar-26 11-Jun-26<br>6-Mar-24 6-Jun-24<br>5-Mar-26 12-Mar-26 19-Mar-26 26-Mar-26 2-Apr-26 9-Apr-26 16-Apr-26 23-Apr-26 30-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 18-Jun-26 2-Jul-26 16-Jul-26 23-Jul-26 30-Jul-26 6-Aug-26 13-Aug-26 20-Aug-26 27-Aug-26<br>4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 11-Dec-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 19-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 25-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br><!-- End of picture text -->

##### Company share price performance - 1 year (Large Cap) 

##### Company share price performance - 5 years (Large Cap) 



<!-- Start of picture text -->
Figure 11: 6m FX-adjusted (into €) performance<br><!-- End of picture text -->



<!-- Start of picture text -->
160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 13: 1yr FX-adjusted (into €) performance<br>200<br>180<br>160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 15: 5yr FX-adjusted (into €) performance<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>5-Mar-26 19-Mar-26 2-Apr-26 30-Jul-26 13-Aug-26 27-Aug-26<br>11-Dec-25 19-Mar-26 25-Jun-26<br>12-Mar-26 26-Mar-26 9-Apr-26 16-Apr-26 23-Apr-26 30-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 11-Jun-26 18-Jun-26 25-Jun-26 2-Jul-26 9-Jul-26 16-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26<br>4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 27-Nov-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 5-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 11-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Mar-24 6-Jun-24 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br><!-- End of picture text -->

Page 10 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Company share price performance - 10 years (Large Cap) 

Figure 16: 10yr FX-adjusted (into $) performance 



<!-- Start of picture text -->
Figure 17: 10yr FX-adjusted (into €) performance<br><!-- End of picture text -->



<!-- Start of picture text -->
680 760<br>700<br>600<br>640<br>520 580<br>520<br>440<br>460<br>360 400<br>280 340<br>280<br>200 220<br>160<br>120 100<br>40 40<br>AZN BAYN GSK NOVN AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 20 years (Large Cap)<br>Figure 18: 20yr FX-adjusted (into $) performance Figure 19: 20yr FX-adjusted (into €) performance<br>4,500 5,400<br>4,000 4,800<br>3,500 4,200<br>3,000 3,600<br>2,500 3,000<br>2,000 2,400<br>1,500 1,800<br>1,000 1,200<br>500 600<br>0 0<br>AZN BAYN GSK NOVN AZN BAYN GSK NOVN<br>NOVOB ROG SAN SXXP Index NOVOB ROG SAN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 1 month (SMID Cap)<br>Figure 20: 1m FX-adjusted (into $) performance -  Figure 21: 1m FX-adjusted (into $) performance - Non -<br>Profitable Profitable<br>110 350<br>100 300<br>90<br>250<br>80<br>200<br>70<br>150<br>60<br>50 100<br>50<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>5-Sep-16 5-Jan-26 5-Nov-17<br>4-Sep-11 4-Sep-14 4-Sep-09 4-Sep-12 4-Sep-23 4-Sep-26<br>5-Apr-17 5-Nov-17 5-Jun-18 5-Jan-19 5-Aug-19 5-Mar-20 5-Oct-20 5-May-21 5-Dec-21 5-Jul-22 5-Feb-23 5-Sep-23 5-Apr-24 5-Nov-24 5-Jun-25 5-Aug-26 5-Sep-16 5-Apr-17 5-Jun-18 5-Jan-19 5-Aug-19 5-Mar-20 5-Oct-20 5-May-21 5-Dec-21 5-Jul-22 5-Feb-23 5-Sep-23 5-Apr-24 5-Nov-24 5-Jun-25 5-Jan-26 5-Aug-26<br>4-Sep-06 4-Sep-07 4-Sep-08 4-Sep-09 4-Sep-10 4-Sep-12 4-Sep-13 4-Sep-15 4-Sep-16 4-Sep-17 4-Sep-18 4-Sep-19 4-Sep-20 4-Sep-21 4-Sep-22 4-Sep-23 4-Sep-24 4-Sep-25 4-Sep-26 4-Sep-06 4-Sep-07 4-Sep-08 4-Sep-10 4-Sep-11 4-Sep-13 4-Sep-14 4-Sep-15 4-Sep-16 4-Sep-17 4-Sep-18 4-Sep-19 4-Sep-20 4-Sep-21 4-Sep-22 4-Sep-24 4-Sep-25<br>5-Aug-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 10-Aug-26 11-Aug-26 12-Aug-26 13-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 19-Aug-26 20-Aug-26 21-Aug-26 22-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 28-Aug-26 29-Aug-26 30-Aug-26 31-Aug-26 1-Sep-26 2-Sep-26<br>5-Aug-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 10-Aug-26 11-Aug-26 12-Aug-26 13-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 19-Aug-26 20-Aug-26 21-Aug-26 22-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 28-Aug-26 29-Aug-26 30-Aug-26 31-Aug-26 1-Sep-26 2-Sep-26<br><!-- End of picture text -->

Deutsche Bank AG 

Page 11 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 22: 1m FX-adjusted (into €) performance - Profitable 

###### Figure 23: 1m FX-adjusted (into €) performance - Non - profitable 



<!-- Start of picture text -->
110<br>100<br>90<br>80<br>70<br>60<br>50<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>5-Aug-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 10-Aug-26 11-Aug-26 12-Aug-26 13-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 19-Aug-26 20-Aug-26 21-Aug-26 22-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 28-Aug-26 29-Aug-26 30-Aug-26 31-Aug-26 1-Sep-26 2-Sep-26<br><!-- End of picture text -->



<!-- Start of picture text -->
350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>ARGX BNTX CVAC IDIA<br>MRNA MOR SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 25: 3m FX-adjusted (into $) performance - Non -<br>Profitable<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 27: 3m FX-adjusted (into €) performance - Non -<br>profitable<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>15-Jul-26 28-Aug-26<br>5-Aug-26 6-Aug-26 7-Aug-26 8-Aug-26 9-Aug-26 10-Aug-26 11-Aug-26 12-Aug-26 13-Aug-26 14-Aug-26 15-Aug-26 16-Aug-26 17-Aug-26 18-Aug-26 19-Aug-26 20-Aug-26 21-Aug-26 22-Aug-26 23-Aug-26 24-Aug-26 25-Aug-26 26-Aug-26 27-Aug-26 28-Aug-26 29-Aug-26 30-Aug-26 31-Aug-26 1-Sep-26 2-Sep-26<br>5-Jun-26 9-Jun-26 13-Jun-26 17-Jun-26 21-Jun-26 25-Jun-26 29-Jun-26 3-Jul-26 7-Jul-26 11-Jul-26 19-Jul-26 23-Jul-26 27-Jul-26 31-Jul-26 4-Aug-26 8-Aug-26 12-Aug-26 16-Aug-26 20-Aug-26 24-Aug-26 1-Sep-26<br>5-Jun-26 9-Jun-26 13-Jun-26 17-Jun-26 21-Jun-26 25-Jun-26 29-Jun-26 3-Jul-26 7-Jul-26 11-Jul-26 15-Jul-26 19-Jul-26 23-Jul-26 27-Jul-26 31-Jul-26 4-Aug-26 8-Aug-26 12-Aug-26 16-Aug-26 20-Aug-26 24-Aug-26 28-Aug-26 1-Sep-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Company share price performance - 3 months (SMID Cap) 

Figure 24: 3m FX-adjusted (into $) performance - profitable 



<!-- Start of picture text -->
150<br>135<br>120<br>105<br>90<br>75<br>60<br>45<br>30<br>15<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 26: 3m FX-adjusted (into €) performance - profitable<br>135<br>120<br>105<br>90<br>75<br>60<br>45<br>30<br>15<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>5-Jun-26 9-Jun-26 13-Jun-26 17-Jun-26 21-Jun-26 25-Jun-26 29-Jun-26 3-Jul-26 7-Jul-26 11-Jul-26 15-Jul-26 19-Jul-26 23-Jul-26 27-Jul-26 31-Jul-26 4-Aug-26 8-Aug-26 12-Aug-26 16-Aug-26 20-Aug-26 24-Aug-26 28-Aug-26 1-Sep-26<br>5-Jun-26 9-Jun-26 13-Jun-26 17-Jun-26 21-Jun-26 25-Jun-26 29-Jun-26 3-Jul-26 7-Jul-26 11-Jul-26 15-Jul-26 19-Jul-26 23-Jul-26 27-Jul-26 31-Jul-26 4-Aug-26 8-Aug-26 12-Aug-26 16-Aug-26 20-Aug-26 24-Aug-26 28-Aug-26 1-Sep-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 12 

Deutsche Bank AG 

#### This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Company share price performance - 6 months (SMID Cap) 

Figure 28: 6m FX-adjusted (into $) performance - profitable 



<!-- Start of picture text -->
155<br>125<br>95<br>65<br>35<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 30: 6m FX-adjusted (into €) performance - profitable<br>130<br>100<br>70<br>40<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 1 year (SMID Cap)<br>Figure 32: 1yr FX-adjusted (into $) performance - profitable<br>190<br>170<br>150<br>130<br>110<br>90<br>70<br>50<br>30<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>5-Mar-26 12-Mar-26 19-Mar-26 26-Mar-26 2-Apr-26 9-Apr-26 16-Apr-26 23-Apr-26 30-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 11-Jun-26 18-Jun-26 25-Jun-26 2-Jul-26 9-Jul-26 16-Jul-26 23-Jul-26 30-Jul-26 6-Aug-26 13-Aug-26 20-Aug-26 27-Aug-26<br>5-Mar-26 12-Mar-26 19-Mar-26 26-Mar-26 2-Apr-26 9-Apr-26 16-Apr-26 23-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 11-Jun-26 25-Jun-26 2-Jul-26 9-Jul-26 16-Jul-26 23-Jul-26 30-Jul-26 13-Aug-26 20-Aug-26 27-Aug-26<br>5-Sep-25 5-Oct-25 4-Nov-25 4-Dec-25 3-Jan-26 2-Feb-26 4-Mar-26 3-Apr-26 3-May-26 2-Jun-26 2-Jul-26 1-Aug-26 31-Aug-26<br>30-Apr-26 18-Jun-26 6-Aug-26<br><!-- End of picture text -->

Company share price performance - 1 year (SMID Cap) 

Figure 29: 6m FX-adjusted (into $) performance - Non - profitable 



<!-- Start of picture text -->
360<br>320<br>280<br>240<br>200<br>160<br>120<br>80<br>40<br>0<br>ARGX BNTX IDIA MRNA MOR SXXP Index<br>5-Mar-26 12-Mar-26 19-Mar-26 26-Mar-26 2-Apr-26 9-Apr-26 16-Apr-26 23-Apr-26 30-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 11-Jun-26 18-Jun-26 25-Jun-26 2-Jul-26 9-Jul-26 16-Jul-26 23-Jul-26 30-Jul-26 6-Aug-26 13-Aug-26 20-Aug-26 27-Aug-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 31: 6m FX-adjusted (into €) performance - Non - profitable 



<!-- Start of picture text -->
360<br>320<br>280<br>240<br>200<br>160<br>120<br>80<br>40<br>0<br>ARGX BNTX IDIA MRNA MOR SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 33: 1yr FX-adjusted (into $) performance - Non -<br>profitable<br>800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>4-Dec-25 3-May-26<br>5-Mar-26 12-Mar-26 19-Mar-26 26-Mar-26 2-Apr-26 9-Apr-26 16-Apr-26 23-Apr-26 30-Apr-26 7-May-26 14-May-26 21-May-26 28-May-26 4-Jun-26 11-Jun-26 18-Jun-26 25-Jun-26 2-Jul-26 9-Jul-26 16-Jul-26 23-Jul-26 30-Jul-26 6-Aug-26 13-Aug-26 20-Aug-26 27-Aug-26<br>5-Sep-25 5-Oct-25 4-Nov-25 3-Jan-26 2-Feb-26 4-Mar-26 3-Apr-26 2-Jun-26 2-Jul-26 1-Aug-26 31-Aug-26<br><!-- End of picture text -->

Deutsche Bank AG 

Page 13 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 34: 1yr FX-adjusted (into €) performance - profitable 



<!-- Start of picture text -->
195<br>175<br>155<br>135<br>115<br>95<br>75<br>55<br>35<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 5 years (SMID Cap)<br>Figure 36: 5yr FX-adjusted (into $) performance - profitable<br>339<br>285<br>231<br>177<br>123<br>69<br>15<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 38: 5yr FX-adjusted (into €) performance - profitable<br>320<br>270<br>220<br>170<br>120<br>70<br>20<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>6-Mar-24 6-Jun-24 6-Sep-24<br>5-Sep-25 8-Oct-25 10-Nov-25 13-Dec-25 15-Jan-26 17-Feb-26 22-Mar-26 24-Apr-26 27-May-26 29-Jun-26 1-Aug-26 3-Sep-26<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br>7-Sep-21 7-Jan-22 7-May-22 7-Sep-22 7-Jan-23 7-May-23 7-Sep-23 7-Jan-24 7-May-24 7-Sep-24 7-Jan-25 7-May-25 7-Sep-25 7-Jan-26 7-May-26<br><!-- End of picture text -->

Company share price performance - 5 years (SMID Cap) 

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 35: 1yr FX-adjusted (into €) performance - Non - profitable 



<!-- Start of picture text -->
800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 37: 5yr FX-adjusted (into $) performance - not<br>profitable<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 39: 5yr FX-adjusted (into €) performance -Non-<br>profitable<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>6-Jan-25<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>6-Sep-21 6-Jan-22 6-May-22 6-Sep-22 6-Jan-23 6-May-23 6-Sep-23 6-Jan-24 6-May-24 6-Sep-24 6-May-25 6-Sep-25 6-Jan-26 6-May-26<br>7-Sep-21 7-Dec-21 7-Mar-22 7-Jun-22 7-Sep-22 7-Dec-22 7-Mar-23 7-Jun-23 7-Sep-23 7-Dec-23 7-Mar-24 7-Jun-24 7-Sep-24 7-Dec-24 7-Mar-25 7-Jun-25 7-Sep-25 7-Dec-25 7-Mar-26 7-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 14 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Company share price performance - 10 years (SMID Cap) 

###### Figure 40: 10yr FX-adjusted (into $) performance - Profitable 

Figure 41: 10yr FX-adjusted (into $) performance - Non - Profitable 



<!-- Start of picture text -->
900<br>600<br>300<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 42: 10yr FX-adjusted (into €) performance -<br>Profitable<br>1200<br>800<br>400<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Company share price performance - 20 years (SMID Cap)<br>Figure 44: 20yr FX-adjusted (into $) performance -<br>commercial SMIDs<br>1000<br>900<br>800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>6-Sep-16 6-Mar-17 6-Sep-17 6-Mar-18 6-Sep-18 6-Mar-19 6-Sep-19 6-Mar-20 6-Sep-20 6-Mar-21 6-Sep-21 6-Mar-22 6-Sep-22 6-Mar-23 6-Sep-23 6-Mar-24 6-Sep-24 6-Mar-25 6-Sep-25 6-Mar-26<br>6-Sep-16 6-Mar-17 6-Sep-17 6-Mar-18 6-Sep-18 6-Mar-19 6-Sep-19 6-Mar-20 6-Sep-20 6-Mar-21 6-Sep-21 6-Mar-22 6-Sep-22 6-Mar-23 6-Sep-23 6-Mar-24 6-Sep-24 6-Mar-25 6-Sep-25 6-Mar-26<br>5-Sep-06 5-Sep-07 5-Sep-08 5-Sep-09 5-Sep-10 5-Sep-11 5-Sep-12 5-Sep-13 5-Sep-14 5-Sep-15 5-Sep-16 5-Sep-17 5-Sep-18 5-Sep-19 5-Sep-20 5-Sep-21 5-Sep-22 5-Sep-23 5-Sep-24 5-Sep-25<br><!-- End of picture text -->



<!-- Start of picture text -->
800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 43: 10yr FX-adjusted (into €) performance - Non -<br>Profitable<br>7200<br>6400<br>5600<br>4800<br>4000<br>3200<br>2400<br>1600<br>800<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 45: 20yr FX-adjusted (into $) performance -<br>biotechs<br>9600<br>8400<br>7200<br>6000<br>4800<br>3600<br>2400<br>1200<br>0<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>6-Sep-16 6-Mar-17 6-Sep-17 6-Mar-18 6-Sep-18 6-Mar-19 6-Sep-19 6-Mar-20 6-Sep-20 6-Mar-21 6-Sep-21 6-Mar-22 6-Sep-22 6-Mar-23 6-Sep-23 6-Mar-24 6-Sep-24 6-Mar-25 6-Sep-25 6-Mar-26<br>3-Sep-15 3-Feb-16 3-Jul-16 3-Dec-16 3-May-17 3-Oct-17 3-Mar-18 3-Aug-18 3-Jan-19 3-Jun-19 3-Nov-19 3-Apr-20 3-Sep-20 3-Feb-21 3-Jul-21 3-Dec-21 3-May-22 3-Oct-22 3-Mar-23 3-Aug-23 3-Jan-24 3-Jun-24 3-Nov-24 3-Apr-25 3-Sep-25 3-Feb-26 3-Jul-26<br>23-May-17 23-May-18 23-May-19 23-May-20 23-May-21 23-May-22 23-May-23 23-May-24 23-May-25 23-May-26<br><!-- End of picture text -->

##### Company share price performance - 20 years (SMID Cap) 

Deutsche Bank AG 

Page 15 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 46: 20yr FX-adjusted (into €) performance - commercial SMIDs. 

###### Figure 47: 20yr FX-adjusted (into €) performance - biotechs 



<!-- Start of picture text -->
1200 12600<br>11200<br>9800<br>800<br>8400<br>7000<br>400 5600<br>4200<br>0 2800<br>1400<br>0<br>GMAB GRLSMC IPN<br>REC SOBI ALM<br>ARGX BNTX CVAC IDIA MRNA SXXP Index<br>LUN UCB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Index share price performance<br>Index share price performance - 1 year<br>Figure 48: Share price performance - EU Healthcare (USD) Figure 49: Share price performance - EU Healthcare (EUR)<br>129 126<br>121 118<br>113 110<br>105<br>102<br>97<br>94<br>89<br>81 86<br>73 78<br>65 70<br>SXXP Index SXDP Index SXXP Index SXDP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 50: Share price performance - US Healthcare (USD) Figure 51: Share price performance - US Healthcare (EUR)<br>162 165<br>154 155<br>146<br>138 145<br>130 135<br>122<br>114 125<br>106 115<br>98<br>90 105<br>82 95<br>74<br>66 85<br>58 75<br>50<br>65<br>NBI NYSE Pharma Index S&P 500 NBI NYSE Pharma Index S&P 500<br>27-Nov-25 5-Mar-26 11-Jun-26 11-Dec-25 19-Mar-26 25-Jun-26<br>27-Nov-25 5-Mar-26 11-Jun-26 4-Oct-25<br>5-Sep-06 5-Sep-07 5-Sep-08 5-Sep-09 5-Sep-10 5-Sep-11 5-Sep-12 5-Sep-13 5-Sep-14 5-Sep-15 5-Sep-16 5-Sep-17 5-Sep-18 5-Sep-19 5-Sep-20 5-Sep-21 5-Sep-22 5-Sep-23 5-Sep-24 5-Sep-25<br>23-May-17 23-May-18 23-May-19 23-May-20 23-May-21 23-May-22 23-May-23 23-May-24 23-May-25 23-May-26<br>4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 11-Dec-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 19-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 25-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26 4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 27-Nov-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 5-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 11-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26<br>4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 11-Dec-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 19-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 25-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26 4-Sep-25 4-Nov-25 4-Dec-25 4-Jan-26 4-Feb-26 4-Mar-26 4-Apr-26 4-May-26 4-Jun-26 4-Jul-26 4-Aug-26 4-Sep-26<br><!-- End of picture text -->



<!-- Start of picture text -->
126<br>118<br>110<br>102<br>94<br>86<br>78<br>70<br>SXXP Index SXDP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 51: Share price performance - US Healthcare (EUR)<br>165<br>155<br>145<br>135<br>125<br>115<br>105<br>95<br>85<br>75<br>65<br>NBI NYSE Pharma Index S&P 500<br>Source : Deutsche Bank, Bloomberg Finance LP<br>11-Dec-25 19-Mar-26 25-Jun-26<br>4-Oct-25<br>4-Sep-25 18-Sep-25 2-Oct-25 16-Oct-25 30-Oct-25 13-Nov-25 27-Nov-25 25-Dec-25 8-Jan-26 22-Jan-26 5-Feb-26 19-Feb-26 5-Mar-26 2-Apr-26 16-Apr-26 30-Apr-26 14-May-26 28-May-26 11-Jun-26 9-Jul-26 23-Jul-26 6-Aug-26 20-Aug-26 3-Sep-26<br>4-Sep-25 4-Nov-25 4-Dec-25 4-Jan-26 4-Feb-26 4-Mar-26 4-Apr-26 4-May-26 4-Jun-26 4-Jul-26 4-Aug-26 4-Sep-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 16 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Index share price performance - 5 years 

Figure 53: Share price performance - EU Healthcare (EUR) 

###### Figure 52: Share price performance - EU Healthcare (USD) 



<!-- Start of picture text -->
160 160<br>140 140<br>120 120<br>100 100<br>80 80<br>60 60<br>SXXP Index SXDP Index SXXP Index SXDP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 54: Share price performance - US Healthcare (USD) Figure 55: Share price performance - US Healthcare (EUR)<br>195 195<br>175<br>165<br>155<br>135 135<br>115<br>105<br>95<br>75 75<br>NBI NYSE Pharma Index S&P 500 NBI NYSE Pharma Index S&P 500<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>Index P/E vs. Dividend yield<br>Figure 56: SXDP P/E vs. SXXP P/E Figure 57: SXDP vs. SXXP Dividend Yield<br>24.0 6.0<br>21.0<br>18.0<br>15.0 3.0<br>12.0<br>9.0<br>6.0 0.0<br>SXXP Index SXDP Index SXXP Index SXDP Index<br>6-Mar-24 6-Jun-24<br>6-Mar-24 6-Jun-24<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26 6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Mar-24 6-Jun-24 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26 6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Mar-24 6-Jun-24 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br>1-Jul-16 1-Jul-17 1-Jul-18 1-Jul-19 1-Jul-20 1-Jul-21 1-Jul-22 1-Jul-23 1-Jul-24 1-Jul-25 1-Jul-26 1-Jul-16 1-Jul-17 1-Jul-18 1-Jul-19 1-Jul-20 1-Jul-21 1-Jul-22 1-Jul-23 1-Jul-24 1-Jul-25 1-Jul-26<br><!-- End of picture text -->



<!-- Start of picture text -->
160<br>140<br>120<br>100<br>80<br>60<br>SXXP Index SXDP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 55: Share price performance - US Healthcare (EUR)<br>195<br>175<br>155<br>135<br>115<br>95<br>75<br>NBI NYSE Pharma Index S&P 500<br>Source : Deutsche Bank, Bloomberg Finance LP<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Mar-24 6-Jun-24 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br>6-Sep-21 6-Dec-21 6-Mar-22 6-Jun-22 6-Sep-22 6-Dec-22 6-Mar-23 6-Jun-23 6-Sep-23 6-Dec-23 6-Mar-24 6-Jun-24 6-Sep-24 6-Dec-24 6-Mar-25 6-Jun-25 6-Sep-25 6-Dec-25 6-Mar-26 6-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 17 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 58: DRG/NBI PE vs. SPX P/E 



<!-- Start of picture text -->
4,000.0<br>3,000.0<br>2,000.0<br>1,000.0<br>0.0<br>NBI Index DRG Index SPX Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 60: SXDP Index vs Other Index P/E<br>42.0<br>37.0<br>32.0<br>27.0<br>22.0<br>17.0<br>12.0<br>7.0<br>SXXP Index SXDP Index SPX Index<br>INDU Index UKX Index NKY Index<br>1-Jul-24 1-Jan-25<br>3-Sep-15 3-Sep-16 3-Sep-18 3-Sep-19 3-Sep-20 3-Sep-21 3-Sep-22 3-Sep-23 3-Sep-24 3-Sep-25 3-Sep-26<br>1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-25 1-Jan-26 1-Jul-26<br>3-Sep-17<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 59: DRG/NBI P/E vs. SPX Dividend Yield 



<!-- Start of picture text -->
5.0<br>4.0<br>3.0<br>2.0<br>1.0<br>0.0<br>NBI Index DRG Index SPX Index<br>1-Jul-16 1-Jul-17 1-Jul-18 1-Jul-19 1-Jul-20 1-Jul-21 1-Jul-22 1-Jul-23 1-Jul-24 1-Jul-25 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 61: SXDP Index vs Other Index Dividend Yield 



<!-- Start of picture text -->
8.0<br>6.0<br>4.0<br>2.0<br>0.0<br>SXXP Index SXDP Index SPX Index<br>INDU Index UKX Index NKY Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br><!-- End of picture text -->

Page 18 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

## Relative valuation performance 

#### P/E performance - sector 

Figure 62: Absolute P/E 1 yr fwd - EU HC and EU Market 



<!-- Start of picture text -->
27<br>24<br>21<br>18<br>15<br>12<br>9<br>6<br>EU Healthcare (SXDP Index) EU Market (SXXP Index)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 64: Relative P/E performance (rebased to 10 years<br>back)<br>140<br>110<br>80<br>50<br>EU Market (SXXP Index) EU Healthcare (SXDP Index)<br>31-Dec-15 13-Jul-16 24-Jan-17 7-Aug-17 18-Feb-18 1-Sep-18 15-Mar-19 26-Sep-19 8-Apr-20 20-Oct-20 3-May-21 14-Nov-21 28-May-22 9-Dec-22 22-Jun-23 3-Jan-24 16-Jul-24 27-Jan-25 10-Aug-25 21-Feb-26 4-Sep-26<br>31-Dec-15 30-Jun-16 31-Dec-16 30-Jun-17 31-Dec-17 30-Jun-18 31-Dec-18 30-Jun-19 31-Dec-19 30-Jun-20 31-Dec-20 30-Jun-21 31-Dec-21 30-Jun-22 31-Dec-22 30-Jun-23 31-Dec-23 30-Jun-24 31-Dec-24 30-Jun-25 31-Dec-25 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 63: EU HC P/E 1 yr fwd relative to EU Market 



<!-- Start of picture text -->
60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>EU HC (SXDP) relative to EU Market (SXXP)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 65: EU HC P/E 1yr fwd relative to EU Utilities<br>75%<br>60%<br>45%<br>30%<br>15%<br>0%<br>-15%<br>EU HC (SXDP) relative to EU Utilities (SX6P)<br>14-Jan-19 22-Jul-20 28-Jan-22<br>30-Jun-20 31-Dec-21 30-Jun-22 31-Dec-23<br>31-Dec-15 3-Jul-16 4-Jan-17 8-Jul-17 9-Jan-18 13-Jul-18 18-Jul-19 19-Jan-20 23-Jan-21 27-Jul-21 1-Aug-22 2-Feb-23 6-Aug-23 7-Feb-24 10-Aug-24 11-Feb-25 15-Aug-25 16-Feb-26 20-Aug-26<br>31-Dec-15 30-Jun-16 31-Dec-16 30-Jun-17 31-Dec-17 30-Jun-18 31-Dec-18 30-Jun-19 31-Dec-19 31-Dec-20 30-Jun-21 31-Dec-22 30-Jun-23 30-Jun-24 31-Dec-24 30-Jun-25 31-Dec-25 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 19 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

Figure 66: EU HC P/E 1yr fwd relative to EU HPC (personal and household goods) 



<!-- Start of picture text -->
30%<br>20%<br>10%<br>0%<br>-10%<br>-20%<br>-30%<br>-40%<br>EU HC (SXDP) relative to EU HPC (SXQP)<br>31-Dec-15 30-Jun-16 31-Dec-16 30-Jun-17 31-Dec-17 30-Jun-18 31-Dec-18 30-Jun-19 31-Dec-19 30-Jun-20 31-Dec-20 30-Jun-21 31-Dec-21 30-Jun-22 31-Dec-22 30-Jun-23 31-Dec-23 30-Jun-24 31-Dec-24 30-Jun-25 31-Dec-25 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 67: EU HC P/E 1yr fwd relative to EU Food + Beverages 



<!-- Start of picture text -->
10%<br>0%<br>-10%<br>-20%<br>-30%<br>-40%<br>EU HC (SXDP) relative to EU Food + Beverage (SX3P)<br>31-Dec-15 30-Jun-16 31-Dec-16 30-Jun-17 31-Dec-17 30-Jun-18 31-Dec-18 30-Jun-19 31-Dec-19 30-Jun-20 31-Dec-20 30-Jun-21 31-Dec-21 30-Jun-22 31-Dec-22 30-Jun-23 31-Dec-23 30-Jun-24 31-Dec-24 30-Jun-25 31-Dec-25 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 20 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### P/E performance - individual stocks 

###### Figure 68: AstraZeneca - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
25<br>20<br>15<br>10<br>5<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 70: GlaxoSmithKline - Absolute P/E 1 yr fwd<br>17<br>15<br>13<br>11<br>9<br>7<br>5<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 72: Novartis - Absolute P/E 1 yr fwd<br>18<br>16<br>15<br>13<br>12<br>10<br>9<br>7<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>1-Jan-16 1-Mar-17 1-Oct-17 1-Dec-18 1-Sep-20 1-Nov-21 1-Jun-22 1-Aug-23 1-Oct-24 1-May-25 1-Jul-26<br>1-Jan-16 1-Aug-16 1-Mar-17 1-Oct-17 1-May-18 1-Dec-18 1-Jul-19 1-Feb-20 1-Sep-20 1-Apr-21 1-Nov-21 1-Jun-22 1-Jan-23 1-Aug-23 1-Mar-24 1-Oct-24 1-May-25 1-Dec-25 1-Jul-26<br>1-Jan-16 1-Aug-16 1-Mar-17 1-Oct-17 1-May-18 1-Dec-18 1-Jul-19 1-Feb-20 1-Sep-20 1-Apr-21 1-Nov-21 1-Jun-22 1-Jan-23 1-Aug-23 1-Mar-24 1-Oct-24 1-May-25 1-Dec-25 1-Jul-26<br>1-Aug-16 1-May-18 1-Jul-19 1-Feb-20 1-Apr-21 1-Jan-23 1-Mar-24 1-Dec-25<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 69: AstraZeneca - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
80%<br>60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 71: GlaxoSmithKline - P/E relative to market (SXXP)<br>and Healthcare (SXDP)<br>30%<br>15%<br>0%<br>-15%<br>-30%<br>-45%<br>-60%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 73: Novartis - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>30%<br>20%<br>10%<br>0%<br>-10%<br>-20%<br>-30%<br>-40%<br>-50%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>1-Jan-16 1-Jun-16 1-Nov-16 1-Apr-17 1-Sep-17 1-Feb-18 1-Dec-18 1-Mar-20 1-Jun-21 1-Nov-21 1-Apr-22 1-Sep-22 1-Feb-23 1-Jul-23 1-Dec-23 1-Oct-24 1-Jun-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jul-18 1-May-19 1-Oct-19 1-Aug-20 1-Jan-21 1-May-24 1-Mar-25 1-Aug-25 1-Jan-26<br>1-Jan-16 1-Jun-16 1-Nov-16 1-Apr-17 1-Sep-17 1-Feb-18 1-Jul-18 1-Dec-18 1-May-19 1-Oct-19 1-Mar-20 1-Aug-20 1-Jan-21 1-Jun-21 1-Nov-21 1-Apr-22 1-Sep-22 1-Feb-23 1-Jul-23 1-Dec-23 1-May-24 1-Oct-24 1-Mar-25 1-Aug-25 1-Jan-26 1-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 21 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 74: Novo Nordisk - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
45<br>40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 76: Roche - Absolute P/E 1 yr fwd<br>20<br>18<br>16<br>14<br>12<br>10<br>8<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 78: Sanofi - Absolute P/E 1 yr fwd<br>18<br>16<br>14<br>12<br>10<br>8<br>6<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>1-Jan-16 1-Aug-16 1-Mar-17 1-Oct-17 1-May-18 1-Dec-18 1-Jul-19 1-Feb-20 1-Sep-20 1-Apr-21 1-Nov-21 1-Jun-22 1-Jan-23 1-Aug-23 1-Mar-24 1-Oct-24 1-May-25 1-Dec-25 1-Jul-26<br>1-Jan-16 1-Aug-16 1-Mar-17 1-Oct-17 1-May-18 1-Dec-18 1-Jul-19 1-Feb-20 1-Sep-20 1-Apr-21 1-Nov-21 1-Jun-22 1-Jan-23 1-Aug-23 1-Mar-24 1-Oct-24 1-May-25 1-Dec-25 1-Jul-26<br>1-Jan-16 1-Aug-16 1-Mar-17 1-Oct-17 1-May-18 1-Dec-18 1-Jul-19 1-Feb-20 1-Sep-20 1-Apr-21 1-Nov-21 1-Jun-22 1-Jan-23 1-Aug-23 1-Mar-24 1-Oct-24 1-May-25 1-Dec-25 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 75: Novo Nordisk - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
250%<br>200%<br>150%<br>100%<br>50%<br>0%<br>-50%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 77: Roche - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 79: Sanofi - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>15%<br>4%<br>-7%<br>-18%<br>-29%<br>-40%<br>-51%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jan-16 1-Jun-16 1-Nov-16 1-Apr-17 1-Sep-17 1-Feb-18 1-Jul-18 1-Dec-18 1-May-19 1-Oct-19 1-Mar-20 1-Aug-20 1-Jan-21 1-Jun-21 1-Nov-21 1-Apr-22 1-Sep-22 1-Feb-23 1-Jul-23 1-Dec-23 1-May-24 1-Oct-24 1-Mar-25 1-Aug-25 1-Jan-26 1-Jun-26<br>1-Jan-16 1-Jun-16 1-Nov-16 1-Apr-17 1-Sep-17 1-Feb-18 1-Jul-18 1-Dec-18 1-May-19 1-Oct-19 1-Mar-20 1-Aug-20 1-Jan-21 1-Jun-21 1-Nov-21 1-Apr-22 1-Sep-22 1-Feb-23 1-Jul-23 1-Dec-23 1-May-24 1-Oct-24 1-Mar-25 1-Aug-25 1-Jan-26 1-Jun-26<br><!-- End of picture text -->

Page 22 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 80: Genmab - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
200<br>160<br>120<br>80<br>40<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 82: Grifols - Absolute P/E 1 yr fwd<br>29<br>25<br>21<br>17<br>13<br>9<br>5<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 84: Ipsen - Absolute P/E 1 yr fwd<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jul-16 1-Jan-17 1-Jan-19 1-Jul-21 1-Jan-22 1-Jan-24 1-Jul-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-23 1-Jul-23 1-Jan-24<br>1-Jan-16 1-Jul-17 1-Jan-18 1-Jul-18 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-22 1-Jan-23 1-Jul-23 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 81: Genmab - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
400%<br>350%<br>300%<br>250%<br>200%<br>150%<br>100%<br>50%<br>0%<br>-50%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>3-Sep-18 3-Jan-19 3-May-19 3-Sep-19 3-Jan-20 3-May-20 3-Sep-20 3-Jan-21 3-May-21 3-Sep-21 3-Jan-22 3-May-22 3-Sep-22 3-Jan-23 3-May-23 3-Sep-23 3-Jan-24 3-May-24 3-Sep-24 3-Jan-25 3-May-25 3-Sep-25 3-Jan-26 3-May-26 3-Sep-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 83: Grifols - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
120%<br>90%<br>60%<br>30%<br>0%<br>-30%<br>-60%<br>-90%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 85: Ipsen - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>160%<br>120%<br>80%<br>40%<br>0%<br>-40%<br>-80%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>1-Jan-16 1-Jul-16 1-Jul-17 1-Jan-18 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-22 1-Jan-23 1-Jul-24 1-Jul-25 1-Jan-26<br>27-Jan-18 27-Aug-18 27-Mar-19 27-Oct-19 27-May-20 27-Dec-20 27-Jul-21 27-Feb-22 27-Sep-22 27-Apr-23 27-Nov-23 27-Jun-24 27-Jan-25 27-Aug-25 27-Mar-26<br>1-Jan-17 1-Jul-18 1-Jan-19 1-Jul-21 1-Jan-22 1-Jul-23 1-Jan-24 1-Jan-25 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 23 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 86: Lundbeck - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
30<br>25<br>20<br>15<br>10<br>5<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note absolute P/E 1 yr fwd increased to c4000 in 15/16, however have formatted the y-axis to<br>highlight 10-year historical trend<br>Figure 88: SOBI - Absolute P/E 1 yr fwd<br>24<br>22<br>20<br>18<br>16<br>14<br>12<br>10<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 90: UCB - Absolute P/E 1 yr fwd<br>35<br>30<br>25<br>20<br>15<br>10<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>3-Jan-18 3-Jul-18 3-Jan-19 3-Jul-19 3-Jan-20 3-Jul-20 3-Jan-21 3-Jul-21 3-Jan-22 3-Jul-22 3-Jan-23 3-Jul-23 3-Jan-24 3-Jul-24 3-Jan-25 3-Jul-25 3-Jan-26 3-Jul-26<br>27-Jan-18 27-Apr-18 27-Jul-18 27-Oct-18 27-Jan-19 27-Apr-19 27-Jul-19 27-Oct-19 27-Jan-20 27-Apr-20 27-Jul-20 27-Oct-20 27-Jan-21 27-Apr-21 27-Jul-21 27-Oct-21 27-Jan-22 27-Apr-22 27-Jul-22 27-Oct-22 27-Jan-23 27-Apr-23 27-Jul-23 27-Oct-23 27-Jan-24 27-Apr-24 27-Jul-24 27-Oct-24 27-Jan-25 27-Apr-25 27-Jul-25 27-Oct-25 27-Jan-26 27-Apr-26 27-Jul-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 87: Lundbeck - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
70%<br>50%<br>30%<br>10%<br>-10%<br>-30%<br>-50%<br>-70%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note P/E increased significantly in 15/16, however have formatted the y-axis to highlight 10-year<br>historical trend<br>Figure 89: SOBI - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>85%<br>58%<br>31%<br>4%<br>-23%<br>-50%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 91: UCB - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>160%<br>120%<br>80%<br>40%<br>0%<br>-40%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>3-Jan-18 3-Jul-18 3-Jan-19 3-Jul-19 3-Jan-20 3-Jul-20 3-Jan-21 3-Jul-21 3-Jan-22 3-Jul-22 3-Jan-23 3-Jul-23 3-Jan-24 3-Jul-24 3-Jan-25 3-Jul-25 3-Jan-26 3-Jul-26<br>27-Jan-18 27-Apr-18 27-Jul-18 27-Oct-18 27-Jan-19 27-Apr-19 27-Jul-19 27-Oct-19 27-Jan-20 27-Apr-20 27-Jul-20 27-Oct-20 27-Jan-21 27-Apr-21 27-Jul-21 27-Oct-21 27-Jan-22 27-Apr-22 27-Jul-22 27-Oct-22 27-Jan-23 27-Apr-23 27-Jul-23 27-Oct-23 27-Jan-24 27-Apr-24 27-Jul-24 27-Oct-24 27-Jan-25 27-Apr-25 27-Jul-25 27-Oct-25 27-Jan-26 27-Apr-26 27-Jul-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 24 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 92: Almirall - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
30<br>25<br>20<br>15<br>10<br>5<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 94: Recordati - Absolute P/E 1 yr fwd<br>30<br>25<br>20<br>15<br>10<br>5<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 96: BioNTech - Absolute P/E 1 yr fwd 



<!-- Start of picture text -->
2,000<br>1,800<br>1,600<br>1,400<br>1,200<br>1,000<br>800<br>600<br>400<br>200<br>0<br>Absolute PE 1yr fwd Avg +1 sd -1 sd<br>Source : Deutsche Bank, Bloomberg Finance LP<br>27-Oct-21 27-Dec-21 27-Feb-22 27-Apr-22 27-Jun-22 27-Aug-22 27-Oct-22 27-Dec-22 27-Feb-23 27-Apr-23 27-Jun-23 27-Aug-23 27-Oct-23 27-Dec-23 27-Feb-24 27-Apr-24 27-Jun-24 27-Aug-24 27-Oct-24 27-Dec-24 27-Feb-25 27-Apr-25 27-Jun-25 27-Aug-25 27-Oct-25 27-Dec-25 27-Feb-26 27-Apr-26 27-Jun-26 27-Aug-26<br><!-- End of picture text -->

Figure 93: Almirall - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
120%<br>80%<br>40%<br>0%<br>-40%<br>-80%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 95: Recordati - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>90%<br>60%<br>30%<br>0%<br>-30%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 97: BioNTech - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>620%<br>520%<br>420%<br>320%<br>220%<br>120%<br>20%<br>-80%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>1-Jan-16 1-Jul-16 1-Jan-17 1-Jul-17 1-Jan-18 1-Jul-18 1-Jan-19 1-Jul-19 1-Jan-20 1-Jul-20 1-Jan-21 1-Jul-21 1-Jan-22 1-Jul-22 1-Jan-23 1-Jul-23 1-Jan-24 1-Jul-24 1-Jan-25 1-Jul-25 1-Jan-26 1-Jul-26<br>27-Oct-21 27-Dec-21 27-Feb-22 27-Apr-22 27-Jun-22 27-Aug-22 27-Oct-22 27-Dec-22 27-Feb-23 27-Apr-23 27-Jun-23 27-Aug-23 27-Oct-23 27-Dec-23 27-Feb-24 27-Apr-24 27-Jun-24 27-Aug-24<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 25 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 98: CureVac - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
7000%<br>6000%<br>5000%<br>4000%<br>3000%<br>2000%<br>1000%<br>0%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 100: Sandoz - P/E relative to market (SXXP) and<br>Healthcare (SXDP)<br>45%<br>40%<br>35%<br>30%<br>25%<br>20%<br>15%<br>10%<br>5%<br>0%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>27-Oct-21 27-Jan-22 27-Apr-22 27-Jul-22 27-Oct-22 27-Jan-23 27-Apr-23 27-Jul-23 27-Oct-23 27-Jan-24 27-Apr-24 27-Jul-24 27-Oct-24 27-Jan-25 27-Apr-25 27-Jul-25 27-Oct-25 27-Jan-26 27-Apr-26 27-Jul-26<br>1-Jan-26 15-Jan-26 29-Jan-26 12-Feb-26 26-Feb-26 12-Mar-26 26-Mar-26 9-Apr-26 23-Apr-26 7-May-26 21-May-26 4-Jun-26 18-Jun-26 2-Jul-26 16-Jul-26 30-Jul-26 13-Aug-26 27-Aug-26<br><!-- End of picture text -->

Figure 99: Moderna - P/E relative to market (SXXP) and Healthcare (SXDP) 



<!-- Start of picture text -->
9920%<br>7920%<br>5920%<br>3920%<br>1920%<br>-80%<br>PE relative to SXXP PE relative to SXDP<br>Avg relative to SXXP Avg relative to SXDP<br>27-Feb-23 27-Apr-23 27-Jun-23 27-Aug-23 27-Oct-23 27-Dec-23 27-Feb-24 27-Apr-24 27-Jun-24 27-Aug-24 27-Oct-24 27-Dec-24 27-Feb-25 27-Apr-25 27-Jun-25 27-Aug-25 27-Oct-25 27-Dec-25 27-Feb-26 27-Apr-26 27-Jun-26 27-Aug-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 26 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Price vs. EPS - individual stocks 

###### Figure 101: AstraZeneca price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
12.2 17,500<br>11.2 15,500<br>10.2<br>9.2 13,500<br>8.2 11,500<br>7.2 9,500<br>6.25.2 7,500<br>4.2 5,500<br>3.2 3,500<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 103: Novartis price vs. consensus 12m forward EPS<br>10.0 145<br>9.5 135<br>9.0<br>125<br>8.5<br>8.0 115<br>7.5 105<br>7.0 95<br>6.5 85<br>6.0<br>75<br>5.5<br>5.0 65<br>4.5 55<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 105: Roche price vs. consensus 12m forward EPS<br>30.0 470<br>28.0 440<br>26.0 410<br>24.0 380<br>350<br>22.0<br>320<br>20.0 290<br>18.0 260<br>16.0 230<br>14.0 200<br>12m forward EPS Price (RHS)<br>31-Mar-22 30-Sep-23 30-Sep-25 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-23 30-Sep-23 31-Mar-24 31-Dec-24 30-Jun-25 30-Jun-26<br>30-Sep-21 31-Mar-22 31-Dec-22<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 31-Dec-25 31-Mar-26<br>30-Jun-21 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 31-Dec-23 30-Jun-24 30-Sep-24 31-Mar-25 30-Sep-25 31-Dec-25 31-Mar-26<br>31-Dec-20 31-Mar-21 30-Jun-21 31-Dec-21 30-Jun-22 30-Sep-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 102: GlaxoSmithKline price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
2.0 2,450<br>1.8 2,300<br>1.6 2,150<br>1.4 2,000<br>1.2<br>1,850<br>1.0<br>0.8 1,700<br>0.6 1,550<br>0.4 1,400<br>0.2 1,250<br>0.0 1,100<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 104: Novo Nordisk price vs. consensus 12m<br>forward EPS<br>31.0 1140<br>1040<br>26.0 940<br>840<br>21.0 740<br>640<br>16.0 540<br>440<br>11.0 340<br>240<br>6.0 140<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 106: Sanofi price vs. consensus 12m forward EPS<br>9.3 120<br>8.8 110<br>8.3<br>7.8 100<br>7.3 90<br>6.8 80<br>6.3<br>5.8 70<br>5.3 60<br>12m forward EPS Price (RHS)<br>30-Sep-21 31-Dec-21 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Mar-25 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 31-Mar-22 30-Sep-22 31-Dec-22 30-Jun-23 30-Jun-24 31-Dec-24 31-Mar-25 30-Sep-25 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 31-Mar-22 30-Jun-23 30-Sep-23 31-Dec-23 31-Dec-24 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26<br>30-Sep-21 31-Dec-21 30-Jun-22 31-Mar-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Sep-24 30-Jun-25 31-Dec-25 31-Mar-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 27 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 107: Genmab price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
18.0 3,500<br>16.0 3,000<br>14.0<br>2,500<br>12.0<br>10.0 2,000<br>8.0 1,500<br>6.0<br>1,000<br>4.0<br>2.0 500<br>0.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 109: Ipsen price vs. consensus 12m forward EPS<br>9.0 180<br>8.0 150<br>7.0 120<br>6.0 90<br>5.0 60<br>4.0 30<br>3.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 111: SOBI price vs. consensus 12m forward EPS<br>27.0 550<br>24.0 500<br>21.0 450<br>18.0 400<br>350<br>15.0<br>300<br>12.0<br>250<br>9.0 200<br>6.0 150<br>3.0 100<br>0.0 50<br>12m forward EPS Price (RHS)<br>30-Sep-21 31-Dec-21 31-Dec-22 31-Dec-23 30-Sep-24 31-Dec-24 31-Dec-25<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Mar-24 30-Jun-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Mar-26 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 108: Grifols price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
1.2 35<br>1.2<br>30<br>1.1<br>1.1 25<br>1.0 20<br>1.0<br>0.9 15<br>0.9 10<br>0.8<br>5<br>0.8<br>0.7 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 110: Lundbeck price vs. consensus 12m forward<br>EPS<br>8.0 60<br>50<br>40<br>4.0 30<br>20<br>10<br>0.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 112: UCB price vs. consensus 12m forward EPS<br>14.0 340<br>12.0 290<br>10.0<br>240<br>8.0<br>190<br>6.0<br>140<br>4.0<br>2.0 90<br>0.0 40<br>12m forward EPS Price (RHS)<br>30-Jun-21 30-Sep-21 30-Jun-22 31-Dec-22 31-Mar-23 30-Jun-23 31-Dec-23 31-Mar-24 30-Sep-24 30-Jun-25 30-Sep-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 31-Dec-25<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 31-Dec-21 31-Mar-22 30-Sep-22 30-Sep-23 30-Jun-24 31-Dec-24 31-Mar-25 31-Dec-25<br>30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Mar-26 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 28 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 113: Argenx price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
40.0 1000<br>900<br>30.0<br>800<br>20.0 700<br>10.0 600<br>500<br>0.0 400<br>-10.0 300<br>200<br>-20.0<br>100<br>-30.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 115: Almirall price vs. consensus 12m forward EPS<br>15.0 210<br>13.5<br>180<br>12.0<br>10.5 150<br>9.0 120<br>7.5<br>6.0 90<br>4.5 60<br>3.0<br>30<br>1.5<br>0.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 117: BioNTech price vs. consensus 12m forward<br>EPS<br>45.0 480<br>36.0 400<br>27.0 320<br>18.0 240<br>9.0 160<br>0.0 80<br>-9.0 0<br>12m forward EPS Price (RHS)<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Mar-22 30-Sep-22 31-Dec-22 30-Jun-23 31-Dec-23 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Mar-26<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>27-Jan-21 27-Mar-21 27-May-21 27-Jul-21 27-Sep-21 27-Nov-21 27-Jan-22 27-Mar-22 27-May-22 27-Jul-22 27-Sep-22 27-Nov-22 27-Jan-23 27-Mar-23 27-May-23 27-Jul-23 27-Sep-23 27-Nov-23 27-Jan-24 27-Mar-24 27-May-24 27-Jul-24 27-Sep-24 27-Nov-24 27-Jan-25 27-Mar-25 27-May-25 27-Jul-25 27-Sep-25 27-Nov-25 27-Jan-26 27-Mar-26 27-May-26 27-Jul-26<br>31-Dec-21 30-Jun-22 31-Mar-23 30-Sep-23 31-Mar-24 31-Dec-25 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 114: Galapagos price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
0.0 100<br>-0.5 90<br>-1.0 80<br>-1.5 70<br>-2.0 60<br>-2.5 50<br>-3.0 40<br>-3.5 30<br>-4.0 20<br>-4.5 10<br>-5.0 0<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 116: Recordati price vs. consensus 12m forward<br>EPS<br>4.0 65<br>3.5 60<br>3.0 55<br>50<br>2.5<br>45<br>2.0<br>40<br>1.5<br>35<br>1.0 30<br>0.5 25<br>0.0 20<br>12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 118: CureVac price vs. consensus 12m forward EPS<br>4.5 150<br>3.0 120<br>1.5 90<br>0.0 60<br>-1.5 30<br>-3.0 0<br>12m forward EPS Price (RHS)<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Dec-25 31-Mar-26 30-Jun-26<br>31-Dec-20 31-Mar-21 30-Jun-21 30-Sep-21 31-Dec-21 31-Mar-22 30-Jun-22 30-Sep-22 31-Dec-22 31-Mar-23 30-Jun-23 30-Sep-23 31-Dec-23 31-Mar-24 30-Jun-24 31-Dec-25<br>27-Jan-21 27-Mar-21 27-May-21 27-Jul-21 27-Sep-21 27-Nov-21 27-Jan-22 27-Mar-22 27-May-22 27-Jul-22 27-Sep-22 27-Nov-22 27-Jan-23 27-Mar-23 27-May-23 27-Jul-23 27-Sep-23 27-Nov-23 27-Jan-24 27-Mar-24 27-May-24 27-Jul-24 27-Sep-24 27-Nov-24 27-Jan-25 27-Mar-25 27-May-25 27-Jul-25 27-Sep-25 27-Nov-25 27-Jan-26 27-Mar-26 27-May-26 27-Jul-26<br>30-Sep-24 31-Dec-24 31-Mar-25 30-Jun-25 30-Sep-25 31-Mar-26 30-Jun-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 29 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 119: Moderna price vs. consensus 12m forward EPS 

Figure 120: Sandoz price vs. consensus 12m forward EPS 



<!-- Start of picture text -->
36.0 600 5.0 80<br>30.0 4.5 70<br>500 4.0<br>24.0 60<br>400 3.5<br>18.0 3.0 50<br>12.0 300 2.5 40<br>6.0 200 2.0 30<br>1.5<br>0.0 20<br>100 1.0<br>-6.0 0.5 10<br>-12.0 0 0.0 0<br>12m forward EPS Price (RHS) 12m forward EPS Price (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>27-Jan-21 27-Mar-21 27-May-21 27-Jul-21 27-Sep-21 27-Nov-21 27-Jan-22 27-Mar-22 27-May-22 27-Jul-22 27-Sep-22 27-Nov-22 27-Jan-23 27-Mar-23 27-May-23 27-Jul-23 27-Sep-23 27-Nov-23 27-Jan-24 27-Mar-24 27-May-24 27-Jul-24 27-Sep-24 27-Nov-24 27-Jan-25 27-Mar-25 27-May-25 27-Jul-25 27-Sep-25 27-Nov-25 27-Jan-26 27-Mar-26 27-May-26 27-Jul-26 10-Oct-23 10-Dec-23 10-Feb-24 10-Apr-24 10-Jun-24 10-Aug-24 10-Oct-24 10-Dec-24 10-Feb-25 10-Apr-25 10-Jun-25 10-Aug-25 10-Oct-25 10-Dec-25 10-Feb-26 10-Apr-26 10-Jun-26 10-Aug-26<br><!-- End of picture text -->

Page 30 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### P/E - Individual stocks 

###### Figure 121: AstraZeneca P/E vs. SXXP P/E 



<!-- Start of picture text -->
25.0<br>20.0<br>15.0<br>10.0<br>5.0<br>AZN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 123: Novartis P/E vs. SXXP P/E<br>20.0<br>18.0<br>16.0<br>14.0<br>12.0<br>10.0<br>8.0<br>NOVN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 125: Roche P/E vs. SXXP P/E<br>19.0<br>16.0<br>13.0<br>10.0<br>ROG SXXP Index<br>9-Nov-22<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

###### Figure 122: GlaxoSmithKline P/E vs. SXXP /PE 



<!-- Start of picture text -->
19.0<br>17.0<br>15.0<br>13.0<br>11.0<br>9.0<br>7.0<br>5.0<br>GSK SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 124: Novo Nordisk P/E vs. SXXP P/E<br>41.0<br>37.0<br>33.0<br>29.0<br>25.0<br>21.0<br>17.0<br>13.0<br>9.0<br>NOVOB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 126: Sanofi P/E vs. SXXP P/E<br>19.0<br>17.0<br>15.0<br>13.0<br>11.0<br>9.0<br>7.0<br>SAN SXXP Index<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Deutsche Bank AG 

Page 31 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 127: Genmab P/E vs. SXXP P/E 



<!-- Start of picture text -->
80.0<br>40.0<br>0.0<br>GMAB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 129: Ipsen P/E vs. SXXP P/E<br>18.0<br>13.0<br>8.0<br>3.0<br>IPN SXXP Index<br>Source :Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 131: SOBI P/E vs. SXXP P/E<br>28.0<br>25.0<br>22.0<br>19.0<br>16.0<br>13.0<br>10.0<br>SOBI SXXP Index<br>9-Nov-22<br>9-Nov-22<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

###### Figure 128: Grifols P/E vs. SXXP P/E 



<!-- Start of picture text -->
25.0<br>20.0<br>15.0<br>10.0<br>5.0<br>GRLSMC SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 130: Lundbeck P/E vs. SXXP P/E<br>19.0<br>12.0<br>5.0<br>LUN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 132: UCB P/E vs. SXXP P/E<br>30.0<br>25.0<br>20.0<br>15.0<br>10.0<br>UCB SXXP Index<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Page 32 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 133: Almirall P/E vs. SXXP P/E 



<!-- Start of picture text -->
Figure 134: Recordati P/E vs. SXXP P/E<br><!-- End of picture text -->



<!-- Start of picture text -->
18.0 30.0<br>16.0<br>26.0<br>14.0<br>12.0 22.0<br>10.0 18.0<br>8.0<br>14.0<br>6.0<br>4.0 10.0<br>ALM SXXP Index REC SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates *We note the above values are rolling consensus estimates<br>Figure 135: Sandoz P/E vs. SXXP P/E Figure 136: BioNTech P/E vs. SXXP P/E<br>25.0 6,000.0<br>20.0 5,000.0<br>15.0 4,000.0<br>3,000.0<br>10.0<br>2,000.0<br>5.0 1,000.0<br>0.0 0.0<br>SDZ SXXP Index BNTX SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates *We note the above values are rolling consensus estimates<br>9-Nov-22<br>25-Jul-25 25-Aug-25 25-Sep-25 25-Oct-25 25-Nov-25 25-Dec-25 25-Jan-26 25-Feb-26 25-Mar-26 25-Apr-26 25-May-26 25-Jun-26 25-Jul-26 25-Aug-26 25-Jul-25 25-Sep-25 25-Dec-25 25-Feb-26 25-Jun-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26 9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>25-Aug-25 25-Oct-25 25-Nov-25 25-Jan-26 25-Mar-26 25-Apr-26 25-May-26 25-Jul-26 25-Aug-26<br><!-- End of picture text -->

Deutsche Bank AG 

Page 33 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

EV/EBITDA performance - individual stocks 

###### Figure 137: AstraZeneca EV/EBITDA vs. SXXP EV/EBITDA 



<!-- Start of picture text -->
18.0<br>12.0<br>6.0<br>0.0<br>AZN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 139: Novartis EV/EBITDA vs. SXXP EV/EBITDA<br>17.0<br>13.0<br>9.0<br>5.0<br>NOVN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 141: Roche EV/EBITDA vs. SXXP EV/EBITDA<br>15.0<br>13.0<br>11.0<br>9.0<br>7.0<br>5.0<br>ROG SXXP Index<br>9-Nov-22<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Figure 138: GlaxoSmithKline EV/EBITDA vs. SXXP EV/ EBITDA 



<!-- Start of picture text -->
14.0<br>9.0<br>4.0<br>GSK SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 140: Novo Nordisk EV/EBITDA vs. SXXP EV/EBITDA<br>29.0<br>23.0<br>17.0<br>11.0<br>5.0<br>NOVOB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 142: Sanofi EV/EBITDA vs. SXXP EV/EBITDA<br>12.0<br>6.0<br>0.0<br>SAN SXXP Index<br>9-Nov-22<br>9-Jul-21 9-Nov-22 9-Jul-23 9-Mar-24 9-Jul-24 9-Nov-25<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Jul-21 9-Nov-21 9-Mar-22 9-Jul-22 9-Nov-22 9-Mar-23 9-Jul-23 9-Nov-23 9-Mar-24 9-Jul-24 9-Nov-24 9-Mar-25 9-Jul-25 9-Nov-25 9-Mar-26 9-Jul-26<br>9-Nov-21 9-Mar-22 9-Jul-22 9-Mar-23 9-Nov-23 9-Nov-24 9-Mar-25 9-Jul-25 9-Mar-26 9-Jul-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Page 34 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 143: Genmab EV/EBITDA vs. SXXP EV/EBITDA 



<!-- Start of picture text -->
16.0<br>14.0<br>12.0<br>10.0<br>8.0<br>6.0<br>4.0<br>2.0<br>0.0<br>GMAB SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 145: Ipsen EV/EBITDA vs. SXXP EV/EBITDA<br>12.0<br>10.0<br>8.0<br>6.0<br>4.0<br>2.0<br>0.0<br>IPN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 147: SOBI EV/EBITDA vs. SXXP EV/EBITDA<br>15.0<br>10.0<br>5.0<br>0.0<br>SOBI SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>5-Sep-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-Jun-26 5-Jul-26<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>5-Oct-25 5-Mar-26<br>5-Sep-25 5-May-26 5-Aug-26<br><!-- End of picture text -->

###### Figure 144: Grifols EV/EBITDA vs. SXXP EV/EBITDA 



<!-- Start of picture text -->
12.0<br>10.0<br>8.0<br>6.0<br>GRLSMC SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 146: Lundbeck EV/EBITDA vs. SXXP EV/EBITDA<br>12.0<br>10.0<br>8.0<br>6.0<br>4.0<br>LUN SXXP Index<br>Source : Deutsche Bank, Bloomberg Finance LP<br>*We note the above values are rolling consensus estimates<br>Figure 148: UCB EV/EBITDA vs. SXXP EV/EBITDA<br>20.0<br>16.0<br>12.0<br>8.0<br>4.0<br>UCB SXXP Index<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br>5-Jan-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Deutsche Bank AG 

Page 35 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 149: Recordati EV/EBITDA vs. SXXP EV/EBITDA 



<!-- Start of picture text -->
15.0<br>10.0<br>5.0<br>0.0<br>REC SXXP Index<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

###### Figure 150: BioNTech EV/EBITDA vs. SXXP EV/EBITDA 



<!-- Start of picture text -->
80.0<br>70.0<br>60.0<br>50.0<br>40.0<br>30.0<br>20.0<br>10.0<br>0.0<br>BNTX SXXP Index<br>5-Sep-25 5-Oct-25 5-Nov-25 5-Dec-25 5-Jan-26 5-Feb-26 5-Mar-26 5-Apr-26 5-May-26 5-Jun-26 5-Jul-26 5-Aug-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note the above values are rolling consensus estimates_ 

Page 36 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### US gov bond performance 

###### Figure 151: S&P 500 HC relative performance vs US gov bond yield 



<!-- Start of picture text -->
0.0% 20%<br>1.0% 10%<br>0%<br>2.0%<br>-10%<br>3.0%<br>-20%<br>4.0%<br>-30%<br>5.0% -40%<br>6.0% -50%<br>US 10y treasury yield (lhs, inverted)<br>S&P 500 Healthcare performance (rel to S&P 500, rhs)<br>6-Sep-16 30-Jan-17 25-Jun-17 18-Nov-17 13-Apr-18 6-Sep-18 30-Jan-19 25-Jun-19 18-Nov-19 12-Apr-20 5-Sep-20 29-Jan-21 24-Jun-21 17-Nov-21 12-Apr-22 5-Sep-22 29-Jan-23 24-Jun-23 17-Nov-23 11-Apr-24 4-Sep-24 28-Jan-25 23-Jun-25 16-Nov-25 11-Apr-26 4-Sep-26<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 152: EU MSCI HC relative performance vs US gov bond yield 



<!-- Start of picture text -->
0.0% 40%<br>1.0%<br>20%<br>2.0%<br>3.0% 0%<br>4.0%<br>-20%<br>5.0%<br>6.0% -40%<br>US 10y treasury yield (lhs, inverted)<br>MSCI EU Healthcare performance (rel to MSCI EU, rhs)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>6-Sep-16 30-Jan-17 25-Jun-17 18-Nov-17 13-Apr-18 6-Sep-18 30-Jan-19 25-Jun-19 18-Nov-19 12-Apr-20 5-Sep-20 29-Jan-21 24-Jun-21 17-Nov-21 12-Apr-22 5-Sep-22 29-Jan-23 24-Jun-23 17-Nov-23 11-Apr-24 4-Sep-24 28-Jan-25 23-Jun-25 16-Nov-25 11-Apr-26 4-Sep-26<br><!-- End of picture text -->

Deutsche Bank AG 

Page 37 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

US prescription drug trends (updated weekly) 

#### Diabetes 

###### Figure 153: Diabetes market NRx 



<!-- Start of picture text -->
1,400<br>1,200<br>1,000<br>800<br>600<br>400<br>200<br>0<br>SA insulin LA insulin GLP-1 DPP-IV SGLT-2<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 155: Diabetes branded market NRx growth<br>100%<br>80%<br>60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>-60%<br>SA insulin LA insulin GLP-1 DPP-IV SGLT-2<br>NRx (%)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 154: Diabetes market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
3,000<br>2,500<br>2,000<br>1,500<br>1,000<br>500<br>0<br>SA insulin LA insulin GLP-1 DPP-IV SGLT-2<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 156: Diabetes branded market TRx growth 



<!-- Start of picture text -->
50%<br>30%<br>10%<br>-10%<br>-30%<br>-50%<br>-70%<br>SA insulin LA insulin GLP-1 DPP-IV SGLT-2<br>TRx (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 157: Short-acting insulin market NRx 



<!-- Start of picture text -->
140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Insulin Aspart (Novo Nordisk) Admelog (Sanofi) Apidra (Sanofi)<br>Novolog (Novo Nordisk) Humalog (Lilly)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 158: Short-acting insulin market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
300<br>250<br>200<br>150<br>100<br>50<br>0<br>Insulin Aspart (Novo Nordisk) Admelog (Sanofi) Apidra (Sanofi)<br>Novolog (Novo Nordisk) Humalog (Lilly)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 38 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 159: Long-acting insulin market NRx 



<!-- Start of picture text -->
300<br>250<br>200<br>150<br>100<br>50<br>0<br>Basaglar (Lilly) Toujeo (Sanofi) Tresiba (Novo Nordisk)<br>Levemir (Novo Nordisk) Lantus (Sanofi) Semglee (Mylan)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 160: Long-acting insulin market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
600<br>500<br>400<br>300<br>200<br>100<br>0<br>Basaglar (Lilly) Toujeo (Sanofi) Tresiba (Novo Nordisk)<br>Levemir (Novo Nordisk) Lantus (Sanofi) Semglee (Mylan)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 161: Long-acting insulin market NRx share - by company 



<!-- Start of picture text -->
90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Sanofi Novo Nordisk Lilly<br>NRx share (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 162: Long-acting insulin market NRx share 



<!-- Start of picture text -->
80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Basaglar (Lilly) Toujeo (Sanofi) Tresiba (Novo Nordisk)<br>Levemir (Novo Nordisk) Lantus (Sanofi)<br>NRx share (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 163: Long-acting insulin market TRx growth - by company 



<!-- Start of picture text -->
60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>-60%<br>-80%<br>Sanofi Novo Nordisk<br>TRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 39 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 164: Lantus NRx vs. NRx growth 



<!-- Start of picture text -->
180 100%<br>160 80%<br>140<br>60%<br>120<br>100 40%<br>80 20%<br>60<br>0%<br>40<br>20 -20%<br>0 -40%<br>Lantus NRx Lantus NRx growth (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000'S)<br>NRx growth (%)<br><!-- End of picture text -->

###### Figure 165: GLP-1 market TRx - by administration 



<!-- Start of picture text -->
1,200<br>1,000<br>800<br>600<br>400<br>200<br>0<br>Weekly Daily 2x Daily<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 166: GLP-1 market TRx 



<!-- Start of picture text -->
500<br>450<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>Victoza (Novo Nordisk) Trulicity (Lilly) Bydureon (AZN)<br>Byetta (AZN) Ozempic (Novo Nordisk) Rybelsus (Novo Nordisk)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br><!-- End of picture text -->

###### Figure 167: GLP-1 market NRx 



<!-- Start of picture text -->
1200<br>1000<br>800<br>600<br>400<br>200<br>0<br>Victoza (Novo Nordisk) Trulicity (Lilly) Bydureon (AZN)<br>Byetta (AZN) Ozempic (Novo Nordisk) Rybelsus (Novo Nordisk)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 168: GLP-1 market NRx growth 



<!-- Start of picture text -->
450%<br>360%<br>270%<br>180%<br>90%<br>0%<br>-90%<br>-180%<br>Victoza (Novo Nordisk) Trulicity (Lilly) Bydureon (AZN)<br>Byetta (AZN) Ozempic (Novo Nordisk) Rybelsus (Novo Nordisk)<br>GLP-1 MKT<br>NRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note Ozempic NRx growth increased significantly Nov-19 to Mar-20 to c400-500%, however, have formatted the y-axis to highlight 2 year historical trend_ 

###### Figure 169: GLP-1 market TRx growth 



<!-- Start of picture text -->
400%<br>300%<br>200%<br>100%<br>0%<br>-100%<br>-200%<br>Victoza (Novo Nordisk) Trulicity (Lilly) Bydureon (AZN)<br>Byetta (AZN) Ozempic (Novo Nordisk) Rybelsus (Novo Nordisk)<br>GLP-1 MKT<br>TRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note Ozempic TRx growth increased significantly Nov-19 to Mar-20 to c400-500%, however, have formatted the y-axis to highlight 2 year historical trend_ 

Page 40 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 170: Novo's Victoza + Ozempic and Lilly's Trulicity - NRx share 



<!-- Start of picture text -->
90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Trulicity NRx Share Victoza NRx Share Ozempic NRx Share<br>NRx share (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 171: SGLT-2 market TRx share<br><!-- End of picture text -->



<!-- Start of picture text -->
120%<br>100%<br>80%<br>60%<br>40%<br>20%<br>0%<br>Farxiga (AZN) Invokana (JnJ) Invokamet (JnJ)<br>Jardiance (BI⁄Lilly) Steglatro (Merck) Other<br>TRx share<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP Note: BBG is reporting 0 Farxiga TRx, IQVIA still reports TRx >35,000_ 

###### Figure 172: Jardiance NRx share - post CV outcomes study 



<!-- Start of picture text -->
120%<br>100%<br>80%<br>60%<br>40%<br>20%<br>0%<br>SGLT-2 as a % of diabetes NRx Jardiance as a % of SGLT-2 NRx<br>NRx share (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 173: Jardiance TRx share - post CV outcomes study<br><!-- End of picture text -->



<!-- Start of picture text -->
120%<br>100%<br>80%<br>60%<br>40%<br>20%<br>0%<br>SGLT-2 as a % of diabetes TRx Jardiance as a % of SGLT-2 TRx<br>TRx share (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 174: DPP-IV market NRx 



<!-- Start of picture text -->
90<br>80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Januvia (Merck) Onglyza (AZN) Tradjenta (Lilly) Nesina (Takeda)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br><!-- End of picture text -->



<!-- Start of picture text -->
Figure 175: DPP-IV market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
200<br>180<br>160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Januvia (Merck) Onglyza (AZN) Tradjenta (Lilly) Nesina (Takeda)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>TRx (000's)<br><!-- End of picture text -->

Deutsche Bank AG 

Page 41 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 176: SGLT-2 NRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>Invokana (JnJ) Farxiga (AZN) Jardiance (BI⁄Lilly)<br>Xig Duo XR (AZN) Invokamet (JnJ) Steglatro (Merck)<br>Steglujan (Merck) Synjardy⁄ Glyxambi (Lilly)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP Note: BBG is reporting 0 Farxiga NRx, IQVIA still reports NRx >10,000_ 

###### Figure 177: SGLT-2 TRx 



<!-- Start of picture text -->
600<br>500<br>400<br>300<br>200<br>100<br>0<br>Invokana (JnJ) Farxiga (AZN) Jardiance (BI⁄Lilly)<br>Xig Duo XR (AZN) Invokamet (JnJ) Steglatro (Merck)<br>Steglujan (Merck) Synjardy⁄ Glyxambi (Lilly)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP Note: BBG is reporting 0 Farxiga TRx, IQVIA still reports TRx >35,000_ 

Page 42 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Heart disease 

###### Figure 178: PSCK-9 NRx 



<!-- Start of picture text -->
60<br>50<br>40<br>30<br>20<br>10<br>0<br>Praluent (SASY⁄REGN) Repatha (Amgen)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 180: PCSK-9 market NRx share<br>100%<br>90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Praluent (SASY⁄REGN) Repatha (Amgen)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br>NRx share<br><!-- End of picture text -->



<!-- Start of picture text -->
Figure 179: PSCK-9 TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
180<br>160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Praluent (SASY⁄REGN) Repatha (Amgen)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>TRx (000's)<br><!-- End of picture text -->

Figure 181: PCSK-9 market TRx share 



<!-- Start of picture text -->
100%<br>90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Praluent (SASY⁄REGN) Repatha (Amgen)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>TRx share<br><!-- End of picture text -->

Figure 182: Generic ACE inhibitor market - NRx growth 



<!-- Start of picture text -->
40%<br>30%<br>20%<br>10%<br>0%<br>-10%<br>-20%<br>-30%<br>-40%<br>Generic ACE inhibitor mkt growth<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 183: Generic ARB inhibitor market - TRx growth 



<!-- Start of picture text -->
50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>-10%<br>-20%<br>-30%<br>Generic ARB inhibitor mkt growth<br>Source : Deutsche Bank, Bloomberg Finance LP<br><!-- End of picture text -->

Deutsche Bank AG 

Page 43 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 184: New heart failure drugs - NRx 



<!-- Start of picture text -->
60<br>50<br>40<br>30<br>20<br>10<br>0<br>Entresto (Novartis) Corlanor (Amgen)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 185: New heart failure drugs - TRx 



<!-- Start of picture text -->
160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Entresto (Novartis) Corlanor (Amgen)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 186: Anti platelet market NRx 



<!-- Start of picture text -->
18<br>16<br>14<br>12<br>10<br>8<br>6<br>4<br>2<br>0<br>Plavix (BMS) Effient (Lilly) Agrylin (Takeda) Brilinta (AZN) Persantine (BI) Aggrenox (BI)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 187: Anti platelet market TRx 



<!-- Start of picture text -->
45<br>40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Plavix (BMS) Effient (Lilly) Agrylin (Takeda) Brilinta (AZN) Persantine (BI) Aggrenox (BI)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 188: Brillinta versus class - NRx share 



<!-- Start of picture text -->
120% 40%<br>20%<br>100%<br>0%<br>80%<br>-20%<br>60% -40%<br>-60%<br>40%<br>-80%<br>20%<br>-100%<br>0% -120%<br>Brilinta NRx Share Brilinta NRx Growth (RHS)<br>NRx share (%) NRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 189: Brillinta versus class - TRx share 



<!-- Start of picture text -->
120% 20%<br>100% 0%<br>80% -20%<br>60% -40%<br>40% -60%<br>20% -80%<br>0% -100%<br>Brilinta TRx Share Brilinta TRx Growth (RHS)<br>TRx share (%) TRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 44 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 190: Anticoagulant market NRx 



<!-- Start of picture text -->
500<br>450<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>Warfarin Xarelto (Bayer) Eliquis (BMS) Pradaxa (BI) Savayasa (Daiichi S)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 191: Anticoagulant market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
1200<br>1000<br>800<br>600<br>400<br>200<br>0<br>Warfarin Xarelto (Bayer) Eliquis (BMS) Pradaxa (BI) Savayasa (Daiichi S)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 192: Anticoagulant market NRx - ex Warfarin 



<!-- Start of picture text -->
450<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>Xarelto (Bayer) Eliquis (BMS) Pradaxa (BI) Savayasa (Daiichi S)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 193: Anticoagulant market TRx - ex Warfarin<br><!-- End of picture text -->



<!-- Start of picture text -->
1000<br>900<br>800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>Xarelto (Bayer) Eliquis (BMS) Pradaxa (BI) Savayasa (Daiichi S)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 194: Anticoagulant market NRx growth 



<!-- Start of picture text -->
60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>-60%<br>-80%<br>Warfarin Xarelto (Bayer) Eliquis (BMS)<br>Pradaxa (BI) Savayasa (Daiichi S) MKT g (%)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx growth (%)<br><!-- End of picture text -->



<!-- Start of picture text -->
Figure 195: Anticoagulant market TRx growth<br><!-- End of picture text -->



<!-- Start of picture text -->
60%<br>40%<br>20%<br>0%<br>-20%<br>-40%<br>-60%<br>-80%<br>Warfarin Xarelto (Bayer) Eliquis (BMS)<br>Pradaxa (BI) Savayasa (Daiichi S) MKT g (%)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>TRx growth (%)<br><!-- End of picture text -->

Deutsche Bank AG 

Page 45 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 



<!-- Start of picture text -->
Figure 196: Obesity market TRx Figure 197: Saxenda TRx share<br>450 16% 200%<br>400 14%<br>350 150%<br>12%<br>300<br>250 10% 100%<br>200 8%<br>150 6% 50%<br>100<br>4%<br>50 0%<br>0 2%<br>0% -50%<br>Belviq (Eisai⁄Arena) Contrave Saxenda (Novo Nordisk)<br>Qsymia (Vivus) Wegovy (Novo Nordisk) Other Saxenda share (%) Mkt growth (RHS)<br>Source : Deutsche Bank, Bloomberg Finance LP Source : Deutsche Bank, Bloomberg Finance LP<br>TRx (000's) TRx share (%) Mkt growth (%)<br><!-- End of picture text -->

#### Respiratory 

###### Figure 198: Asthma/COPD market NRx 



<!-- Start of picture text -->
800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>LABA/ICS LAMA LABA/LAMA Triple<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br><!-- End of picture text -->

###### Figure 199: Asthma/COPD market TRx 



<!-- Start of picture text -->
900<br>800<br>700<br>600<br>500<br>400<br>300<br>200<br>100<br>0<br>LABA/ICS LAMA LABA/LAMA Triple<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 200: LABA/ICS market NRx 



<!-- Start of picture text -->
200<br>180<br>160<br>140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Airduo Respiclick (Teva) Symbicort (AZN) Dulera (Merck) Breo (GSK) Advair (GSK)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 201: LABA/ICS market TRx 



<!-- Start of picture text -->
450<br>400<br>350<br>300<br>250<br>200<br>150<br>100<br>50<br>0<br>Airduo Respiclick (Teva) Symbicort (AZN) Dulera (Merck) Breo (GSK) Advair (GSK)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 46 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 202: GSK's Breo Ellipta TRx/NRx share 



<!-- Start of picture text -->
14%<br>12%<br>10%<br>8%<br>6%<br>4%<br>2%<br>0%<br>TRx share NRx share<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Share (%)<br><!-- End of picture text -->

###### Figure 203: GSK's Anoro Ellipta TRx/NRx share 



<!-- Start of picture text -->
7%<br>6%<br>5%<br>4%<br>3%<br>2%<br>1%<br>0%<br>TRx share NRx share<br>Share (%)<br><!-- End of picture text -->



<!-- Start of picture text -->
Source : Deutsche Bank, Bloomberg Finance LP<br><!-- End of picture text -->

###### Figure 204: GSK's Trelegy Ellipta NRx 



<!-- Start of picture text -->
90<br>80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br><!-- End of picture text -->

###### Figure 205: GSK's Trelegy Ellipta TRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 206: LABA/LAMA market NRx 



<!-- Start of picture text -->
30<br>25<br>20<br>15<br>10<br>5<br>0<br>Anoro Ellipta (GSK) Stiolto Respimat (BI) Bevespi Aerosphere (AZN)<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx (000's)<br><!-- End of picture text -->

###### Figure 207: LABA/LAMA market TRx 



<!-- Start of picture text -->
80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Anoro Ellipta (GSK) Stiolto Respimat (BI) Bevespi Aerosphere (AZN)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 47 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 208: LAMA market NRx 



<!-- Start of picture text -->
10<br>9<br>8<br>7<br>6<br>5<br>4<br>3<br>2<br>1<br>0<br>Spiriva (BI) Incruse Ellipta (GSK) Tudorza Pressair (AZN) Seebri Neohaler<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 209: LAMA market TRx 



<!-- Start of picture text -->
30<br>25<br>20<br>15<br>10<br>5<br>0<br>Spiriva (BI) Incruse Ellipta (GSK) Tudorza Pressair (AZN) Seebri Neohaler<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 210: Respiratory biologics NRx (excl Dupixent) 



<!-- Start of picture text -->
9<br>8<br>7<br>6<br>5<br>4<br>3<br>2<br>1<br>0<br>Xolair Nucala Fasenra Cinqair<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 211: Respiratory biologics TRx (excl Dupixent) 



<!-- Start of picture text -->
35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Xolair Nucala Fasenra Cinqair<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 212: GSK's Incruse Ellipta TRx/NRx share 



<!-- Start of picture text -->
120%<br>100%<br>80%<br>60%<br>40%<br>20%<br>0%<br>Incruse TRx Incruse NRx<br>TRx/NRx share<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 48 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Eye disease 

###### Figure 213: Dry eye market NRx 



<!-- Start of picture text -->
40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Restasis Xiidra<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 214: Dry eye market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
90<br>80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Restasis Xiidra<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

#### HIV 

###### Figure 215: HIV market TRx 



<!-- Start of picture text -->
300<br>250<br>200<br>150<br>100<br>50<br>0<br>STRs INSTIs NNRTIs Protease Inhibs NRTI Backbone<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 216: Single-treatment regimen market TRx 



<!-- Start of picture text -->
140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Atripla Complera Dovato Trizivir Stribild Odefsey<br>Genvoya Triumeq Juluca Biktarvy Generic<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 217: Single-treatment regimen market TRx 



<!-- Start of picture text -->
90<br>80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Atripla Complera Dovato Trizivir<br>Stribild Odefsey Genvoya Triumeq<br>Juluca Biktarvy Generic<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 218: Single-treatment regimen market NRx 



<!-- Start of picture text -->
45<br>40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Atripla Complera Dovato Trizivir Stribild Odefsey<br>Genvoya Triumeq Juluca Biktarvy Generic<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 49 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 219: HIV market - GSK vs. Gilead NRx market share 



<!-- Start of picture text -->
100%<br>90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Gilead GSK<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 221: Tivicay NRx and TRx<br>14<br>12<br>10<br>8<br>6<br>4<br>2<br>0<br>Tivicay TRx Tivicay NRx<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx share (%)<br>NRx and TRx (000's)<br><!-- End of picture text -->

###### Figure 220: HIV market - GSK vs. Gilead TRx market share 



<!-- Start of picture text -->
100%<br>90%<br>80%<br>70%<br>60%<br>50%<br>40%<br>30%<br>20%<br>10%<br>0%<br>Gilead GSK<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 222: Triumeq NRx and TRx<br>10<br>9<br>8<br>7<br>6<br>5<br>4<br>3<br>2<br>1<br>0<br>Triumeq TRx Triumeq NRx<br>NRx share (%)<br>NRx and TRx (000's)<br><!-- End of picture text -->



<!-- Start of picture text -->
Source : Deutsche Bank, Bloomberg Finance LP<br><!-- End of picture text -->

###### Figure 223: Biktarvy NRx and TRx 



<!-- Start of picture text -->
90<br>80<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0<br>Biktarvy TRx Biktarvy NRx<br>Source : Deutsche Bank, Bloomberg Finance LP<br>NRx and TRx (000's)<br><!-- End of picture text -->

Page 50 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 224: Triumeq NRx share 



<!-- Start of picture text -->
8% 0%<br>7% -5%<br>6%<br>-10%<br>5%<br>-15%<br>4%<br>-20%<br>3%<br>2% -25%<br>1% -30%<br>0% -35%<br>Triumeq as a % of STRs ch % in share (RHS) Linear (ch% in share (RHS))<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 226: Tivicay NRx share<br>8% 10%<br>7% 5%<br>6% 0%<br>5%<br>-5%<br>4%<br>-10%<br>3%<br>2% -15%<br>1% -20%<br>0% -25%<br>Tivicay as a % of total market Ch% in share (RHS) Linear (ch% in share (RHS))<br>NRx share (%) Share cg (%)<br>NRx share (%) Share cg (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 225: Triumeq TRx share<br><!-- End of picture text -->



<!-- Start of picture text -->
8% 0%<br>7% -5%<br>6%<br>-10%<br>5%<br>-15%<br>4%<br>-20%<br>3%<br>-25%<br>2%<br>1% -30%<br>0% -35%<br>Triumeq as a % of STRs ch % in share (RHS) Linear (ch% in share (RHS))<br>Source : Deutsche Bank, Bloomberg Finance LP<br>Figure 227: Tivicay TRx share<br>8% 5%<br>7%<br>0%<br>6%<br>5% -5%<br>4%<br>3% -10%<br>2%<br>-15%<br>1%<br>0% -20%<br>Tivicay as a % of total market Ch% in share (RHS) Linear (ch% in share (RHS))<br>NRx share (%) Share cg (%)<br>TRx share (%) Share cg (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 228: NRTI backbone therapy - NRx 



<!-- Start of picture text -->
25<br>20<br>15<br>10<br>5<br>0<br>Truvada Epzicom Descovy Combivir Delstrigo Generic<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 229: NRTI backbone therapy - TRx 



<!-- Start of picture text -->
60<br>50<br>40<br>30<br>20<br>10<br>0<br>Truvada Epzicom Descovy Combivir Delstrigo Generic<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 51 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 



<!-- Start of picture text -->
Figure 230: NNRTI market - NRx<br>0.8<br>0.7<br>0.6<br>0.5<br>0.4<br>0.3<br>0.2<br>0.1<br>0.0<br>Edurant Intelence Viramune Sustiva Pifeltro Generic<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 231: NNRTI market - TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
3.0<br>2.5<br>2.0<br>1.5<br>1.0<br>0.5<br>0.0<br>Edurant Intelence Viramune Sustiva Pifeltro Generic<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 52 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Immunology 



<!-- Start of picture text -->
Figure 232: Ulcerative colitis market - orals - NRx<br><!-- End of picture text -->



<!-- Start of picture text -->
3<br>2<br>2<br>1<br>1<br>0<br>Lialda (Takeda) Apriso (Bausch Health) Asacol Hd (Abbvie)<br>Pentasa (Takeda) Delzicol (Abbvie) Uceris (Bausch Health)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 233: Ulcerative colitis market - orals - TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
8<br>7<br>6<br>5<br>4<br>3<br>2<br>1<br>0<br>Lialda (Takeda) Apriso (Bausch Health) Asacol Hd (Abbvie)<br>Pentasa (Takeda) Delzicol (Abbvie) Uceris (Bausch Health)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 234: Multiple Sclerosis - orals - NRx 



<!-- Start of picture text -->
3<br>2<br>2<br>1<br>1<br>0<br>Gilenya (NOVN) Tecfidera (Biogen) Aubagio (Sanofi) Mavenclad (MRK)<br>Mayzent (NOVN) Vumerity (Biogen) Ponvory Zeposia<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 235: Multiple Sclerosis - orals - TRx 



<!-- Start of picture text -->
9<br>8<br>7<br>6<br>5<br>4<br>3<br>2<br>1<br>0<br>Gilenya (NOVN) Tecfidera (Biogen) Aubagio (Sanofi) Mavenclad (MRK)<br>Mayzent (NOVN) Vumerity (Biogen) Ponvory Zeposia<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 236: Multiple Sclerosis market - types - NRx 



<!-- Start of picture text -->
4<br>3.5<br>3<br>2.5<br>2<br>1.5<br>1<br>0.5<br>0<br>Orals Interferons Copaxone Ocrevus Tysabri Lemtrada Zinbryta<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 237: Multiple Sclerosis market - types - TRx 



<!-- Start of picture text -->
14<br>12<br>10<br>8<br>6<br>4<br>2<br>0<br>Orals Interferons Copaxone Ocrevus Tysabri Lemtrada Zinbryta<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 53 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 238: Multiple sclerosis market - interferons - NRx 



<!-- Start of picture text -->
0.60<br>0.50<br>0.40<br>0.30<br>0.20<br>0.10<br>0.00<br>Betaseron Avonex Rebif Plegridy<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 239: Multiple sclerosis market - interferons - TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
3.0<br>2.5<br>2.0<br>1.5<br>1.0<br>0.5<br>0.0<br>Betaseron Avonex Rebif Plegridy<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 240: IL - 17 market NRx 



<!-- Start of picture text -->
6<br>5<br>4<br>3<br>2<br>1<br>0<br>Cosentyx Taltz Siliq<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 241: IL - 17 market TRx 



<!-- Start of picture text -->
20<br>18<br>16<br>14<br>12<br>10<br>8<br>6<br>4<br>2<br>0<br>Cosentyx Taltz Siliq<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 242: Dupixent NRx 



<!-- Start of picture text -->
40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 243: Dupixent TRx 



<!-- Start of picture text -->
140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 54 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 244: Stelara vs Taltz vs Cosentyx vs Tremfya vs Siliq (NRx) 



<!-- Start of picture text -->
14<br>12<br>10<br>8<br>6<br>4<br>2<br>0<br>Stelara Cosentyx Taltz Tremfya Siliq Ilumya Skyrizi<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Figure 245: Stelara vs Taltz vs Cosentyx vs Tremfya vs Siliq (NRx growth) 



<!-- Start of picture text -->
150%<br>100%<br>50%<br>0%<br>-50%<br>-100%<br>-150%<br>Stelara Cosentyx Taltz Tremfya Siliq Ilumya Skyrizi<br>NRx growth (%)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP *We note for Skyrizi and Ilumya NRx growth increased significantly. We have formatted the y-axis in order to highlight the 2 year historical trend_ 

###### Figure 246: Stelara vs Taltz vs Cosentyx vs Tremfya vs Siliq (TRx) 



<!-- Start of picture text -->
40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Stelara Cosentyx Taltz Tremfya Siliq Ilumya Skyrizi<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

#### Rheumatoid arthritis 

Figure 247: RA market NRx 



<!-- Start of picture text -->
40<br>35<br>30<br>25<br>20<br>15<br>10<br>5<br>0<br>Humira Enbrel Remicade Cimzia Simponi<br>Actemra Kevzara Xeljanz Olumiant Rinvoq<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 248: RA market TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Humira Enbrel Remicade Cimzia Simponi Actemra Kevzara Xeljanz Olumiant Rinvoq<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 55 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Vaccination 

###### Figure 249: US Shingle vaccination market NRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>Shingrix Zostavax<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 250: US Shingle vaccination market TRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>Shingrix Zostavax<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

#### Migraine 

###### Figure 251: Migraine market NRx 



<!-- Start of picture text -->
120<br>100<br>80<br>60<br>40<br>20<br>0<br>Triptans Aimovig Ajovy Emgality Nurtec Vyepti Non-Triptans (Other)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 252: Non-triptan migraine market NRx 



<!-- Start of picture text -->
120<br>100<br>80<br>60<br>40<br>20<br>0<br>Aimovig Ajovy Emgality Nurtec Vyepti Non-Triptans (Other)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 253: Migraine market TRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>Triptans Aimovig Ajovy Emgality Nurtec Vyepti Non-Triptans (Other)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

###### Figure 254: Non-triptan migraine market TRx 



<!-- Start of picture text -->
250<br>200<br>150<br>100<br>50<br>0<br>Aimovig Ajovy Emgality Nurtec Vyepti Non-Triptans (Other)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank, Bloomberg Finance LP_ 

Page 56 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Injectable biosimilars 

###### Figure 255: EPO TRx ('000s) 



<!-- Start of picture text -->
7.0<br>6.0<br>5.0<br>4.0<br>3.0<br>2.0<br>1.0<br>0.0<br>PP LPP OP PEE EEE SS<br>Aranesp Epogen Mircera Procrit Retacrit<br>Source : Deutsche Bank research; Bloomberg Finance LP<br>Figure 257: HGH TRx ('000s)<br>20<br>18<br>1614 \<br>12 .<br>10<br>8<br>6 vi\<br>4<br>2<br>0<br>SoPST FPPH ooSFoP SMoH oFHoOT & SMS<br>. Egrifta . Genotropin . Humatrope . Increlex . Norditropin Nutropin<br>Omnitrope Saizen Serostim Skytrofa Sogroya Zomacton<br>Source : Deutsche Bank research; Bloomberg Finance LP<br>Figure 259: CSF TRx ('000s)<br>4.5<br>4.0<br>3.5<br>3.0<br>2.5<br>2.0 eer | lhadd aM | sain<br>1.5<br>1.0<br>0.5<br>0.0<br>PP PH DP PP DH HO © &<br>SS KM MK ST HM SK a HS<br>. Fulphila . Fylnetra . Granix . Leukine . Neulasta . Neupogen<br>Nivestym Nyvepria Releuko Udenyca Zarxio Ziextenzo<br>TRx (000's)<br>TRx (000's)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 256: EPO NRx ('000s)<br><!-- End of picture text -->



<!-- Start of picture text -->
3.5<br>3.0<br>2.5<br>2.0<br>1.5<br>1.0<br>0.5<br>0.0<br>PPLE EP PEELPEE ES<br>Aranesp Epogen Mircera Procrit Retacrit<br>Source : Deutsche Bank research; Bloomberg Finance LP<br>Figure 258: HGH NRx ('000s)<br>7<br>6<br>5<br>ai<br>4<br>3<br>yf Nh Wy is i ra<br>2<br>1<br>0 PP P Po Po oH DP PP ef<br>SSK KM Mo MM MF KW<br>Egrifta Genotropin Humatrope Increlex Norditropin Nutropin<br>Omnitrope Saizen Serostim Skytrofa Sogroya Zomacton<br>NRx (000's)<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

Figure 260: CSF NRx ('000s) 



<!-- Start of picture text -->
2.5<br>2.0<br>1.5 | r panaADMi ly Ad heal ! nade<br>1.0<br>0.5<br>0.0 re<br>— sateen atinaensncnentn Maman<br>PP Po oo bo oo Po &<br>SSK KM SK oF MM SM BF OF Oh<br>Fulphila Fylnetra Granix Leukine Neulasta Neupogen<br>Nivestym Nyvepria Releuko Udenyca Zarxio Ziextenzo<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 57 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Insulin biosimilars 

###### Figure 261: Admelog & Humalog TRx 



<!-- Start of picture text -->
140<br>120<br>100<br>80<br>60<br>40<br>20<br>0<br>Admelog Humalog Humalog Kwikpen<br>Source : Deutsche Bank research; Bloomberg Finance LP<br>Figure 263: Basaglar, Semglee and Lantus TRx<br>400.0<br>350.0<br>300.0<br>250.0<br>200.0<br>150.0<br>100.0<br>50.0<br>0.0<br>Basaglar Semglee Lantus Lantus Solostar<br>TRx (000's)<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 262: Admelog & Humalog NRx<br><!-- End of picture text -->



<!-- Start of picture text -->
60<br>50<br>40<br>30<br>20<br>10<br>0<br>Admelog Humalog Humalog Kwikpen<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

###### Figure 264: Basaglar, Semglee and Lantus NRx 



<!-- Start of picture text -->
200.0<br>180.0<br>160.0<br>140.0<br>120.0<br>100.0<br>80.0<br>60.0<br>40.0<br>20.0<br>0.0<br>Basaglar Semglee Lantus Lantus Solostar<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

#### Humira biosimilars 

###### Figure 265: Humira biosimilars TRx 



<!-- Start of picture text -->
90.0<br>80.0<br>70.0<br>60.0<br>50.0<br>40.0<br>30.0<br>20.0<br>10.0<br>0.0<br>Amjevita Cyltezo Hadlima Humira Hyrimoz Idacio Yuflyma<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

###### Figure 266: Humira biosimilars NRx 



<!-- Start of picture text -->
30.0<br>25.0<br>20.0<br>15.0<br>10.0<br>5.0<br>0.0<br>Amjevita Cyltezo Hadlima Humira Hyrimoz Idacio Yuflyma<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

Page 58 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Remicade biosimilars 



<!-- Start of picture text -->
Figure 267: Remicade biosimilars TRx<br><!-- End of picture text -->



<!-- Start of picture text -->
1.8<br>1.6<br>1.4<br>1.2<br>1.0<br>0.8<br>0.6<br>0.4<br>0.2<br>0.0<br>Avsola Inflectra Renflexis<br>TRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 



<!-- Start of picture text -->
Figure 268: Remicade biosimilars NRx<br>0.8<br>0.7<br>0.6<br>0.5<br>0.4<br>0.3<br>0.2<br>0.1<br>0.0<br>Avsola Inflectra Renflexis<br>NRx (000's)<br><!-- End of picture text -->

_Source : Deutsche Bank research; Bloomberg Finance LP_ 

Deutsche Bank AG 

Page 59 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

## EU Large cap patent expiry 

Figure 269: EU Pharmaceutical large caps (AZN, GSK, NOVO) patent expiry dates 

|Product<br>A<br>ZN<br>_Ti_|2035|2035|Japan<br>2035|China<br>_*bold =_<br>_N_<br>_ME_<br>2035|
|---|---|---|---|---|
|_agrsso_<br>_Farxiga/Forxiga_<br>|;<br>|;<br>2028;<br>|;<br>2024-25;<br><br>|;<br>2027; 2041<br>|
|_Soliris_<br>_Imfinzi_|; 2025-32|; 2029|2<br>027;2029|2029|
|_Lynparza_<br>|2024-27;<br>|;<br>|2029;<br>|;<br>|
|_Symbicort_<br>_Ehld_|2025-29|Expired|Expired|Expired|
|_vuse_<br>_Calquence_<br>_Ultomiris_<br>|2026-32;2032-36<br>; 2038|2<br>032-35-2036<br>2038-|2<br>037;2036<br>; 2038|2032;2036<br>2<br>035:<br>2038|
|_Vaxzevria_<br>_Fasenra_<br>|; 2028-34<br>|; 2028-34<br>|; 2034|2028<br>|
|_Brilinta_<br>_Nexium_|;<br>Expired|;<br>Expired|Expired|2037<br>Expired|
|_Crestor_|Expired|Expired|Expired|Expired|
|_Strensiq_|<br>2025-29;|<br>2025-31;|<br>;||
|_Beyfortus_<br>|2028-35; 2038-40||<br>; 2038|2038|
|_Datroway_<br>_Enhertu_<br>_Imjudo_|; 2035<br>2031|; 2035<br>2026|2031|; 2035<br>2026|
|_Orpathys_<br>|||||
|_Truqap_<br>_Andexxa/ Ondexxya_|2028-30;<br>;|;|;|;<br>;|
|_Xigduo/Xigduo_|||2024-25;|2027;|
|_Lokelma_<br>_Rdtt_|2032;|2032||2033;<br>|
|_oxausa_<br>_Wainua/ Wainzua_<br>|2025;<br>|||;<br>|
|_Airsupra_<br>_Breztri/Trixeo_|2030<br>2030-31;|2030;|2030<br>2030-34;|2030<br>2030;|
|_Tezspire_|||||
|_Saphnelo_<br>_FluMist_|2025-29;<br>2025|2025-29<br>2025|2030-34;<br>2025|2025|
|_Kanuma_<br>_Koselugo_|||||
|_Voydeya_|:2038||||
|GSK|||||
|_Shingrix_<br>|2029|2031|||
|_Rotarix_|Expired|Expired|||
|_Zejula_<br>_Menveo_|2031; 2027-39<br>2025|2032; 2029-37<br>2025|||
|_Synflorix_<br>||2026<br>|||
|_Relvar/Breo Ellipta_<br>_Amuity Ellipa_<br>_Avamys/Veramyst_|2025; 2027-31|2028; 2025-29|||
|_Ventolin HFA_<br>|2026<br>|Expired<br>|||
|_Benlysta_<br>_Apretude_|2025; 2029-35<br>2031*; 2026-31|2026;2035<br>2031;2031|||
|_Cabenuva/Vocabria + Rekam_|_bys_<br>2031*; 2026-38|2031;2031|||
|<br>_Rukobia_<br>_B_|<br>2029; 2025-27<br>2027|2025;2034<br>2028|||
|_exsero_<br>_Cervarix_<br>_Dovato_|Expired<br>2028; 2030-31|Expired<br>2029; 2029-34*|||
|_Juluca_|2028; 2025-38|2029; 2025-29|||
|_Triumeq_<br>_Tii_|2028-2030<br>2028-2030|2029-2029<br>2029-2029|||
|_vcay_<br>|||||
|_Nucala_<br>_Blenrep_|2029-2036<br>2032 -2038|2028- 2031<br>2032|||
|_Jemperli_|2035* 2034-2038|2036 2038|||
|_Ojjaara/Omjjara_|2030 2035-2040|2028 2039*|||
|_Anoro Ellipta_|<br>2027 2025-31<br>|<br>2029 2025-30<br>|||
|_Flixotide/Flovent_<br>_Seretide/Advair_|2026<br>2026|expired<br>expired|||
|_Trelegy Ellipta_<br>_Ati_|2027 2025-31|2029 2025-32<br>exired|||
|_ugmenn_<br>||p<br>|||
|_Lamictal_<br>_Arexvy_|expired<br>2030|expired<br>2032|||
|_Infanrix/Pediarix_<br>_Fluarix_|expired<br>expired|expired<br>expired|||
|_FluLaval_|exired|exired|||
|_Priorix, Priorix Tetra, Varilrix_<br>NOVO|p<br>expired|p<br>expired|||
|_Victoza_|Expired|Expired|Expired|Expired|
|_Saxenda_<br>_Tresiba_<br>|Expired<br>2029<br>|Expired<br>2028<br>|Expired<br>2027<br>|Expired<br>Expired<br>|
|_Ryzodeg_|2029|2028|Expired|Expired|
|_Xultophy_|2029|2028|Expired|Expired|
|_Ozempic_|2032|2031|2031|2026|
|_Rybelsus_<br>_Wegovy_<br>|2032 (Oral: 2034)<br>2032<br>|2031<br>2031<br>|2031<br>2031<br>|2026<br>2026<br>|
|_Flasp_<br>_Esperoct_|2030<br>2032|2030<br>2034|20230<br>2034|2030<br>2029|



_Source: Company data_ 

Page 60 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

# Figure 270: EU Pharmaceutical large caps (NOVN, ROG, ~~<u>———————</u>~~ SAN) patent expiry dates 

|<br>NOVN||||
|---|---|---|---|
|_Tasigna_|Expired|Expired||
|_Promacta_|Expired|2025||
|_Xildra_||||
|_Kesimpta_|2031|Expired||
|_Cosentyx_<br>|2029|2030<br>||
|_Jakavi_||2027||
|_Gilenya_||||
|_Zolgensma_|2033|2033||
|_Zolair_||||
|_Entresto_|2025|2026||
|_Kisqali_|2031|2032||
|_Tafinlar_|2030|2029||
|_Mekinist_|2027|2029||
|_Use of Mekinist with Tafinlar_|2031|2030||
|_Ilaris_|Expired|2025||
|_Pluvicto_|2034|2034||
|_Zolgensma_|2033|2033||
|_Leqvio_|2034|2035||
|_Scemblix_|2033|2037||
|_Lutathera_|2025|2027||
|_Fabhalta_|2034|2034||
|ROG||||
|_Xolair_|2023|2024||
|_Perjeta_|2025|||
|_Kadcyla_|2026|||
|_Ocrevus_|2029|||
|SAN||||
|_Alprolix_|2026|2028||
|_Dupixent_|2029|2028|2026|
|_Toujeo_|2031|2031|2033|
|_Fabrazyme_|2028|||
|_Nexviazyme/ Nexviadyme_|2032|2032|2031|
|_Sarclisa_|2032|2030|2028|
|_Altuviio_|2035|2034|2031|
|_Rezurock_|2028||2034|
|_Cablivi_|2031|2030|2032|
|_Xenpozyme_|2034|2032|2030|
|_Tzield_|2034|||
|_Beyfortus_|2035|2032|2032|
|NB: Different dates refer to|different within-produc|tpatents according|to indications/formulations|



_Source : Company data_ 

Page 61 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

## Company catalyst calendars 

#### Large Cap companies 

Figure 271: Novo Nordisk - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Oral/SCa<br>mycretin|O<br>besity|P3 AMAZE program initated|Q1 2026|
|Cagrisema[cagrilintide+semaglutide]|O<br>besity|P3 REDEFINE-4 H2H vs tirzepatide did not meet primary endpoint|23rd Feb 2026|
|InsulinI<br>codec|T2D|US approval|Mar-26|
|HympavziP<br>FE[TFPI]|hemophilia A / B age 6+|FDA approval|8th June 2026|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D(<br>vsp<br>bo)|REIMAGINE-1 (NCT06323174) PCD Oct'25, headline 6th May 2026; presented<br>ADA|26th June 2026|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D(<br>FDCt<br>rial)|REIMAGINE-2 (NCT06065540) PCD Nov'25. full data at ADA|26th June 2026|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D(<br>add-ont<br>oi<br>nsulin)|REIMAGINE-3 (NCT06323161) full data at ADA|26th June 2026|
|Ziltivekimab[IL-6 inhibitor]|C<br>VOT|P3 ZEUS did not meet priamary endpoint|31st July|
|[F8 mimetic]|H<br>emA|P1 results in healthy male pts was safe and well tolerated; (P1 in haemophilia A<br>ongoing)|4th Aug 2026|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D(<br>H2Hv<br>st<br>irzepatide)|REIMAGINE-4 (5) (NCT06534411)did not show non-inferiority in HbA1c reduction|<br>4th Aug 2026|
|Amylin3<br>55[amylin agonist]|O<br>besity|P1 readout previously expected Q4 2025. Asset remains in P1 pipeline|ongoing|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D|P3 REIMAGINE SWITCH to initiate<br>|Q3 2026|
|Semaglutide2<br>.4mg[GLP-1]|M<br>ASH|EU submission Q1'25; approval 29th Jan; submitted part 1 of ESSENCE trial for<br>label update in Q1'26; EU decision expected|H2 2026|
|SCZ<br>enagamtide(<br>amycretin)[amylin +GLP-1]|A<br>SCVD|P3 to initiate|Q4 2026|
|Oral/SCZ<br>enagamtide(<br>amycretin)[amylin +GLP-1|] T<br>2D|Positive P2 T2D diabetes data; due to initiate P3 AMBITION|Q4 2026|
|Orals<br>ema[25mg]|T<br>2D|sBLA submitted based on PIONEER PLUS data Q4'25; decision expected|Q4 2026|
|Sogroya(somapacitan)|T<br>urnerS<br>yndrome|US decision expected|Q4 2026|
|Etavopivat|Thalassemia/SCD|P2/3 results (HIBISCUS) met primary endpoints 20th Apr. Submission expected|Q4 2026|
|Cagrisema[cagrilintide+semaglutide]|O<br>besity|P3 REDEFINE-1 in obesity readout Dec'24; filing occurred 18th Dec'25; approval<br>expected turn of the year|Q4 2026|
|Ozempic[sema 1.0mg]|E<br>yed<br>iseasei<br>nT<br>2D|P3 FOCUS LT readout|Dec 2026|
|CDR132L(Cardior) [oligonucleotide inhibitor]|c<br>hronich<br>eartf<br>ailure|P2 in chronic heart failure with preserved or reduced ejection fraction ongoing|2026|
|Concizumab|prophylaxis(<br>peads)|Positive P3 data; submission expected|2026|
|Triplea<br>gonist|Obesity|P2 initiated Q2'26; readout expected|Q1 2027|
|Alhemo[TFPI]|HemA<br>/B(<br>+i<br>nhibitors)|US and EU pediatric submission occurred Q1'26. Decisions expected|Q1 2027|
|Ziltivekimab[IL-6 inhibitor]|A<br>MI|P3 ARTEMIS initiated in June'24; readout expected|H1 2027|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D/Obesity|P3 REDEFINE-11 (longer trial with re-escalation)  PCD Dec 2026, readout|H1 2027|
|UBT251(Triple agonist GLP-1/GIP/glucagon)|O<br>besity|P1b/2 trial data readout|H1 2027|
|Ziltivekimab[IL-6 inhibitor]|H<br>FpEF|P3a HERMES initated April'24; readout expected|H1 2027|
|Cagrisema[cagrilintide+semaglutide]|T<br>2D/Obesity(<br>CVOT)|REDEFINE-3 in CVOT initiated; readout expected|H2 2027|
|UBT251(Triple agonist GLP-1/GIP/glucagon)|T<br>2D|P2 initiated June 2026; readout expected|end of 2027|
|Cagrisemah<br>ighd<br>ose[cagrilintide+semaglutide]|T<br>2D/Obesity|Initiated P3 high dose trial May 2026; readout expected|H1 2028|
|SCZ<br>enagamtide(<br>amycretin)[amylin +GLP-1]|O<br>besity|P3 AMAZE-8 H2H sema; readout|H1 2029|
|SCZ<br>enagamtide(<br>amycretin)[amylin +GLP-1]|H<br>FpEF|P3 HF-POLARIS initiated Q2 2026; readout|H2 2029|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 62 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 272: GSK - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|risvutatugr<br>ezetecan+<br>i<br>vonescimab[ADC +PD<br>1 VEGF] (collab with SMMT)|-<br>Solid tumours|Trials in NSCLC, SCLC, CRC announced collaboration|12th Jan 2026|
|Depemokimab[anti-IL5 Ab]|A<br>sthma|P3N<br>IMBLEd<br>idn<br>otm<br>eetp<br>rimarye<br>ndpoint|17thF<br>eb2<br>026|
|Linerixibat[IBAT inhibitor]|C<br>holestaticp<br>ruritusi<br>nP<br>BC|U<br>Sa<br>pprovalb<br>asedo<br>nG<br>LISTENd<br>ata _(Q2’25 submission)_|19thM<br>ar2<br>026|
|x-readD<br>oravirine+<br>I<br>slatravirM<br>RK|HIV|FDA approval|21st Apr 2026|
|mocertatugr<br>ezetecan[B7-H4 ADC]|2L+ EC|P3 BEHOLD-Endometrial01 initiated|Q2'26|
|mocertatugr<br>ezetecan[B7-H4 ADC]|2L+ PROC|P3 BEHOLD-Ovarian01 initiated|Q2'26|
|Arexvy[recomb protein vacc adj.]|R<br>SV|18-49 increased risk  US approval|18thM<br>ay2<br>026|
|Tebipenemp<br>ivoxil[Antibac carbapenem]|UTI|PIVOT-PO stopped early for efficacy; FDA approval|17th Jun 2026|
|e<br>fimosfermina<br>lfa[FGF21 analog]|F4 MASH|P3 NEBULA-1/2 initiated|July 2026|
|Camlipixant[P2X3-R antagonist]|R<br>efractoryc<br>hronicc<br>ough|P3C<br>ALM-1m<br>etp<br>rimarye<br>ndpoint;C<br>ALM-2d<br>idn<br>otm<br>eetp<br>rimarye<br>ndpoint;d<br>iscontinued|1<br>7thJ<br>uly2<br>026|
|Jideytro(<br>Zidesamtinib)[ROS1 TKI]|ROS1+ NSCLC|FDA approval based on P3 ARROS-1|22nd July 2026|
|risvutatugr<br>ezetecan [B7-H3 ADC]|2L SCLC|P3 ARTEMISpositive data|28th July2026|
|x-readL<br>enacapavir+<br>I<br>slatravir[GILD/MRK]|HIV|P3 ISLEND-1/2 positive topline 8th June; full data at AIDS 2026|30th July 2026|
|x-readB<br>ictegravir/Lenacapavir[GILD]|HIV|FDA decision based on ARTISTRY-1 & 2 PDUFA date|27th Aug 2026|
|x-readI<br>-DXd[MRK]|ESCLC|FDA PDUFA|10th Oct 2026|
|Bepirovirsen[Antisense oligonucleotide]|HBV|P3 BE-WELL positive topline 7th Jan 2026; data presented at EASL 2026; launch 2027; PDUFA|26th Oct 2026|
|Neladalkib[ALKi]|ALK+ NSCLC/solid tumors|Acquired from Nuvalent 9th June 2026; PDUFA TKI-pretreated|27th Nov 2026|
|mocertatugr<br>ezetecan[B7-H4 ADC]|gyne cancers|3x P3 BEHOLD studie to initiate (O02, O03, E02)|H2 2026|
|Arexvy[recomb protein vacc adj.]|R<br>SV|18-49 immunocomp US  decision|H22<br>026|
|Cabotegravir[Integrase inhibitor]|H<br>IV|Q4MP<br>rEPP<br>3r<br>eadout+<br>U<br>S/EUr<br>egs<br>ubmission(<br>decisiona<br>ndl<br>aunchH<br>12<br>027)|H<br>22<br>026|
|Depemokimab[anti-IL5 Ab]|EGPA|P3 OCEAN readout (submission H1 2027 regulatory decision H2 2027)|H2 2026|
|Jemperli[Anti-PD-1 Ab]|Rectal cancer|P3 AZUR positive headline 13th Jul 2026. submission H2'26 with accelerated approval; PDUFA|Feb 2027|
|risvutatugr<br>ezetecan[B7-H3 ADC]|prostate/lung cancer|P3 EMBOLD initiation of additional studies (SCLC 303, prostate-302/304/203)|H2 2026|
|velzatinib [KITi]|1L GIST|P3 StrateGIST FrontLine initiation|H2 2026|
|Jideytro(<br>Zidesamtinib)[ROS1 TKI]|ROS1+ treatment naïve  NSCLC|US submission (decision H2'27)|H1 2027|
|Ventolin|Low carbon MDI|P3 readout Q3'25 - EU submission Q4'25. Expected EU approval|H1 2027|
|Ventolin|Low carbon MDI|US submission|H1 2027|
|cabotegravir+<br>r<br>ilpivirine[Integrase inhibitor<br>+NNRTI]|Q4M HIV|P3 CUATRO readout (launch 2028)|H2 2027|
|risvutatugr<br>ezetecan[B7-H3 ADC]|2L SCLC|P3 EMBOLD-SCLC-301 data expected|2027|
|Arexvy[recomb protein vacc adj.]|RSV immune response 60+|China data, 60+ years, accepted regulatory review in CN Feb'25 decision expected|2027|
|Q6MH<br>IVc<br>hoice|H<br>IV|assetc<br>hoicec<br>onfirmatione<br>xpected2<br>026;r<br>egistrations<br>tudyt<br>os<br>tart||



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 63 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 273: Novartis - upcoming catalysts 

|**Product**|**Indication**|**Event/Comments**|**Date**|
|---|---|---|---|
|**Leqvio**[siRNA (regulation of LDL-C)]|Hyperlipidemia (peds)|P3 ORION readout + submission occurred|Q3 2025|
|**x-read icotrokinra (IL-23)**[_JNJ]_|PsO|FDA approval|18th Mar 2026|
|**Del-brax**[AOC]|FSHD|P1/2 FORTITUDE positive headline|11th June 2026|
|**Votoplam (PTC518)**|HD|HD P2 met primary endpoint in Q2; P3 initiated|Mar-26|
|**GIA632**[IL-15 mAb]|Vitiligo|P2 initiated|Mar-26|
|**Ianalumab**[BAFFi; ADCC]|Waiha|P3 VAYHIA missed primary endpoint|Apr-26|
|**Del-zota**[AOC]|DMD|US submission|25th June 2026|
|**NIO752**[ASO]|PSP|P3 initiated (specifically for US submission) (EU submission expected H2 2026)|Jun-26|
|**Pelabresib**[BETi]|MF|P3 initiated (specifically for US submission) (EU submission expected H2 2026)|Jun-26|
|**x-read Enlicitide (PCSK9)**[MRK]|HeFH|FDA approval based on CORALreef studies|17th July 2026|
|**Pelacarsen**[ASO targeting Lp(a)]|**CVRR-Lp**|**Readout of P3 HORIZON CVOT outcomes study (event driven) (submission expected H2 2026)**|**mid-year**|
|**Ianalumab [BAFFi; ADCC]**|**Sjogren's**|**P3 NEPTUNUS readout Oct'25;  submission occurrred Q1 2026 with priority review, launch expected**|**H2 2026**|
|**Cosentyx**|PMR|Readout for P3 REPLENISH met primary endpoint [GCA did not meet PE Q2'25]; approval|H2 2026|
|**Pluvicto**[177-Lu-PSMA-617]|mHSPC|PSMAddition readout in mHSPC in Q2’25 at ESMO and US submission occurred Q4'25; approval|H2 2026|
|**Remibrutinib**[BTKi]|RMS|P3 REMODEL-1/2 positive headline 1st Sep; full data to be presented MSToronto (submission in 2027)|21-23rd Oct|
|**Ianalumab**[BAFFi; ADCC]|1L ITP|P3 VAYHIT2 data presented at ASH; VAYHIT1 readout (submission expected 2027)|H2 2026|
|Del-desiran(TfR1 mAb)_[RNA]_|DM1|P3 HARBOR readout|H2 2026|
|**Remibrutinib**[BTKi]|HS|P3 RECHARGE 1/2 due to read out|H2 2026|
|**Remibrutinib**[BTKi]|CIndU|Positive P3; on track for FDA approval of SD; FDA submission of cold and cholinergenic forms|H2 2026|
|**Remibrutinib**[BTKi]|FA|P2 positive data Q2'25, P3 initiation|H2 2026|
|**Farabursen**[MIR17]|ADPKD|P3 initiation|H2 2026|
|**QCZ484**|Hypertension|P2 readout (regulatory submission 2028+)|H2 2026|
|**VHB937**[TREM2]|ALS|P2 ASTRALS readout|H2 2026|
|**KLU156**|Malaria|P3 data presented 2025, planned submission|2026|
|**x-read obicetrapib**[NAMS]|ASCVD|P3 PREVAIL CVOT interim data|YE 2026|
|**Rydapt**[multi kinase inhibitor]|AML|P2 readout (submission in 2027)|2026|
|**Zigakibart**[Anti-APRIL]|IgAN|P3 BEYOND readout (UPCR and eGFR) (submission expected 2027)|H1 2027|
|**Abelacimab**[FXI]|AF|P3 LILAC readout (submission 2028)|2027|
|**Leqvio**[siRNA (regulation of LDL-C)]|CV disease|P3 VICTORION-2p started Q1'23; CV events in high LDL-C readout (submission 2027)|2027|
|**Kesimpta**|MS (new dosing)|P3 FILIOS readout (regulatory filing 2027)|2027|
|**Fabhalta (Iptacopan)**[CFB inhibitor]|gMG|P3 readout (submission in 2027)|2027|
|**DII235**[siRNA targetting Lp(a)]|CVRR-Lp(a)|P2b readout|2027|
|**YTB323**[CD19 CAR-T]|srSLE/LN and BCL and AAV|Recruitment for 4 P2 studies ongoing, first readout 2027+ (first submission 2028)|2027|
|**Leqvio**[siRNA (regulation of LDL-C)]|HeFH|P3 ORION-4 readout|2027|
|**Lutathera**[SSTR radioligand]|GEP-NETs|P3 readout + Regulatory filing|2028|
|**Pluvicto**[177-Lu-PSMA-617]|Oligometastatic PC|Ph3 PSMA-DC started in Q1 2024 (submission expected 2029+)|2028|
|**Ac-PSMA-617 PC**[PSMA Radioligand]|Prostate cancer|P3 ActFIRST started in Q2'25, readout|2028|
|**Remibrutinib**[BTKi]|MG|P3 RELIEVE due to read out and submission|2028|
|**Fabhalta (Iptacopan)**[CFB inhibitor]|**aHUS**|**P3 APPRECIATE expected to read out  (submission 2029+)**|**2028**|
|**Fabhalta (Iptacopan)**[CFB inhibitor]|IC-MPGN|P3 APPARENT readout (submission 2029+)|2028|
|**Del-brax**[AOC]|FSHD|P1/2  positive headline 11th June 2026; P3 FORTITUDE-3 (FORWARD) readout and submission|2028|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 64 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 274: AstraZeneca - upcoming catalysts 

|Product|Indication|Event/Comments|Companyd<br>ata|
|---|---|---|---|
|Breztri[LAMA/LABA/ICS]|COPD|P2/3 ATHLOS - removed from development|Q1'26|
|<br>Ultomiris[anti-C5 mAb]|CSA-AKI|<br>P3 ARTEMIS - discontinued due to efficacy|<br>Q1'26|
|Calquence[BTK inhibitor]|1L CLL (fixed duration)|P3 AMPLIFY US approval|20th Feb 2026|
|Imfinzi[PD-L1 mAb]|locoregional HCC|P3 EMERALD-3 full readout at ASCO. Positive headline|2nd Apr 2026|
|Saphnelo[IFN-1 mAb]|moderate to severe SLE|P3 TULIP-SC positive readout, received CRL 3rd Feb 2026, approval|27th Apr 2026|
|Breztri[LAMA/LABA/ICS]|Severe asthma|KALOS and LOGOS approval|28th Apr 2026|
|Eneboparatide[PTH-1 agonist]|hypoparathyroidism|P3 CALYPSO 52 week readout|12th May 2026|
|Imfinzi[PD-L1 mAb]|muscle-inv. bladder cancer|P3 VOLGA readout|14th May 2026|
|Enhertu[HER2 ADC]|High risk HER2+ early BC|P3 DESTINY-Breast11/05 US approval|15th May 2026|
|baxdrostat[aldosterone-syn inhib]|uncontrolledh<br>ypertension|BaxHTNa<br>pproved|18thM<br>ay2<br>026|
|Dato-Dxd[TROP2 ADC]|TNBCm<br>etastatic|TROPION-Breast02F<br>DAa<br>pproval|22ndM<br>ay2<br>026|
|Imfinzi[PD-L1 mAb]|non-MIBC|P3 POTOMAC FDA approval|28th May 2026|
|AZD5004[oral GLP1-1]||P2b SOLSTICE/VISTA positive headline; full data at ADA|5th Jun 2026|
|Truqap[AKT inhibitor]|PTEN-deficient mCRPC|P3 CAPItello-281 approval|12th Jun 2026|
|x-readT<br>rodelvy(Trop-2) [GILD]|1L mTNBC|ASCENT-03/04 FDA approval|24th June 2026|
|Ultomiris[anti-C5 mAb]|HSCT-TMA|P3 TMA-313 did not meet primary endpoint|Q2'26|
|Imfinzi[PD-L1 mAb]|1L bladder cancer|<br>P3 NILE met primary endpoint|Q2'26|
|Imfinzi[PD-L1 mAb]|early HCC|P3 EMERALD-2 did not meet primary endpoint|Q2'26|
|AZD6234[amylin]|Obesity|P2 APRICUS readout|Q2'26|
|sonesitatugv<br>edotin [CLDN18.2]|CLDN18.2+gastric cancer(2L+)|P3 CLARITY-Gastric01positive headline|26th July2026|
|x-readI<br>vonescimab[SMMT]|sq 1L NSCLC|P3 HARMONi-3 interim PFS readout  (final readout expected H1 2027)|H2 2026|
|Camizestrant[oral SERD]|ESR1mH<br>R+H<br>ER2-m<br>BC(<br>1Ls<br>witch)|P3S<br>ERENA-6d<br>ata@<br>ASCO'25;U<br>SA<br>DCOMM3<br>0thA<br>pril.F<br>DAd<br>ecision|H22<br>026|
|Camizestrant[oral SERD]|allc<br>omerH<br>R+/HER2m<br>BC(<br>1L)|P3S<br>ERENA-4r<br>eadout|H22<br>026|
|Dato-Dxd+<br>I<br>mfinzi[TROP2 + PD-L1]|NSQT<br>ROP2+1<br>LN<br>SCLC|P3A<br>VANZARr<br>eadout|H22<br>026|
|Enhertu[HER2 ADC]|High-riskH<br>ER2-positiveB<br>C[<br>mono]|P3D<br>ESTINY-Breast09E<br>nhertum<br>onoa<br>rmr<br>eadout _(combo arm @ASCO'25)_|H22<br>026|
|Volrustomig[PD-1/CTLA-4 bispecific mA|b1L mNSCLC (PD-L1+, TPS�50%)|P3 eVOLVE-Lung02 discontinued following recommenation from IDMC|17th Aug 2026|
|<br>Enhertu[HER2 ADC]|<br>HER2m NSCLC|<br>P3 DESTINY-Lung04 positive PFS headline|<br>17th Aug 2026|
|Dato-Dxd+<br>T<br>agrisso[TROP2 + EGFRi]|EGFRm NSCLC (2L)|P3 TROPION-Lung15 readout|H2 2026|
|Tagrisso[EGFR inhibitor] +<br>O<br>rpathys|EGFRm NSCLC|P3 SAFFRON positive PFS headline|17th Aug 2026|
|AZD6234[amylin]|Obesity|P2 ARAY readout|H2 2026|
|AZD9550+AZD6234[GLP-1 glucagon<br>|Obesity|P2b ASCEND trial readout|H2 2026|
|agonist + selective amylin agonist]||||
|anselamimab[fibril-reactive mAb]|AL amyloidosis (Mayo Stg. IIIa/b)|P3 CARES-301/2 primary endpoint not met in overall population; regulatory decision<br>expected|H2 2026|
|gefurulimab[anti-C5 Ab]|Myasthenia gravis|<br>P3 PREVAIL met primary endpoint; regulatory decision expected|H2 2026|
|Lynparza[PARP inhibitor]|1L PARP BRCAwt ovarian cancer|P3 MONO-OLA-1 readout|H2 2026|
|Imfinzi+<br>o<br>leclumab/monalizumab[PD-L|1Stage 3 NSCLC|P3 PACIFIC-9 readout|H2 2026|
|Tezspire[<br>TSLPm<br>Ab]|EoE|P3 CROSSING readout|H2 2026|
|x-readT<br>rodelvyG<br>ILD[Trop-2]|1L mNSCLC (PD-L1+, TPS�50%)|P3 EVOKE-03 did not meet primary endpoint|8th June 2026|
|Wainua[ligand-conj antisense]|ATTR-CM|P3 CARDIO-TTRansform negative headline 9th july; full data ESC|Aug-26|
|x-readK<br>eytruda(<br>Qlex)[MRK]|MIBC|FDA PDUFA|17th Aug 2026|
|x-readI<br>-DXd[MRK]|ESCLC|FDA PDUFA|10th Oct 2026|
|x-readI<br>vonescimab[SMMT]|EGFRm nsq NSCLC|HARMONi PDUFA|14th Nov 2026|
|Ultomiris [anti-C5 mAb]|IgAN|P3 ICANpositive headline 21st Apr; PDUFA|Q4'26|
|x-readK<br>eytruda[MRK]|MIBC|P3 KEYNOTE-992 Keytruda + chemoradiotherapy PCD|Jan-27|
|x-readS<br>ac-TMT(<br>TROP-2)[MRK]|3L + adv/met GEJ|First of 17 P3 TroFuse PCD - TroFuse-015|Jan-27|
|x-readI<br>vonescimab[SMMT]|nsq 1L NSCLC|P3 HARMONi-3 final readout  (est enrollment completion H2 2026)|H1 2027|
|efzimfotasea<br>lfa[next-gen asfotase alfa]|hypophosphatasia|P3 headline HICKORY (missed primary endpoint) /CHESTNUT &N MULBERRY<br>(positive high level data) March 2026; regulatory decision expected|H1 2027|
|laroprovstat[PCSK9 inhibitor]|Dyslipidaemia (PCSK9/LDL-lowering)|P3A<br>ZUREr<br>eadout[<br>3t<br>rialso<br>ngoingi<br>nd<br>yslipidaemia,H<br>eFHa<br>ndh<br>ighr<br>iskp<br>ts]|H12<br>027|
|Dato-Dxd[TROP2 ADC]|NSQ NSCLC (1L)|P3 TROPION-Lung07 readout|H1 2027|
|<br>tozorakimab[IL-33 ligand mAb]|<br>lupus nephritis / systemic sclerosis|<br>P3 IRIS/DAISY readout|H1 2027|
|balcinrenone/dapagliflozin[MR antagon|isHF with renal impairment|P3 BalanceD-HF|H1 2027|
|zibotentan/dapagliflozin[ETA receptor a|nCKD and high proteinuria|P3 ZENITH readout|H1 2027|
|Saphnelo [IFN-1 mAb]<br>saruparib[next-gen PARPi]|CLE<br>Breast/Prostate|P3 LAVENDER readout<br>P3 EvoPAR-Breast01/Prostate01 readout|H1 2027<br>H2 2027|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 65 

Deutsche Bank AG 

#### This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 275: Roche - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|CT-388[GLP-1/GIP]|Obesity|P21<br>03/104(<br>Obesity+<br>/-T<br>2D)p<br>ositiver<br>eadouto<br>ccurred|27thJ<br>an2<br>026|
|Fenebrutinib[BTKi]|PPMS|P3F<br>ENtrepidr<br>eadouta<br>tA<br>CTRIMS|Feb'26|
|CT-868Q<br>DS<br>C[GLP-1/GIP]|Obesity|Positive P2 004 (T1D w. OW/OB as adjunct treatment) readout|Q1 2026|
|NXT007[next gen FVIIIa mAb]|HemA|P2 data @ISTH'25; P3 ZEBRHA-1 & 2 initiated Q1'26; readout expected|2028|
|Gazyva[immunology]|INS|P3 INShore positive readout Q4 2025. US filing occurred Q1'26; PDUFA|27th Sep 2026|
|GYM329[anti-myostatin]|FSHD|P2 MANOEUVRE discontinued|Mar'26|
|Evrysdi+<br>G<br>YM329 [SMN2 splicingmodifier]|SMA|P2/3M<br>ANATEEd<br>iscontinued|Mar'26|
|Fenebrutinib[BTKi]|RMS|P3F<br>ENhance-1p<br>ositiveh<br>eadline2<br>ndM<br>arch,F<br>ENhance1<br>a<br>nd2<br>p<br>resentedA<br>AN|22ndA<br>pr2<br>026|
|Giredestrant+<br>p<br>albociclib[SERD]|1<br>LE<br>R+/HER2m<br>BC|P3p<br>ersevERAd<br>idn<br>otm<br>eetp<br>rimarye<br>ndpoint9<br>thM<br>arch,d<br>atae<br>xpecteda<br>tA<br>SCO|29thM<br>ay-2ndJ<br>un|
|HympavziP<br>FE[TFPI]|hemophilia A / B age 6+|FDA approval|8th June 2026|
|Petrelintide[GLP-1/GIP + Amylin]|Obesity+<br>/-T<br>2D|P2Z<br>UPREME-1d<br>atap<br>resenteda<br>tA<br>DA|5th-8thJ<br>une|
|Divarasib[KRAS G12C]|2L KRASG12C+ NSCLC|P3 KRASCENDO 1 positive headline|2nd July 2026|
|Vabysmo|CNV|P3 POYANG metprimaryendpoint|July2026|
|CT-388+<br>P<br>etrelintide[GLP-1/GIP + Amylin]|Obesity|P2Z<br>YNERGYt<br>oi<br>nitiate|H22<br>026|
|Enspryng[IL-6]|MOG-AD|Positive P3 METEOROID headline Jan 2026. Data readout AAN (Apr). Filing expected|H2 2026|
|Vamikibart[IL-6 mAb]|UME|SANDCAT/MEERKAT readouts Oct'25; filing expected|H2 2026|
|PiaSky[C5 inhibitor]|aHUS|US/EU filing|H2 2026|
|Itovebi+<br>f<br>ulvestrant[PI3K�inhibitor]|post CDKi HR+ mBC|P3 INAVO121 readout|H2 2026|
|Itovebi+<br>P<br>hesgo[PI3K�inhibitor]|PIK3CA-mut HER2+ mBC|P3 INAVO122 readout|H2 2026|
|Susvimo[<br>eyei<br>mplant]|nAMD|EU approval|H2 2026|
|sefaxersen[ASO factor B]|IgAN|P3 IMAGINATION interim readout|H2 2026|
|CT-996Q<br>Do<br>ral[GLP-1]|Obesity|P2 readout|H2 2026|
|CT-996Q<br>Do<br>ral[GLP-1]|Obesity|P3 initiation|H2 2026|
|Lunsumio+<br>l<br>enalidomide[anti-CD20/3]|2L+ FL|P3 CELESTIMO readout expected|H2 2026|
|Petrelintide[GLP-1/GIP + Amylin]|Obesity+<br>/-T<br>2D|P2Z<br>UPREME-2o<br>ngoing;d<br>atae<br>xpected|H22<br>026|
|Enspryng[Anti-IL-6 mAb]|TED|P3 SatraGO-1/2 one failed to meet primary endpoint; PDUFA|15th Oct 2026|
|Emugrobart/GYM-329c<br>ombo[GLP-1 + anti-myostatin]|Obesity|P<br>2<br>G<br>Y<br>M<br>I<br>N<br>D<br>A<br>(<br>E<br>m<br>u<br>g<br>r<br>o<br>b<br>a<br>r<br>t<br>+<br>t<br>i<br>r<br>z<br>e<br>p<br>a<br>t<br>i<br>d<br>e<br>)<br>i<br>n<br>i<br>t<br>i<br>a<br>t<br>e<br>d<br>Q<br>2<br>’<br>2<br>5<br>;<br>r<br>e<br>a<br>d<br>o<br>u<br>t<br>e<br>x<br>p<br>e<br>c<br>t<br>e<br>d<br>H<br>2<br>2<br>0<br>2<br>6<br>;<br>PCD(<br>NCT06965413)|Oct2<br>026|
|Gazyva[immunology]|MN|P3 MAJESTY data presented at ERA; PDUFA|15th Nov 2026|
|Giredestrant[SERD]|adjuvantE<br>R+/HER2-e<br>arlyB<br>C|(lidERA)f<br>iledi<br>nU<br>SQ<br>1'26-<br>P<br>DUFA|30thN<br>ov2<br>026|
|Gazyva[immunology]|SLE|US filing accepted 20th Apr 2026. PDUFA|4th Dec 2026|
|Giredestrant+<br>e<br>verolimus[SERD]|p<br>ostC<br>DKiE<br>R+/HER2m<br>BC|USf<br>illingD<br>ec'25(<br>evERA)P<br>DUFA|18thD<br>ec2<br>026|
|x-readT<br>ulisokibart[MRK]|UC|P3 ATLAS-UC PCD|Aug-26|
|x-readE<br>YE103/MRK-3000[MRK]|DME|P2/3 BRUNELLO PCD|Sep-26|
|x-readI<br>vonescimab[SMMT]|EGFRm nsq NSCLC|HARMONi PDUFA|14th Nov 2026|
|x-readI<br>vonescimab[SMMT]|sq 1L NSCLC|P3 HARMONi-3 readout|H2 2026|
|x-readI<br>vonescimab[SMMT]|nsq 1L NSCLC|P3 HARMONi-3 readout|H1 2027|
|x-readg<br>olodirsen/Vyondys5<br>3[SRPT]|DMD|FDA PDUFA|28th Feb 2027|
|Lunsumio+<br>P<br>olivy[anti-CD20/79]|R/R LBCL|PDUFA based on P3 SUNMO|9th Feb 2027|
|Giredestrantp<br>lusC<br>DK4/6i[SERD]|1L ER+/HER2- mBC (resistant)|P3 pionERA PCD (NCT06065748)|Feb 2027|
|Columvi[anti-CD20/3]|r/r mantle cell lymphoma|P3 GloBryte PCD (NCT06084936)|Aug 2027|
|Giredestrant [SERD]|1L maint ER+/HER2+ BC|P3 heredERA PCD|Oct 2027|
|Susvimo [<br>eyei<br>mplant]|DME|EU filing|2027|
|Trontinemab[BS anti A�mAb]||FinalP<br>1/2d<br>ata+<br>P<br>3d<br>esignp<br>resented@<br>AAIC'25;P<br>3i<br>nitiatedS<br>ep'25(final readout<br>in 2028)||
|CT-388 [GLP-1/GIP]|Obesity|P3 (<br>enith1/2)i<br>nitiatedQ<br>1'26;P<br>CDJ<br>uly/Aug2<br>028|Jul2<br>028|
|afimkibart[Anti-TL1A]|IBD(<br>UC)|P3A<br>METRINE-1/2P<br>CD|Mar2<br>030|
|<br>afimkibart[Anti-TL1A]|<br><br>IBD(<br>CD)|P3S<br>IBERITE-1/2P<br>CD|May2<br>030|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 66 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 276: Sanofi - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Cerezyme|Gaucherd<br>isease|PDUFAd<br>ate-<br>a<br>pproved|13thJ<br>an2<br>026|
|Amlitelimab[OX40 mAb]||OCEANAA<br>Dp<br>rogram(<br>SHORE,C<br>OAST2)r<br>eadout|23rdJ<br>an2<br>026|
|Amlitelimab[OX40 mAb]|A<br>sthma|P2m<br>ixedd<br>ataw<br>ithh<br>ighd<br>ose-<br>r<br>emovedf<br>romp<br>ipeline|Q1'26|
|SP0230|Meningitis|reverted for reformulation - P2 readout previously expected H1 2026|Q1 2026|
|SP0289[Flu H5 mRNA]|pandemic influenza|P1/2 study initiated Q1'25; PCD|Mar-26|
|SP0287[Flu+COVID vaccine]|influenza & COVID-19 vaccine|Two P1/2 studies initiated Q1'25; PCD|Apr-26|
|lunsekimigS<br>C[IL13xTSLP]|CRSwNP|P2a DUET met primary endpoint|7th Apr 2026|
|lunsekimigS<br>C[IL13xTSLP]|AD|P2b VELVET did not meet primary endpoint - removed from pipeline|7th Apr 2026|
|Dupixent[IL4/IL13 mAb]|CSU peds|Approved in US|22nd Apr 2026|
|Riliprubart[C1s inhibitor]|CIDP|P3 MOBILIZE (IV-IG refractory) terminated|10th June 2026|
|HympavziP<br>FE[TFPI]|hemophilia A / B age 6+|FDA approval|8th June 2026|
|Amlitelimab[OX40 mAb]||OCEANAA<br>Dp<br>rogramd<br>iscontinued|24thJ<br>uly2<br>026|
|Venglustat[Oral GCS inhibitor]|Fabry disease|P3 primary endpoint not met - terminated in Fabry disease|Q2'26|
|Balinatunfib[oral TNFR1si]|UC/CD|P2 SPECIFY-CD terminated|Q2'26|
|Itepekimab[IL33 mAb]|C<br>OPD|AERIFY-1m<br>ete<br>ndpoint;A<br>ERIFY-2d<br>idn<br>ot;a<br>ssetd<br>iscontinued|Q<br>2'26|
|x-readS<br>GMOS<br>T-920/Isaralgagene<br>Civaparvovec[Gene therapy]|Fabry disease|Expected completion of BLA rolling submission|Q2 2026|
|Dupixent [IL4/IL13 mAb]|Lichen simplex chronicus|P3 did not meetprimaryendpoint|Q2'26|
|efdoralprina<br>lfa[AAT fusion protein]|AA1T deficiency|P3 ElevAATetrial met primary endpoints US submission|H2 2026|
|x-readA<br>POGZ<br>umilokibart[IL-13]|AD|P2 part B 16-week data presented May 2026;P3 initiation expected|H2 2026|
|x-readA<br>POGZ<br>umilokibart+<br>A<br>PG279[<br>IL-13+<br>OX40L]|AD|P1b H2H vs Dupixent PoC data|H2 2026|
|SP0087[Rabies vero cell vaccine]|rabies|US submission and EU approval expected|H2 2026|
|Nexviazyme[enzyme replacement therapy]|IOPD|P3 met primary endpoint; US regulatory submission|H2 2026|
|FluzoneH<br>D|influenza 50+|Filing US/EU Q1'26, US decision expected (EU 2027)|H2 2026|
|Venglustat [Oral GCS inhibitor]|Gaucher T3|Positive P3 readout 2nd Feb 2026; PDUFA|25th Nov 2026|
|lunsekimigS<br>C[IL13xTSLP]|moderate/severe asthma|P2 AIRCULES met primary endpoint, AIRLYMPUS readout|H1 2027|
|Riliprubart[C1s inhibitor]|CIDP|P3 VITALIZE (on IV-IG) readout (to be evaluated following MOBILIZE termination)|2027|
|SP0218(vaccine)|Yellow fever|EU submission|2027|
|SP0202[pneumococcal-21 vaccine]|infant pneumococcal disease|P3 program initiated Q1'25;data readout|2027|
|Brivekimig[TNFxOX4OL Nanobody VHH]|HS|P2b BRIGHTEN readout|2027|
|Frexalimab [CD40L]|RMS|P3 initiated H1'24; expected regulatorysubmission|2027|
|Duvakitug[anti-TL1A]|I<br>BD|P3S<br>UNSCRAPEa<br>ndS<br>TARSCAPEi<br>nitiatedQ<br>3'25.P<br>2bR<br>ELIEVEd<br>atap<br>resentedF<br>eb'26.<br>FirstP<br>CD|May2<br>028|
|SP0218(vaccine)|Yellow fever|US submission|2028|
|Rilzabrutinib [BTK inhibitor]|IgG4-RD|P3 data and submission|2028|
|Rilzabrutinib [BTK inhibitor]|wAIHA|P3 data and submission|2028|
|Frexalimab [CD40L]|SPMS|P3 data and regulatorysubmission|2028|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 67 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Mid-Cap Companies 

###### Figure 277: Genmab - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Epkinly[CD3xCD20 duobody]_(with ABBV)_|2L R/R DLBCL (ASCT ineligible)|P3 EPCORE-DLBCL-1 (vs SoC) did not reach statistical significance headline|16th Jan 2026|
|x-readCorcept relacorilant|PROC|FDA approval|25th Mar 2025|
|Rina-S_[FR�-TOPO1 ADC]_|2L PSOC platinum-doublet  chemo re|placemP3 RAINFOL-07 announced|Q1'26|
|Rina-S_[FR�-TOPO1 ADC]_|1L pMMR EC|P3 RAINFOL-08 announced|Q1'26|
|Rina-S_[FR�-TOPO1 ADC]_|GI Cancers|P2 PoC RAINFOL-09 initiated|Q2'26|
|Epkinly [CD3xCD20 duobody] _(with ABBV)_|2L R/R DLBCL|P3 EPCORE-DLBCL-4(+Lena)metprimaryendpoint;headine|29th June 2026|
|petosemtamab[EGFR+LGR5]|1L CRC|P3 trial to initiate|H2 2026|
|petosemtamab[EGFR+LGR5]|2L+ CRC|P3 trial to initiate|H2 2026|
|petosemtamab[EGFR+LGR5]|Locally advanced HNSCC|P3 trial to initiate|H2 2026|
|petosemtamab[EGFR+LGR5]|1L r/m HNSCC|P3 LiGeR-HN1 readout|Q4 2026|
|Rina-S_[FR�-TOPO1 ADC]_|PROC|P2 RAINFOL-01 readout|Q4 2026|
|Rina-S_[FR�-TOPO1 ADC]_|PROC|P3 RAINFOL-02 enrolling, data expected (2027 launch)|Q4 2026|
|Epkinly[CD3xCD20 duobody]_(with ABBV)_|1L DLBCL|P3 EPCORE-DLBCL-2 (+R-CHOP) readout (launch 2027)|Q4 2026|
|x-readREGN odronextamab|R/R FL|approval ongoingwith CRL issued Q2'25|2026+|
|petosemtamab[EGFR+LGR5]|2L/3L r/m HNSCC|P3 LiGeR-HN2 readout|Q1 2027|
|Rina-S_[FR�-TOPO1 ADC]_|NSCLC|P2 RAINFOL-05 initiated H2'25; data expected|2027|
|Rina-S [FR�-TOPO1 ADC]|2L+ Endo|P3 RAINFOL-03 readout|2027|
|Mim8_(with NOVO)_|HemA|P3 FRONTIER 4 data|PCD: Jun 2028|
|Rina-S_[FR�-TOPO1 ADC]_|2L PSOC maintenance|P3 RAINFOL-04  initiated H2'25; data expected|2028|
|Epkinly[CD3xCD20 duobody]_(with ABBV)_|1L FL|P3 EPCORE-FL-2 readout (launch 2031)|2030|
|_Source : Company data, Deutsche Bank Research (last_|_updated post-Q2'26)_|||



###### Figure 278: Grifols - upcoming catalysts 

|Product<br>Indication<br>BiotestF<br>ibrinogen<br>Bleedingd<br>isorder|Event/Comments<br>EUl<br>aunchQ<br>4'25;U<br>Sa<br>pprovalD<br>ec'25a<br>ndl<br>aunched|Date<br>Q<br>2'26|
|---|---|---|
|_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_|||



Page 68 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

Figure 279: Ipsen - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Tazverik|2L FL|P3 SYMPHONY-1 (NCT04224493) asset withdrawn due to safety<br>concerns in trial|Mar-26|
|IPN60250/ritivixibat|PSC|P2 (NCT05642468) no meaninful conclusion made due to small<br>enrollment|Apr'26|
|Tovorafenib(<br>Ojemda)|pediatric low-grade glioma|P3 FIREFLY-1 EU approval|22nd Apr 2026|
|Corabotase(<br>IPN10200<br>Ax)|Upper facial lines|P2 LANTIC (NCT04821089)  full data presented.|May-26|
|ICT01|1L AML|P2b/3 EVICTION-3 initiated|Q2'26|
|Dysport|Chronic migrane|P3 C-BEOND (NCT06047444) positive headline|9th Jul 2026|
|Dysport|Episodic migrane|P3 E-BEOND (NCT06047457) rpositive headline|9th July 2026|
|Bylvay|Biliary atresia|P3 BOLD (NCT04336722) did not meet primary endpoint|24th Jul 2026|
|Somatuline(<br>x-readf<br>rom<br>generics)|N/A|Further sandostatin entries|ongoing|
|Daraxonrasib[<br>RVMD]|mPDAC|Est PDUFA using CNPV|22nd Sep 2026|
|Corabotase(<br>IPN10200<br>Ax)|Glabellar Lines|P3 LAURITE-1/2 (NCT07427797/NCT07435428) initiated Q3'25; PCD|Dec-26|
|Corabotase(<br>IPN10200<br>Ax)|Cervical Dystonia|P2 CATALPA (NCT06937931) PCD|Mar-27|
|Navtemadlin|Myelofibrosis<br>Mono in newly diagnose|P3 POIESIS readout|2027|
|Tovorafenib(<br>Ojemda)|children & young adults with<br>RAF-mutated glioma|P3 FIREFLY-2 readout (NCT05566795) readout (PCD: Feb'26)|2027|
|IPN10200T<br>x|Chronic and episodic migraine|P2 MERANTI (NCT06625060) readout (PCD: May'27)|2027|
|IPN10200T<br>x|Upper-limb spasticity (adults)|P2 LANTIMA (NCT04752774) readout (PCD: Oct'27)|2027|
|IPN1194|Solid tumors|P1/2a(NCT06305247)PCD|Mar-28|
|_Source : Company data, Deutsche B_|_ank Research (last updated post-Q2'26)_|||



Figure 280: Lundbeck - upcoming catalysts 

|Product|Indication|E<br>vent/Comments|Date|
|---|---|---|---|
|Vyepti(<br>eptinezumab)|Migraine|Expanding filing in Asia (SUNRISE data<br>published Jun'25)|14th Nov 2025|
|LuA<br>F28996(<br>D1/D2a<br>gonist;P<br>arkinson's)|Parkinson's|P1b data at AD/PD 2026|Mar'26|
|LuA<br>F28996(<br>D1/D2a<br>gonist;P<br>arkinson's)|Parkinson's|Poc P2 initiated|Jul-26|
|Asedebart/LuA<br>G13909(<br>anti-ACTHm<br>Ab)|CAH/aCS|CAH proof of mechanism P1b readout Q2'25 -<br>P2 initiated|Q1'26|
|Bexicaserin(<br>LongboardP<br>harmaceuticals)|Epilepsy|P2 PACIFIC OLE data presentation at AAN|Apr'26|
|||TED P1b  data at ENDO 2026; did not||
|LuA<br>G22515(<br>CD40L)|TED(<br>andM<br>S?)|translate to clinical effect; evaluating other<br>indications|Jun'26|
|Bocunebart/PACAP(<br>migraine)|Migraine|P2 study (NCT06323928) data presented at<br>American Headache SocietyCongress|4th Jun 2026|
|Bocunebart/PACAP(<br>migraine)|Migraine|P3 initiation expected|H2 2026|
|Bexicaserin(<br>LongboardP<br>harmaceuticals)|Dravets<br>yndrome|P3 DEEp SEA enrollment expected to<br>complete|H2 2026|
|Bexicaserin(<br>LongboardP<br>harmaceuticals)|Epilepsy|P3 DEEp OCEAN enrollment completed 20th<br>July;readout expected|Q4'26|
|Amlenetug(<br>alpha-synuclein)|MSA|P3 initiation achieved; enrolled ahead of<br>schedule Q1'26; data readout|Q3'27|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 69 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 281: SOBI upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Aspaveli/Empaveli[C3 inhibitor]|CG3/IC-MPGN|EU approval|Jan 2026|
|Kineret[IL1 antagonist]|Still's disease|Japan regulatory submission occurred Q3 2025, approved|Q2 2026|
|Zynlonta[CD19 ADC]|2L DLBCL|LOTIS-5 data readout|3rd June 2026|
|Olezarsen/<br>T<br>ryngolza|sHTG|FDA approved (Ionis)|24th June 2026|
|Altuvoct[F8 replacement]|HemA|P3b FREEDOM interim data at ISTH|12th July 2026|
|x-readPlozasiran [ARWR]|sHTG|P3 SHASTA-3/-4 data to be presented ESC|30th Aug 2026|
|Aspaveli/Empaveli[C3 inhibitor]|CG3/IC-MPGN|JP approval expected|H2 2026|
|Gamifant[IFN�mAb]|IDS|MAS/sHLH FDA approved Jun'25; IDS PoC data positive topline 7th Jan, full<br>data at ISICEM (Mar'26), P3 EMBRACE initiation expected|H2 2026|
|Pozdeutinurad[URAT1]|Progressive and<br>tophaceousgout|Readout from P2 REDUCE1 expected|H2 2026|
|Vonjo[JAK2 inhibitor]|CMML|P2 ongoing study – PCD|June 2027|
|Pozdeutinurad[URAT1]|Progressive and<br>tophaceous gout|Primary endpoint and safety readout from P2  REDUCE2  21st May 2026; BLA<br>submission expected|2027|
|NASP/SEL-212[pegadricase]|Chronic gout|CRL 26th June 2026, resubmission planned|2027|
|Vonjo[JAK2 inhibitor]|VEXAS|PAXIS P3 readout|2027|
|Vonjo[JAK2 inhibitor]|MF|PACIFICA - Confirmatory study data expected (fully enrolled Apr'26)|2027|
|_Source :Company data, Deutsche Bank Research (las_|_t updated post-Q2'26)_|||



###### Figure 282: UCB - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Fintepla_[5-HT agonist]_|CDKL5 DD|EU regulatory submission May 2026; US submission|Mar-26|
|Doxecitinea<br>ndd<br>oxribtimine_[nucleoside therapy]_|TK2 DD|US/EU filing in Feb 2025; US approval Nov'25, EU approval|Mar-26|
|icotrokinra(<br>IL-23) _[x-read JNJ]_|PsO|FDA approval|Mar-26|
|Bimzelx _[IL17-A/F mAb]_|PsA H2H|P3 BE BOLD H2H vs Skyrizi superior readout|1<br>1thM<br>ar2<br>026|
|UCB0022/glovadalen_[dopamine modulator]_|PD|Positive P2a results in Q2'25; assessing next steps|ongoing|
|Cizutamig[BCMA/CD3 TCE]|MG/SARD-ILD|(Candid Therapeutics Acquisition) P2 to initiate|YE 2026|
|Staccato_[GABA inhibitor]_|Seizures|P3 results expected|Q4'26-H1'27|
|Rezanecel[cell therapy]|MTLE|(Neurona Acquisition) P3 to initiate|H1 2027|
|Bepranemab _[anti-tau mAb]_|Alz disease|P2 to initiate|H12<br>027|
|Bimzelx _[IL17-A/F mAb]_|pediatric HS|topline results expected|H1 2027|
|Bimzelx _[IL17-A/F mAb]_|pediatric psoriasis|topline results expected|H2 2027|
|Rystiggo _[FcRN mAb]_|MOG-antibody disease|P3 readout expected (event driven)|H22<br>027|
|Bimzelx _[IL17-A/F mAb]_|palmoplantar pustulosis|P3 BE SEEN trial initiated Nov'25; data expected||
|Bimzelx _[IL17-A/F mAb]_|juvenile idiopathic arthritis|topline results expected|2028|
|Dapirolizumab _[CD40L inhibitor]_|SLE|Initiated P3 PHOENYCS FLY in Dec’24, results expected|2028|
|UCB9741/galvokimig_[IL-13/IL-17A/F mAb]_|AtD|P2a positive topline Q2'25; P2b initiation Dec'25; readout|2028|
|Fintepla_[5-HT agonist]_|Rett syndrome|P3 initiated Q2'26; readout expected|2029|
|Rystiggo _[FcRN mAb]_|ocular MG|P3 initiated Q3'26; readout expected|2029|
|UCB9741/galvokimig_[IL-13/IL-17A/F mAb]_|COPD/NCFB|2x P2 studies initiated Q3'26; topline data expected|2029|
|_Source : Company data, Deutsche Bank Research (last updated post-Q_|_2'26)_|||



Page 70 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 283: Argenx - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|TSP-101[Fn14]|Undisclosed|P1 ongoing; initiated|Q4'2025|
|ARGX-119 _[MuSK agonist]_|ALS|P2a reALiSe data did not support further development|26th Feb 2026|
|batoclimab _(x-read Immunovant)_|TED|P3 topline result for trial 3201/2 trials failed to meet primary endpoint|2nd Apr 2025|
|Vyvgart(<br>efgartigimod) _[FcRN]_|Ocular MG|P3 ADAPT-OCULUS positive readout 26th Feb; full data presented<br>AAN|18-22nd Apr 2026|
|Vyvgart (<br>efgartigimod) _[FcRN]_|MG seronegative|FDA approval|8th May2026|
|Empasiprubart _[C2 inhibitor]_|DGF|P2 VARVARA with 52-week analysis to inform progression decision|mid-2026|
|Vyvgart(<br>efgartigimod) _[FcRN]_|Graves Disease|Reg study initiated|Jun-26|
|FB102[CD122]|Vitaligo|P1b data reported|9th Jul 2026|
|Adimanebart/ARGX-119 _[MuSK agonist]_|CMS|P3r<br>egistrations<br>tudyt<br>os<br>tartf<br>ollowingP<br>1bd<br>ataQ<br>2'25|H22<br>026|
|Vyvgart(<br>efgartigimod) _[FcRN]_|Myositis|P3 study A<br>LKIVIAreadout expected|Q3 2026|
|Brepocitinib(x-read Roivant)|Dermatomyositis|PDUFA Q3 2026; expected launch|Sep-26|
|Empasiprubart _[C2 inhibitor]_|MMN|P3 EMPASSION H2H vs IV-IG readout expected|Q4 2026|
|FB102[CD122]|Celiac disease|P2 data expected|H2 2026|
|Vyvgart(<br>efgartigimod) _[FcRN]_|SSc|POC readout expected|H2 2026|
|ARGX-213 _[FcRn+Albumin targeting Ab]_|FcRn+Albumin|P3 trial to initiate|H2 2026|
|ARGX-121 _[IgA targeting Ab]_|FcRn+IgA targeting Ab|P2 trial to initiate|H2 2026|
|ARGX-118[Galectin-10]|Undisclosed|P1 to initiate|H2 2026|
|ARGX-125[bispecific Ab]|Undisclosed|P1 to initiate|H2 2026|
|ARGX-109 _[IL-6 Ab]_|IL-6|P1 PoC trial to initiate|H2 2026|
|Cemdisiran(x-read ALNY/REGN)|gMG|Assumed PDUFA|22nd Nov 2026|
|ARGX-124 [FcRN]|Undisclosed|complete P1 evaluation|end 2026|
|riliprubart _(x-read SAN)_|CIDP|P3 MOBILIZE (IV-IG refractory) /VITALIZE (on IV-IG) readout|H1 2027|
|Vyvgart(<br>efgartigimod) _[FcRN]_|ITP IV|ITP ADVANCE-NEXT IV readout expected|H1 2027|
|Vyvgart(<br>efgartigimod) _[FcRN]_|Sjogren's|P3 reg study U<br>NITYreadout expected|H2 2027|
|Empasiprubart _[C2 inhibitor]_|CIDP|P3E<br>MVIGORATEH<br>2Hv<br>sI<br>V-IGP<br>3expectedr<br>eadout|H<br>22<br>027|
|Empasiprubart _[C2 inhibitor]_|CIDP|P3 EMNERGIZE readout|H2 2027|
|Vyvgart(<br>efgartigimod) _[FcRN]_|Autoinjector|Autoinjector planned launch|2027|
|Vyvgart(<br>efgartigimod) _[FcRN]_|AMR|POC readout expected|2027|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

###### Figure 284: Recordati - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|Isturisa[11-�-hydroxylase inhibitor]|C<br>ushing'ss<br>yndrome|P4e<br>nrollmentt<br>ob<br>egin|Aug-26|
|Qarziba[IgG1 mAb]|Ewing sarcoma|Clinical trial evaluating safety, dose and early signs of effect<br>initiated in Q2 2025; top-line results expected|Q4 2026|
|Pasireotide[somatostatin analogue]|Post-Bariatric Hypoglycaemia (PBH)|P3 development plan to be finalised|YE 2026|
|mRNA-3927|Propionic acidemia|Top-line results of registrational study|YE 2026|
|Zilganersen[GFAP]|Alexander disease|Regulatory submission EU/JP|Q1'27|
|Sutimlimab|ITP|God<br>ecisionm<br>adet<br>oa<br>dvancet<br>oP<br>3;t<br>rialt<br>oi<br>nitiate|Q<br>1'27|
|Qarziba[IgG1 mAb]|H<br>ighr<br>/rn<br>euroblastoma|A<br>dditionals<br>eto<br>fc<br>linicald<br>atan<br>eeded.I<br>nterimr<br>esultse<br>xpected|H<br>1'28|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Deutsche Bank AG 

Page 71 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

###### Figure 285: Idorsia - upcoming catalysts 

|Product|TherapyArea|Event/Comments|Date|
|---|---|---|---|
|IDOR-1134-2831<br>_[Syntheticglycan vaccine]_|Clostridium difficile|clostridium difficile positive P1 data; partner discussions<br>initiated|Q2 2026|
|Daridorexant<br>_[Dual orexin agonist]_|Pediatric insomnia|P2 in pediatric insomnia readout Q2'26; label-enabling<br>consultation with FDA|ongoing|
|Lucerastat<br>_[glucosylceramide synthase inhibitor]_|Fabry disease|P3 trial to initiate (regulatory filing 2029)|Q3 2026|
|CFTRT<br>ype-IVc<br>orrector|Cystic fibrosis|P1 to initiate|H2 2026|
|IDOR-1117-2520<br>_[CCR6 antagonist]_|Psoriasis|P2 fully enrolled Q1'26; data due|Q4 2026|
|Selatogrel<br>_[P2Y12 antagonist]_|Myocardial Infarction|P3 SOS-AMI ongoing; PCD|Dec-26|
|QUVIVIQ(daridorexant)<br>_[Dual orexin agonist]_|Insomnia|Insomnia DORA class de-scheduling timeline; FDA 8-10wks<br>and DEA 6-9mos; hopefully launch by|By end of 2026|
|Cenerimod<br>_[S1P1 receptor modulator]_|SLE|P3 OPUS ongoing; PCD (Oct'26) readout|H1'27|
|ACT-777991<br>_[CXCR3 antagonist]_|Vitiligo|P2 initiation activities underway; data due|2027|
|ACT-1004-1239<br>_[ACKR3 / CXCR7 antagonist]_|Primary Multiple Sclerosis|PMS P2 initiated Q1'26; data due|Q2 2028|
|_Source : Company data, Deutsche Bank Research (la_|_st updated post-Q2'26)_|||



###### Figure 286: Almirall - upcoming catalysts 

||Indication|Event/Comments|Date|
|---|---|---|---|
|Seysara<br>_[tetracycline]_|Acne|P3 China dossier filed Q3'23; approved|Jan'26|
|Anti-IL-13/OX40LB<br>sAb|Undisclosed|P1 initiated|Q1'26|
|Lebrikizumab<br>_[IL-13 mAb]_|AD pediatric (16 wks)|ADorable-1 (NCT05559359) readout|16th Mar 2026|
|Lebrikizumab<br>_[IL-13 mAb]_|AD (hand and foot)|ADTouch (NCT06921759) PCD|May'26|
|Lebrikizumab<br>_[IL-13 mAb]_|PAR|PREPARED-1 (NCT06339008) PCD|Sep'26|
|Anti-IL2m<br>Ab<br>_[inlicensed from NOVO]_|HS|P1 completed; P2 initiated|Q2'26|
|Klisyri<br>_[Tubulin and Src-k inhibitor]_|Actinic Keratosis|US large field launched in August 2024. EU launch<br>expected|2026|
|ALM27134m<br>Ab<br>_[Anti-IL-1RAP]_|Autoimmune dermatology|P2 planned|Q3'26-Q1'27|
|IL-2muFc|SLE|POC planned|Q3'26-Q1'27|
|ALM27134m<br>Ab<br>_[Anti-IL-1RAP]_|HS|P2 initiated; initial data expected|End 2026|
|Lebrikizumab<br>_[IL-13 mAb]_|AD|ADlongr<br>eadout: additional 5-year long-term safety<br>and efficacy|H1 2027|
|Lebrikizumab<br>_[IL-13 mAb]_|AD (maintenance phase)|ADhope-2(<br>NCT06526182)o<br>ngoing:24-week<br>effectiveness and safety; PCD|Apr'27|
|Lebrikizumab<br>_[IL-13 mAb]_|CRSwNP|CONTRAST-NP (NCT06338995) PCD|May'27|
|Lebrikizumab<br>_[IL-13 mAb]_|AD pediatric (52 wks)|ADorable-2 (NCT05735483) PCD|Dec'27|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 72 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

|Figure 287: Alvotech - upcoming ca<br>Product|talysts<br>Indication|Event/Comments|Date|
|---|---|---|---|
|AVT23 [Omalizumab]|Respiratory|EMA application accepted|6th Oct'25|
|AVT06 [Aflibercept]|Ophthalmology|Positive results; EMA approval 21st<br>Aug'25;  EU launch|Q4'25|
|AVT05 [Golimumab]|Immunology|EU launch|Q4'25|
|AVT03 [Denosumab]|Immunology/Oncology|EU approval Nov'25, launch|Q4'25|
|AVT32 [Pembrolizumab]|Oncology|Due to start P1|Jun-26|
|AVT29 [Aflibercept HD]|Ophthalmology|P3 ongoing; regulatory submission<br>expected|2026|
|AVT05 [Golimumab]|Immunology|Received CRL Nov'25; resubmitted Q2'26;<br>FDA decision expected|Q4 2026|
|AVT03 [Denosumab]|Immunology/Oncology|Received CRL Nov'25; resubmitted Q2'26;<br>FDA decision expected|Q4 2026|
|AVT06 [Aflibercept]|Ophthalmology|Received CRL Nov'25; resubmitted Q2'26;<br>FDA decision expected|Q4 2026|
|AVT16 [Vedolizumab]<br>_Source : Company data, Deutsche Bank Research (last updated p_|Immunology<br>_ost-Q2'26)_|Regulatory submission in EU<br>Regulatory submission in US<br>Est. US BSUFA|Occurred: Q1'26<br>Occurred: Jun'26<br>Est: 6th Apr 2027|



Deutsche Bank AG 

Page 73 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 288: BioNtech - upcoming catalysts 

|Product<br>Oncology|Indication|Event/Comments|Date|
|---|---|---|---|
|BNT327(<br>Pumitamig)[<br>PDL1-VEGF]||||
|BNT327|1L HNSCC|P2/3 ROSETTA HNSCC - originally planned for 2026, development<br>pulled|Q1 2026|
|BNT327|NSCLC|P2/3 ROSETTA Lung-02 initiated; P2 data presented at ASCO 2026;<br>P3 data expected||
|BNT327|ES-SCLC|P3 ROSETTA Lung-01 presented single arm ELCC 2026; full data<br>due||
|BNT327|1LT<br>NBC|P3 ROSETTA Breast-01 data expected||
|BNT327|Unresectable Stg3 lung|P2/3 ROSETTA Lung-201 data due|2030+|
|BNT327|1L PD-L1�50% NSCLC|P2/3 ROSETTA Lung-202 data due|2030+|
|BNT327|1L CRC|P2/3 ROSETTA CRC-203 data due|2030+|
|BNT327|Gastric cancer|P2/3 ROSETTA GI-204 data due|2030+|
|BNT327|HCC|P1/2 ROSETTA HCC-206 data due|2030+|
|BNT327|RCC|P1/2 ROSETTA RCC-208 data due|2030+|
|BNT327+BNT3212|Multiple solid tumors|P1/2 ongoing|ongoing|
|BNT327+BNT314 _(EpCAM x 4-1BB)_|Multiple solid tumors/CRC|P1/2 ongoing|ongoing|
|BNT327+BNT325[<br>Sacituzumabd<br>rozuntecan] _(TROP2)_|TNBC|P2 readout occurred (no details if positive or negative)|4th Aug 2026|
|BNT327+BNT323[<br>Trastuzumabp<br>amirtecan]_(HER2)_|HR+ HER2-low/ultralow/0 BC or TNBC|P1/2 data expected|2026|
|BNT327+BNT326_(HER3)_|Multiple solid tumors  & Advanced<br>NSCLC|P1/2 trials initiated + ongoing; NSCLC readout (pushed from 2026)|2027(+)|
|BNT327+BNT324 _(B7-H3)_|Adv lung cancer/solid tumours|P2 in lung and P1/2 in solid tumours ongoing; readouts expected|H2 2026|
|x-readI<br>vonescimabS<br>MMT|sq 1L NSCLC|P3 HARMONi-3 readout|H2 2026|
|x-readI<br>vonescimabS<br>MMT|EGFRm nsq NSCLC|HARMONi PDUFA (readout Nov'25)|14th Nov 2026|
|x-readI<br>vonescimabS<br>MMT|nsq 1L NSCLC|P3 HARMONi-3 readout|H1 2027|
|B<br>NT122[<br>Autogenec<br>evumeran/iNeST]||||
|BNT122[iNeST] (Genentech collaboration)|Adjuvant CRC|P2 recruitment ongoing; monotherapy final analysis|2027|
|BNT122[iNeST] (Genentech collaboration)|Adjuvant PDAC|P2 recruitment ongoing; readout expected|2029|
|Gotistobart/B<br>NT316[<br>CTLA-4]||||
|BNT316(ONC-392/gotistobart)|PROC|P2 ongoing|ongoing|
|BNT316(ONC-392/gotistobart)|aPD-1/PD-L1 experienced sq NSCLC|P3 (PRESERVE-003) clinical hold Oct'24; continuing just in<br>squamous NSCLC; interim data expected|H2 2026|
|BNT316(ONC-392/gotistobart)<br>|mCRPC + radio, and multiple solid<br>tumors|P2 readout expected (pushed from 2026)|2027(+)|
|FixVac<br>BNT116[<br>Fixvacc<br>omboL<br>ibtayo](<br>REGNc<br>ollaboration)|s.IV NSCLC PD-L1+ 1L ineligible for Cx|Combo LuCa-MERIT-1 data with cemiplimab data presented<br>@WCLC|Sept 2025|
|||<br>P2 (NCT04526899) met primary endpoint in July’24; received FDA||
|BNT113(<br>FixVaco<br>fft<br>hes<br>helfi<br>mmunotherapy)|HNSCC PD-L1/HPV16+|<br>fast track designation in Jan'26 based on preliminary data from P2/3<br>AHEAD-MERIT. PCD Apr 2029. Data expected|H2 2026|
|BNT211[<br>CLDN6C<br>AR-T]||||
|BNT211|CAR-T/CLDN6+ solid tumors|P1 ongoing|ongoing|
|BNT323/<br>T<br>rastuzumabp<br>amirtecan[<br>HER2A<br>DC]||||
|Trastuzumabp<br>amirtecan_(HER2 ADC)_|Endo/breast cancer|BLA submission based on totality of breast and endo data|H2 2026|
|Trastuzumabp<br>amirtecan_(HER2 ADC)_|R+/HER2-low met. breast cancer and 2L<br>HER2+ EC|P3 trials initiated Q3'25. P3 DYNASTY BREAST-02 data expected|Q4 2026|
|Trastuzumabp<br>amirtecan_(HER2 ADC)_|2L+ HER2+ endo|single arm P2 data due at conference (P3 FERN-EC-01 data due<br>2028)|H2 2026|
|Trastuzumabp<br>amirtecan_(HER2 ADC)_|Multiple solid tumors|<br>P2 ongoing|Q4'25|
|Othero<br>ncologya<br>ssets||||
|Sacituzumabd<br>rozuntecan/<br>B<br>NT325(TROP2 ADC)|PROC|P1/2 ongoing; data presented @ ESMO 2025|ESMO 2025|
|BNT326(HER3 ADC)|R/R NSCLC and HR+/HER2- BC|P2  in 2L+ HER2-low/-null BC presented|SABCS 2025|
|<br>BNT324(B7H3 ADC)|1L+ CRPC|<br>Pivotal data expected|2029|
|InfectiousD<br>iseases<br>BNT161(exclusive license to PFE)|Flu(<br>quadrivalent)a<br>ndC<br>OVID-19|Preparing variant strain vaccine adaptation for launch in 2025/26<br>season. Received reg. approval US/EU/UK/JPN in Q3||



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Deutsche Bank AG 

Page 74 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Figure 289: Moderna - upcoming catalysts 

|Product|Indication|Event/Comments|Date|
|---|---|---|---|
|mRNA-1010|Seasonal flu|FDA approval (mFLUSIVA)|5th Aug 2026|
|mRNA-3705|MMA|FDA agreed to pivotal study design, MRNA waiting until 3927 PA readout before making<br>decision on pivotal trial|2026|
|mRNA-1189|EBV|P1 readout_Jun'25;_P2 PCD|Oct-26|
||Adjuvant melanoma|P3 INTerpath-001 positive interim RFS headline|19th Aug|
||Adjuvant NSCLC|P3 ongoing PCD|Jun-30|
||Adjuvant NSCLC non-pCR post<br>neoadjuvant|<br>P3 ongoing; PCD|May-33|
||Adjuvant NSCLC  [Stg 1 +<br>Keytruda Qlex]|P3 initiated|May-26|
|Intismerana<br>utogene<br>(mRNA-4157)|LA cSCC<br>1L metastatic melanoma|P2/3 terminated for business reasons<br>P3 initiated|May-26<br>May-26|
||Adjuvant melanoma|P2 KN-942 ongoing (fully enrolled), interim readout at ASCO|29th May - 2nd Jun '26|
||1L metastatic sq NSCLC|P2 ongoing; PCD|Jul-29|
||Adjuvant RCC|P2 fully enrolled; PCD|Jan-28|
||NMIBC|P2 ongoing ; PCD|Sep-31|
||MIBC (bladder cancer)|P1/2 fully enrolled; PCD|Apr-27|
|mRNA-1083|Flu+COVID|Engaging with FDA on data requirements for resubmitting BLA, will file post 1010. Refilling<br>in Canada Q4'25.|2026|
|mRNA-1403|Norovirus|P3 did not meet statistical criteria for early success, trial remains ongoing to enrol<br>additional cohort|Q2'26|
|mRNA-4194|Lynch Syndrome|P1/2 initiated|Q2'26|
|mRNA-4200|Solid tumors|P2 initiated|Q2'26|
|mRNA-4359|Checkpoint vaccine|P1/2 and P2 studies in 1L melanoma and 1LNSCLC P2 readout expected|2026|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Deutsche Bank AG 

Page 75 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 Pharmaceuticals 

EU Pharmaceuticals 

|Figure 290: Sandoz - upcomin|g catalysts|||
|---|---|---|---|
|Product|Indication|Event/Comments|Date|
|Herwenda<br>[Herceptin biosim]|Breast and gastric cancer|Resubmitted BLA|Dec 18th 2025|
|Ranluspec<br>[ranibizumab biosim]|Opthalmology|EU approval (launch timelines unconfirmed)|23rd Feb 2026|
|Bysumlog<br>(insulin lispro)|Diabetes|EU approval|15th May 2025|
|Dazparda<br>(insulin lispro)|Diabetes|EU approval|15th May 2025|
|Enzeevu<br>[aflibercept biosim]|Ophthalmology|US launch expected (with expanded label)<br>EU launch complete|Q4 2026<br>Q4 2025|
|Ondibta<br>[insulinglargine biosim]|Diabetes|EU launch|early 2027|
|Opdivo<br>[nivolumab biosim]|Oncology|P1 and P3 initiated; US LoE|end 2028|
|Keytruda<br>[pembrolizumab biosim]|Oncology|P1 and P3 initiated; US LoE|Dec-28|
|Tecentriq<br>[atezolizumab biosim]|Oncology|P1 and P3 initiated; US LoE|2030|



_Source : Company data, Deutsche Bank Research (last updated post-Q2'26)_ 

Page 76 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

## Appendix 1 

#### Important Disclosures 

#### *Other information available upon request 

*Prices are current as of the end of the previous trading session unless otherwise indicated and are sourced from local exchanges via Reuters, Bloomberg and other vendors . Other information is sourced from Deutsche Bank, subject companies, and other sources. For disclosures pertaining to recommendations or estimates made on securities other than the primary subject of this research, please see the most recently published company report or visit our global disclosure look-up page on our website at <u>https://research.db.com/Research/Disclosures/EquityResearchDisclosures. Aside from within this report,</u> important risk and conflict disclosures can also be found at <u>https://research.db.com/Research/Disclosures/Disclaimer.</u> Investors are strongly encouraged to review this information before investing. 

#### Analyst Certification 

The views expressed in this report accurately reflect the personal views of the undersigned lead analyst about the subject issuers and the securities of those issuers. In addition, the undersigned lead analyst has not and will not receive any compensation for providing a specific recommendation or view in this report. Emmanuel Papadakis. 

Deutsche Bank AG 

Page 77 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Equity rating dispersion and banking relationships 



<!-- Start of picture text -->
= oom<br>| | I!|<br>fm companies covered @ Cos. w/ Banking Relationship &MIFID investment & Ancilary Services]<br>Europe Universe<br><!-- End of picture text -->

###### Equity Rating and Dispersion Key 

The Equity Rating Dispersion Chart depicts the following: 

The proportion of recommendations that are rated "buy", "sell" and "hold" over the previous 12 months. This is shown for securities issued in the stated region e.g. "Europe Universe". See rating definitions below. This is represented by the "Companies Covered" bars in the chart. The percentage value displayed above the bar is the proportion as a percentage. E.g. 50% above the “buy” / “Companies Covered” bar means that 50% of DB’s equity research covered companies over the past 12 months  have a “buy” rating. 

Next to each of the three respective bars showing the proportion of "buy", "sell" and "hold" recommendations we provide two additional bars to show: 

- The proportion of "buy", "sell" or "hold recommendations where Deutsche Bank and or/Affiliates provided MIFID Investment or Ancillary Services in the past 12 months. This is represented in the "MIFID Investment and Ancillary Services" bar. The percentage value displayed above the bar shows the proportion of Companies Covered with the given rating where DB has also provided MIFID Investment and Ancillary Services in the past 12 months. E.g. 50% above the “Cos. w/ MIFID Investment and Ancillary Services” bar means 50% of the Companies Covered with the rating stated have also received MIFID Investment and Ancillary Services from DB. 

- The proportion of "buy" (or "sell" or "hold) recommendations where Deutsche Bank and or/Affiliates has provided Investment Banking services in the past 12 months for which it has received compensation. The percentage value displayed above the bar shows the proportion of Companies Covered with the stated rating where DB has also provided Investment Banking services in the past 12 months. E.g. 50% above the “Cos. w/ Investment Banking relationship” bar means 50% of the Companies Covered with the rating stated also have an Investment Banking Relationship with DB. 

Buy: Based on a current 12- month view of TSR, we recommend that investors buy the stock. 

Sell: Based on a current 12-month view of TSR, we recommend that investors sell the stock. 

Hold: We take a neutral view on the stock 12-months out and, based on this time horizon, do not recommend either a Buy or Sell. 

TSR = Total Shareholder Return. Percentage change in share price from current price to projected target price plus projected dividend yield 

Newly issued research recommendations and target prices supersede previously published research. 

Page 78 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

#### Additional Information 

The information and opinions in this report were prepared by Deutsche Bank AG or one of its affiliates (collectively 'Deutsche Bank'). Though the information herein is believed to be reliable and has been obtained from public sources believed to be reliable, Deutsche Bank makes no representation as to its accuracy or completeness. Hyperlinks to third-party websites in this report are provided for reader convenience only. Deutsche Bank neither endorses the content nor is responsible for the accuracy or security controls of those websites. 

If you use the services of Deutsche Bank in connection with a purchase or sale of a security that is discussed in this report, or is included or discussed in another communication (oral or written) from a Deutsche Bank analyst,  Deutsche Bank may act as principal for its own account or as agent for another person. 

Deutsche Bank may consider this report in deciding to trade as principal.  It may also engage in transactions, for its own account or with customers, in a manner inconsistent with the views taken in this research report.  Others within Deutsche Bank, including strategists, sales staff and other analysts, may take views that are inconsistent with those taken in this research report. Deutsche Bank issues a variety of research products, including fundamental analysis, equity-linked analysis, quantitative analysis and trade ideas. Recommendations contained in one type of communication may differ from recommendations contained in others, whether as a result of differing time horizons, methodologies, perspectives or otherwise. Deutsche Bank and/or its affiliates may also be holding debt or equity securities of the issuers it writes on. Analysts are paid in part based on the profitability of Deutsche Bank AG and its affiliates, which includes investment banking, trading and principal trading revenues. 

Opinions, estimates and projections constitute the current judgment of the author as of the date of this report. They do not necessarily reflect the opinions of Deutsche Bank and are subject to change without notice. Deutsche Bank provides liquidity for buyers and sellers of securities issued by the companies it covers. Deutsche Bank research analysts sometimes have shorter-term trade ideas that may be inconsistent with Deutsche Bank's existing longer-term ratings. Some trade ideas for equities are listed as Catalyst Calls on the Research Website (https://research.db.com/Research/) , and can be found on the general coverage list and also on the covered company's page. A Catalyst Call represents a high-conviction belief by an analyst that a stock will outperform or underperform the market and/or a specified sector over a time frame of no less than two weeks and no more than three months. In addition to Catalyst Calls, analysts may occasionally discuss with our clients, and with Deutsche Bank salespersons and traders, trading strategies or ideas that reference catalysts or events that may have a nearterm or medium-term impact on the market price of the securities discussed in this report, which impact may be directionally counter to the analysts' current 12-month view of total return or investment return as described herein. Deutsche Bank has no obligation to update, modify or amend this report or to otherwise notify a recipient thereof if an opinion, forecast or estimate changes or becomes inaccurate. Coverage and the frequency of changes in market conditions and in both general and company-specific economic prospects make it difficult to update research at defined intervals.  Updates are at the sole discretion of the coverage analyst or of the Research Department Management, and the majority of reports are published at irregular intervals. This report is provided for informational purposes only and does not take into account the particular investment objectives, financial situations, or needs of individual clients. It is not an offer or a solicitation of an offer to buy or sell any financial instruments or to participate in any particular trading strategy. Target prices are inherently imprecise and a product of the analyst's judgment.  The financial instruments discussed in this report may not be suitable for all investors, and investors must make their own informed investment decisions. Prices and availability of financial instruments are subject to change without notice, and investment transactions can lead to losses as a result of price fluctuations and other factors.  If a financial instrument is denominated in a currency other than an investor's currency, a change in exchange rates may adversely affect the investment.  Past performance is not necessarily indicative of future results. Performance calculations exclude transaction costs, unless otherwise indicated. Unless otherwise indicated, prices are current as of the end of the previous trading session and are sourced from local exchanges via Reuters, Bloomberg and other vendors.  Data is also sourced from Deutsche Bank, subject companies, and other parties. Artificial intelligence tools may be used in the preparation of this material, including but not limited to assist in fact-finding, data analysis, pattern recognition, content drafting and editorial corrections pertaining to research material. 

The Deutsche Bank Research Department is independent of other business divisions of the Bank. Details regarding our organizational arrangements and information barriers we have to prevent and avoid conflicts of interest with respect to our research are available on our website (https://research.db.com/Research/) under Disclaimer. 

Macroeconomic fluctuations often account for most of the risks associated with exposures to instruments that promise to pay fixed or variable interest rates. For an investor who is long fixed-rate instruments (thus receiving these cash flows), increases in interest rates naturally lift the discount factors applied to the expected cash flows and thus cause a loss. The longer the maturity of a certain cash flow and the higher the move in the discount factor, the higher will be the loss. Upside surprises in inflation, fiscal funding needs, and FX depreciation rates are among the most common adverse macroeconomic shocks to receivers. But counterparty exposure, issuer creditworthiness, client segmentation, regulation (including changes in assets holding limits for different types of investors), changes in tax policies, currency convertibility (which may constrain currency conversion, repatriation of profits and/or liquidation of positions), and settlement issues related to local clearing houses are also important risk factors. The sensitivity of fixed-income instruments to macroeconomic shocks may be mitigated by indexing the contracted cash flows to inflation, to FX depreciation, or to specified interest rates - these are common in emerging markets.  The index fixings may - by construction - lag or mis-measure the actual move in the underlying variables they are intended to track. The choice of the proper fixing (or metric) is particularly important in swaps markets, where floating coupon rates (i.e., coupons indexed to a typically short-dated interest rate reference index) are exchanged for fixed coupons. Funding in a currency that differs from the currency in which coupons are denominated carries FX risk. Options on swaps (swaptions) the risks typical to options in addition to the risks related to rates movements. 

Deutsche Bank AG 

Page 79 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

Derivative transactions involve numerous risks including market, counterparty default and illiquidity risk.  The appropriateness of these products for use by investors depends on the investors' own circumstances, including their tax position, their regulatory environment and the nature of their other assets and liabilities; as such, investors should take expert legal and financial advice before entering into any transaction similar to or inspired by the contents of this publication. The risk of loss in futures trading and options, foreign or domestic, can be substantial. As a result of the high degree of leverage obtainable in futures and options trading, losses may be incurred that are greater than the amount of funds initially deposited - up to theoretically unlimited losses. Trading in options involves risk and is not suitable for all investors. Prior to buying or selling an option, investors must review the 'Characteristics and Risks of Standardized Options", at <u>https://www.theocc.com/companyinformation/documents-and-archives/options-disclosure-document. If you are unable to access the website, please contact</u> your Deutsche Bank representative for a copy of this important document. 

Participants in foreign exchange transactions may incur risks arising from several factors, including the following: (i) exchange rates can be volatile and are subject to large fluctuations; (ii) the value of currencies may be affected by numerous market factors, including world and national economic, political and regulatory events, events in equity and debt markets and changes in interest rates; and (iii) currencies may be subject to devaluation or government-imposed exchange controls, which could affect the value of the currency. Investors in securities such as ADRs, whose values are affected by the currency of an underlying security, effectively assume currency risk. 

Unless governing law provides otherwise, all transactions should be executed through the Deutsche Bank entity in the investor's home jurisdiction. Aside from within this report, important conflict disclosures can also be found at <u>https:// research.db.com/Research/</u> on each company's research page or under the ‘Disclosures' tab. Investors are strongly encouraged to review this information before investing. 

Deutsche Bank (which includes Deutsche Bank AG, its branches and affiliated companies) is not acting as a financial adviser, consultant or fiduciary to you or any of your agents (collectively, "You" or "Your") with respect to any information provided in this report. Deutsche Bank does not provide investment, legal, tax or accounting advice, Deutsche Bank is not acting as your impartial adviser, and does not express any opinion or recommendation whatsoever as to any strategies, products or any other information presented in the materials.  Information contained herein is being provided solely on the basis that the recipient will make an independent assessment of the merits of any investment decision, and it does not constitute a recommendation of, or express an opinion on, any product or service or any trading strategy. 

The information presented is general in nature and is not directed to retirement accounts or any specific person or account type, and is therefore provided to You on the express basis that it is not advice, and You may not rely upon it in making Your decision. The information we provide is being directed only to persons we believe to be financially sophisticated, who are capable of evaluating investment risks independently, both in general and with regard to particular transactions and investment strategies, and who understand that Deutsche Bank has financial interests in the offering of its products and services. If this is not the case, or if You are an IRA or other retail investor receiving this directly from us, we ask that you inform us immediately. 

In July 2018, Deutsche Bank revised its rating system for short term ideas whereby the branding has been changed to Catalyst Calls ("CC") from SOLAR ideas; the rating categories for Catalyst Calls originated in the Americas region have been made consistent with the categories used by Analysts globally; and the effective time period for CCs has been reduced from a maximum of 180 days to 90 days. 

**United States** : Approved and/or distributed by Deutsche Bank Securities Incorporated, a member of FINRA and SIPC.  Analysts located outside of the United States are employed by non-US affiliates and are not registered/qualified as research analysts with FINRA. 

**European Economic Area (exc. United Kingdom)** : Approved and/or distributed by Deutsche Bank AG, a joint stock corporation with limited liability incorporated in the Federal Republic of Germany with its principal office in Frankfurt am Main. Deutsche Bank AG is authorized under German Banking Law and is subject to supervision by the European Central Bank and by BaFin, Germany's Federal Financial Supervisory Authority. 

**United Kingdom** : Approved and/or distributed by Deutsche Bank AG acting through its London Branch at 21 Moorfields, London EC2Y 9DB. Deutsche Bank AG in the United Kingdom is authorised by the Prudential Regulation Authority and is subject to limited regulation by the Prudential Regulation Authority and Financial Conduct Authority. Details about the extent of our authorisation and regulation are available on request. 

**Hong Kong SAR** : Distributed by Deutsche Bank AG, Hong Kong Branch except for any research content relating to futures contracts within the meaning of the Hong Kong Securities and Futures Ordinance Cap. 571. Research reports on such futures contracts are not intended for access by persons who are located, incorporated, constituted or resident in Hong Kong. The author(s) of a research report , and the entities for which they act and/or are affiliated with, may not be licensed to carry on regulated activities in Hong Kong and, if not licensed, do not hold themselves out as being able to do so. The provisions set out above in the 'Additional Information' section shall apply to the fullest extent permissible by local laws and regulations, including without limitation the Code of Conduct for Persons Licensed or Registered with the Securities and Futures Commission. This report is intended for distribution only to 'professional investors' as defined in Part 1 of Schedule of the SFO. This document must not be acted or relied on by persons who are not professional investors. Any investment or investment activity to which this document relates is only available to professional investors and will be engaged only with professional investors. 

Page 80 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

**India** : Prepared by Deutsche Equities India Private Limited (DEIPL) having CIN: U65990MH2002PTC137431 and registered office at 14th Floor, The Capital, C-70, G Block, Bandra Kurla Complex, Mumbai (India) 400051. Tel: + 91 22 7180 4444. It is registered by the Securities and Exchange Board of India (SEBI) as a Stock broker bearing registration no.: INZ000252437; Merchant Banker bearing SEBI Registration no.: INM000010833 and Research Analyst bearing SEBI Registration no.: INH000001741. DEIPL's Compliance / Grievance officer is Ms. Rashmi Poddar (Tel: +91 22 7180 4929 email ID: complaints.deipl@db.com). Registration granted by SEBI and certification from NISM in no way guarantee performance of DEIPL or provide any assurance of returns to investors. Investment in securities market are subject  to market risks.  Read all the related documents carefully before investing. DEIPL may have received administrative warnings from the SEBI for breaches of Indian regulations. Deutsche Bank and/or its affiliate(s) may have debt holdings or positions in the subject company.  With regard to information on associates, please refer to the "Shareholdings" section in the Annual Report at: <u>https:// www.db.com/ir/en/annual-reports.htm. For latest India research audit report, refer https://country.db.com/india/deutsche-</u> equities-india/index?language_id=1. 

**Japan** : Approved and/or distributed by Deutsche Securities Inc.(DSI). Registration number - Registered as a financial instruments dealer by the Head of the Kanto Local Finance Bureau (Kinsho) No. 117. Member of associations: JSDA, Type II Financial Instruments Firms Association and The Financial Futures Association of Japan. Commissions and risks involved in stock transactions - for stock transactions, we charge stock commissions and consumption tax by multiplying the transaction amount by the commission rate agreed with each customer. Stock transactions can lead to losses as a result of share price fluctuations and other factors. Transactions in foreign stocks can lead to additional losses stemming from foreign exchange fluctuations. We may also charge commissions and fees for certain categories of investment advice, products and services. Recommended investment strategies, products and services carry the risk of losses to principal and other losses as a result of changes in market and/or economic trends, and/or fluctuations in market value. Before deciding on the purchase of financial products and/or services, customers should carefully read the relevant disclosures, prospectuses and other documentation. 'Moody's', 'Standard  Poor's', and 'Fitch' mentioned in this report are not registered credit rating agencies in Japan unless Japan or 'Nippon' is specifically designated in the name of the entity. Reports on Japanese listed companies not written by analysts of DSI are written by Deutsche Bank Group's analysts with the coverage companies specified by DSI. Some of the foreign securities stated on this report are not disclosed according to the Financial Instruments and Exchange Law of Japan. Target prices set by Deutsche Bank's equity analysts are based on a 12-month forecast period. 

**Korea** : Distributed by Deutsche Securities Korea Co. 

**South Africa:** Deutsche Bank AG Johannesburg is incorporated in the Federal Republic of Germany (Branch Register Number in South Africa: 1998/003298/10). 

**Singapore:** This report is issued by Deutsche Bank AG, Singapore Branch (One Raffles Quay #18-00 South Tower Singapore 048583, 65 6423 8001), which may be contacted in respect of any matters arising from, or in connection with, this report. Where this report is issued or promulgated by Deutsche Bank in Singapore to a person who is not an accredited investor, expert investor or institutional investor  (as defined in the applicable Singapore laws and regulations), they accept legal responsibility to such person for its contents. 

**Taiwan** : Information on securities/investments that trade in Taiwan is for your reference only. Readers should independently evaluate investment risks and are solely responsible for their investment decisions. Deutsche Bank research may not be distributed to the Taiwan public media or quoted or used by the Taiwan public media without written consent. Information on securities/instruments that do not trade in Taiwan is for informational purposes only and is not to be construed as a recommendation to trade in such securities/instruments. 

**Qatar** : Deutsche Bank AG in the Qatar Financial Centre (registered no. 00032) is regulated by the Qatar Financial Centre Regulatory Authority. Deutsche Bank AG - QFC Branch may undertake only the financial services activities that fall within the scope of its existing QFCRA license. Its principal place of business in the QFC: Qatar Financial Centre, Tower, West Bay, Level 5, PO Box 14928, Doha, Qatar. This information has been distributed by Deutsche Bank AG. Related financial products or services are only available only to Business Customers, as defined by the Qatar Financial Centre Regulatory Authority. 

**Russia** : The information, interpretation and opinions submitted herein are not in the context of, and do not constitute, any appraisal or evaluation activity requiring a license in the Russian Federation. 

**Kingdom of Saudi Arabia** : Deutsche Securities Saudi Arabia (DSSA) is a closed joint stock company authorized by the Capital Market Authority of the Kingdom of Saudi Arabia with a license number (No. 37-07073) to conduct the following business activities: Dealing, Arranging, Advising, and Custody activities.  DSSA registered office is Faisaliah Tower, 17th Floor, King Fahad Road - Al Olaya District Riyadh, Kingdom of Saudi Arabia P.O. Box 301806. 

**United Arab Emirates** : Deutsche Bank AG in the Dubai International Financial Centre (registered no. 00045) is regulated by the Dubai Financial Services Authority. Deutsche Bank AG - DIFC Branch may only undertake the financial services activities that fall within the scope of its existing DFSA license. Principal place of business in the DIFC: Dubai International Financial Centre, The Gate Village, Building 5, PO Box 504902, Dubai, U.A.E. This information has been distributed by Deutsche Bank AG. Related financial products or services are available only to Professional Clients, as defined by the Dubai Financial Services Authority. 

**Australia and New Zealand** :  This research is intended only for 'wholesale clients' within the meaning of the Australian Corporations Act and New Zealand Financial Advisors Act, respectively. Please refer to Australia-specific research disclosures 

Deutsche Bank AG 

Page 81 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 7 September 2026 

Pharmaceuticals 

EU Pharmaceuticals 

and related information at <u>https://www.dbresearch.com/PROD/RPS_EN-PROD/PROD0000000000521304.xhtml</u> . Where research refers to any particular financial product recipients of the research should consider any product disclosure statement, prospectus or other applicable disclosure document before making any decision about whether to acquire the product. In preparing this report, the primary analyst or an individual who assisted in the preparation of this report has likely been in contact with the company that is the subject of this research for confirmation/clarification of data, facts, statements, permission to use company-sourced material in the report, and/or site-visit attendance.  Without prior approval from Research Management, analysts may not accept from current or potential Banking clients the costs of travel, accommodations, or other expenses incurred by analysts attending site visits, conferences, social events, and the like. Similarly, without prior approval from Research Management and Anti-Bribery and Corruption ("ABC") team, analysts may not accept perks or other items of value for their personal use from issuers they cover. 

Additional information relative to securities, other financial products or issuers discussed in this report is available upon request. This report may not be reproduced, distributed or published without Deutsche Bank's prior written consent. 

Backtested, hypothetical or simulated performance results have inherent limitations. Unlike an actual performance record based on trading actual client portfolios, simulated results are achieved by means of the retroactive application of a backtested model itself designed with the benefit of hindsight. Taking into account historical events the backtesting of performance also differs from actual account performance because an actual investment strategy may be adjusted any time, for any reason, including a response to material, economic or market factors. The backtested performance includes hypothetical results that do not reflect the reinvestment of dividends and other earnings or the deduction of advisory fees, brokerage or other commissions, and any other expenses that a client would have paid or actually paid. No representation is made that any trading strategy or account will or is likely to achieve profits or losses similar to those shown. Alternative modeling techniques or assumptions might produce significantly different results and prove to be more appropriate. Past hypothetical backtest results are neither an indicator nor guarantee of future returns. Actual results will vary, perhaps materially, from the analysis. 

The method for computing individual E,S,G and composite ESG scores set forth herein is a novel method developed by the Research department within Deutsche Bank AG, computed using a systematic approach without human intervention. Different data providers, market sectors and geographies approach ESG analysis and incorporate the findings in a variety of ways.  As such, the ESG scores referred to herein may differ from equivalent ratings developed and implemented by other ESG data providers in the market and may also differ from equivalent ratings developed and implemented by other divisions within the Deutsche Bank Group.  Such ESG scores also differ from other ratings and rankings that have historically been applied in research reports published by Deutsche Bank AG.  Further, such ESG scores do not represent a formal or official view of Deutsche Bank AG. It should be noted that the decision to incorporate ESG factors into any investment strategy may inhibit the ability to participate in certain investment opportunities that otherwise would be consistent with your investment objective and other principal investment strategies. The returns on a portfolio consisting primarily of sustainable investments may be lower or higher than portfolios where ESG factors, exclusions, or other sustainability issues are not considered, and the investment opportunities available to such portfolios may differ. Companies may not necessarily meet high performance standards on all aspects of ESG or sustainable investing issues; there is also no guarantee that any company will meet expectations in connection with corporate responsibility, sustainability, and/or impact performance. 

Copyright © 2026 Deutsche Bank AG 

Page 82 

Deutsche Bank AG 

This document is being provided for the exclusive use of JUSTIN PALAZZOLO at UNIV OF TEXAS DEPT OF FINANCE. 

##### David Folkerts-Landau Group Chief Economist and Global Head of Research 

|Pam Finelli|Steve Pollard|Jim Reid|Tim Rokossa|
|---|---|---|---|
|COO and Head of Fixed<br>Income Research|Global Head of Company<br>Research and Sales|Global Head of Macro and<br>Thematic Research|Head of European<br>Company Research|
|Matthew Barnard<br>Head of Americas<br>Company Research|Debbie Jones<br>Global Head of<br>Sustainability and Data<br>Innovation, Research|Robin Winkler<br>Head of German Macro<br>Research|Sameer Goel<br>Global Head of EM &<br>APAC Research|
|Francis Yared<br>Global Head of Rates<br>Research|George Saravelos<br>Global Head of FX<br>Research|Peter Hooper<br>Vice-Chair of Research|Nilendra de-Mel<br>Head of APAC & Middle<br>East Product<br>Development|



International Production Locations 

|Deutsche Bank AG|Deutsche Bank AG|Deutsche Bank AG|Deutsche Securities Inc.|
|---|---|---|---|
|Deutsche Bank Place|Equity Research|Filiale Hongkong|1-3-1 Azabudai|
|Level 16|Mainzer Landstrasse 11-17|International Commerce|Azabudai Hills Mori JP Tower|
|Corner of Hunter & Phillip|60329 Frankfurt am Main|Centre,|Minato-ku, Tokyo 106-0041|
|Streets|Germany|1 Austin Road West,Kowloon,|Japan|
|Sydney, NSW 2000<br>Australia<br>Tel: (61) 2 8258 1234|Tel: (49) 69 910 00|Hong Kong<br>Tel: (852) 2203 8888|Tel: (81) 3 6730 1000|
|Deutsche Bank AG|Deutsche Bank Securities Inc.|Deutsche Bank AG||
|21 Moorfields|The Deutsche Bank Center|Filiale Singapur||
|London EC2Y 9DB|1 Columbus Circle|One Raffles Quay, South||
|United Kingdom|New York, NY 10019|Tower,||
|Tel: (44) 20 7545 8000|Tel: (1) 212 250 2500|Singapore 048583<br>TeL: +65 6423 8001||



