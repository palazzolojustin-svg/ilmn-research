Equity Research European Pharmaceuticals, Biotechnology & Life Sciences 28 September 2026 

Roche 

# **Pharma Day First Take: Incremental pipeline updates, strong long-term outlook reiterated** 

Now 20 NMEs to launch by 2030 (up from 18), five new Ph.3 starts, solid enicepatide obesity data, and some new peaksales targets. Positives offset by offset by some modest pipeline delays (gire pionERA/pegozafermin) and emugrobart/TL1A AtD removals. Detailed feedback from the event to follow. 

**This morning, ahead of today’s Pharma Day, ROP provided a c.200 slide deck for the event, with no major new target changes since last year's Pharma Day, as expected, but with a number of incremental updates.** High level, ROP continues to expect the on-market portfolio to deliver Pharma growth to over-compensate for generic erosions, with Pharma set to see "sustained growth beyond 2030", and with Pharma Core Operating margin to be at least stable. 

**ROP did not provide new Pharma-specific divisional targets** . Against current BARC expectations of **c.3% pharma top-line growth from 2026-30, and pharma COP margin (Core Operating Profit) expanding to 56% in 2030, from 50% in 2026,** we remain broadly in line with restated targets. 

ROPC.S/ROP SE OVERWEIGHT European Pharmaceuticals, Biotechnology & Life NEUTRAL Sciences Price Target CHF 430.00 Price (25-Sep-26) CHF 360.30 Potential Upside/Downside +19.3% Source: Bloomberg, Barclays Research 

**European Pharmaceuticals, Biotechnology & Life Sciences** 

### **James Gordon** 

+44 (0)20 7116 2784 james.gordon@barclays.com Barclays, UK 

### **Sidhartha Modi** 

+91 (0)22 6175 1326 sidhartha.modi@barclays.com Barclays, UK 

### **Charles Pitman-King, CFA** 

+44 (0)20 3134 6023 charles.pitman-king@barclays.com Barclays, UK 

**ROP highlighted up to 20 NMEs with launch potential by 2030** , versus up to 18 presented in 2025, with 1) **tambotatug petilecan** , 2) **zemocimig** , 3) **bexobrutide** , 4) **HER2 TKI** and 5) **VEGF x IL-6 DutaFab** all added, whilst 1) CT-868, 2) NXT007 and 3) emugrobart have been removed. Potential launches by YE27 were highlighted as 1) **divarasib** , 2) b, 3) **Enspryng** in MOGAD/TED, 4) **sefaxersen** in IgAN and 5) **afimkibart** in UC. _Detailed summary below._ 

**New obesity data was provided for ROP’s GLP-1/GIP asset enicepatide** , which delivered 22.7% weight loss at 48 weeks, equivalent to **18.3% placebo-adjusted weight loss** , with no apparent plateau; at 24mg, 48%/38%/26% of patients achieved ≥20%/≥25%/≥30% weight loss. This compares with Eli Lilly’s tirzepatide, which delivered **20.9% weight loss and 17.8% placebo-adjusted weight loss at 72 weeks** at 15mg in SURMOUNT-1. We view this as a favourable comparision for enicepatide, particularly noting differences in study length, though 

Barclays Capital Inc. and/or one of its affiliates does and seeks to do business with companies covered in its research reports. As a result, investors should be aware that the firm may have a conflict of interest that could affect the objectivity of this report. Investors should consider this report as only a single factor in making their investment decision. 

This research report has been prepared in whole or in part by equity research analysts based outside the US who are not registered/qualified as research analysts with FINRA. **Please see analyst certifications and important disclosures beginning on page 4.** 

<mark>Completed: 28-Sep-26, 10:19 GMT Released: 28-Sep-26, 10:20 GMT Restricted - External</mark> 

Barclays | Roche 

baseline characteristics may also need to be taken into account. In T2D, enicepatide **reduced HbA1c by 2.65% from an 8.1% baseline, and body weight by 15.5% at 48 weeks** ; Roche did not disclose the corresponding placebo weight-loss result. By comparison, tirzepatide 15mg delivered a **2.3% HbA1c reduction, alongside 14.7% absolute and 11.6% placebo-adjusted weight loss at 72 weeks** in SURMOUNT-2, broadly supporting enicepatide’s competitive efficacy profile but again subject to cross-trial caveats. 

**Roche additionally provided updated peak revenue forecasts for a number of pipeline products,** including first-time guidance for 1) **tambotatug pelitecan** of >SFr3bn), 2) **bexobrutideg** of >SFr3bn, 3) **zemocimig** of >SFr3bn, 4) an **HER2 TKI** of SFr1-2bn, and 5) a **VEGFxIL6 DutaFab bispecific** of SFr1-2bn. See Figure 1 below: 

**FIGURE 1. Comparison of peak sales guidance 2025 vs 2026** 

|**Drug**|**Indication**|**Old Peak sales**<br>**(SFr bn)**|**New Peak sales**<br>**(SFr bn)**|**Cons**<br>**(SFr bn)**|**BARCe**<br>**(SFR bn)**|
|---|---|---|---|---|---|
|giredestrant|HR+ BC|9bn +|Not Updated|4.9|8.4|
|petrelintide|Obesity +/-T2D|3+|3+|2.0|0.2|
|trontinemab|AD|3+|3+|1.8|1.1|
|prasinezumab|PD|3+|3+|0.7|0.4|
|afimkibart|UC/CD|3+|3+|1.9|1.9|
|enicepatide|Obesity|||||
|CT-868|T1D|3+|3+|n.a.|1.3|
|CT-996|Obesity|||||
|zilebesiran|Hypertension|3+|3+|0.8|0.6|
|pegozafermin|MASH|3+|3+|1.4|0.9|
|afimkibart|IBD, AtD, AD, MASH|3+|3+|1.9|1.9|
|**fenebrutinib**|**RMS, PPMS**|**2-3**|**_3+_**|**1.6**|**2.1**|
|**divarasib**|**KRAS+ NSCLC, CRC**|**1-2**|**_2-3_**|**1.4**|**1.4**|
|cevostamab|rr MM|1-2|1-2|n.a.|1.1|
|**sefaxersen**|**IgAN**|**0.5-1**|**_1-2_**|**n.a.**|**0.8**|
|vamikibart|UME|0.5-1|0.5-1|0.6|0.5|
|**tambotatug pelitecan**|**SCLC, NSCLC and others**|**n.a.**|**_3+_**|**n.a.**|**n.a.**|
|**bexobrutideg**|**CLL**|**n.a.**|**_3+_**|**n.a.**|**n.a.**|
|**zemocimig**|**Hemophilia A**|**n.a.**|**_3+_**|**n.a.**|**0.8**|
|**HER2 TKI**|**HER2+ BC**|**n.a.**|**_1-2_**|**n.a.**|**0.8**|
|**VEGF x IL6 DutaFab**|**DME**|**n.a.**|**_1-2_**|**n.a.**|**n.a.**|



Source: ROP investor materials 

**In addition to reiterating its financial framework, Roche increased the number of potential NME launches by 2030 to 20,** reflecting the addition of **tambotatug pelitecan in SCLC/NSCLC** and the **VEGF x IL-6 DutaFab in DME** . Roche also identified **five planned Phase III initiations** : (1.) petrelintide in obesity/T2D in H2'26, (2.) tambotatug pelitecan in 2L+ SCLC in Q4'26, (3.) VEGF x IL-6 DutaFab in DME, (4.) CT-996 in obesity/T2D and (5.) enicepatide in obesity/T2D, ASCVD and HFrEF in H1'27. The latter three have expected H1'27 starts, with first-patient enrolment remains pending across the five programmes. 

28 September 2026 

2 

Barclays | Roche 

ROP announced delays to 1) **giredestrant’s** Ph.3 pionERA readout, now expected in **2028, versus 2027 previously** , 2) **pegozafermin’s** Ph.3 ENLIGHTEN-Fibrosis readout, now expected in **H1'28, versus H1'27** , and 3) **pegozafermin's** ENLIGHTEN-Cirrhosis framed for 2028+. Separately, Roche removed emugrobart in obesity and afimkibart in AtD from Ph.2 following disappointing data. 

We view the release as **positive, albeit not groundbreaking** . The increase to 20 potential NME launches by 2030 and five planned Ph.3 starts reinforce improving pipeline momentum noted as positives, with no change to financial targets reinforcing existing expectations. 

28 September 2026 

3 

Barclays | Roche 

### **Analyst(s) Certification(s):** 

I, James Gordon, hereby certify (1) that the views expressed in this research report accurately reflect my personal views about any or all of the subject securities or issuers referred to in this research report and (2) no part of my compensation was, is or will be directly or indirectly related to the specific recommendations or views expressed in this research report. 

### **Important Disclosures:** 

Barclays Research is produced by the Investment Bank of Barclays Bank PLC and its affiliates (collectively and each individually, "Barclays"). All authors contributing to this research report are Research Analysts unless otherwise indicated. The publication date at the top of the report reflects the local time where the report was produced and may differ from the release date provided in GMT. 

### **Availability of Disclosures:** 

For current important disclosures regarding any companies that are the subject of this research report, please refer to https:// publicresearch.barclays.com or alternatively send a written request to: Barclays Compliance Control Room, 745 Seventh Avenue, 28th Floor, New York, NY 10019. 

The analysts responsible for preparing this research report have received compensation based upon various factors including the firm's total revenues, a portion of which is generated by investment banking activities, the profitability and revenues of the Markets business and the potential interest of the firm's investing clients in research with respect to the asset class covered by the analyst. 

Research analysts employed outside the US by affiliates of Barclays Capital Inc. are not registered/qualified as research analysts with FINRA. Such nonUS research analysts may not be associated persons of Barclays Capital Inc., which is a FINRA member, and therefore may not be subject to FINRA Rule 2241 restrictions on communications with a subject company, public appearances and trading securities held by a research analyst’s account. 

Analysts regularly conduct site visits to view the material operations of covered companies, but Barclays policy prohibits them from accepting payment or reimbursement by any covered company of their travel expenses for such visits. 

Barclays Research Department produces various types of research including, but not limited to, fundamental analysis, equity-linked analysis, quantitative analysis, and trade ideas. Recommendations contained in one type of Barclays Research may differ from those contained in other types of Barclays Research, whether as a result of differing time horizons, methodologies, or otherwise. 

In order to access Barclays Statement regarding Research Dissemination Policies and Procedures, please refer to https:// publicresearch.barclays.com/S/RD.htm. In order to access Barclays Research Conflict Management Policy Statement, please refer to: https:// publicresearch.barclays.com/S/CM.htm. 

### **Primary Stocks (Ticker, Date, Price)** 

**Roche** (ROPC.S, 25-Sep-2026, CHF 360.30), Overweight/Neutral, A/D/J/K/L/M/N 

Unless otherwise indicated, prices are sourced from Bloomberg and reflect the closing price in the relevant trading market, which may not be the last available closing price at the time of publication. 

### **Disclosure Legend:** 

**A:** Barclays Bank PLC and/or an affiliate has been lead manager or co-lead manager of a publicly disclosed offer of securities of the issuer in the previous 12 months. 

**B:** An employee or non-executive director of Barclays PLC is a director of this issuer. 

**CD:** Barclays Bank PLC and/or an affiliate is a market-maker in debt securities issued by this issuer. 

**CE:** Barclays Bank PLC and/or an affiliate is a market-maker in equity securities issued by this issuer. 

**CH:** Barclays Bank PLC and/or its group companies makes, or will make, a market in the securities (as defined under paragraph 16.2 (k) of the HK SFC Code of Conduct) in respect of this issuer. 

**D:** Barclays Bank PLC and/or an affiliate has received compensation for investment banking services from this issuer in the past 12 months. 

**E:** Barclays Bank PLC and/or an affiliate expects to receive or intends to seek compensation for investment banking services from this issuer within the next 3 months. 

**FA:** Barclays Bank PLC and/or an affiliate beneficially owns 1% or more of a class of equity securities of this issuer, as calculated in accordance with US regulations. 

**FB:** Barclays Bank PLC and/or an affiliate beneficially owns a long position of more than 0.5% of a class of equity securities of this issuer, as calculated in accordance with EU regulations. 

**FC:** Barclays Bank PLC and/or an affiliate beneficially owns a short position of more than 0.5% of a class of equity securities of this issuer, as calculated in accordance with EU regulations. 

**FD:** Barclays Bank PLC and/or an affiliate beneficially owns 1% or more of a class of equity securities of this issuer, as calculated in accordance with South Korean regulations. 

**FE:** Barclays Bank PLC and/or its group companies has financial interests in relation to this issuer and such interests aggregate to an amount equal to or more than 1% of this issuer’s market capitalization, as calculated in accordance with HK regulations. 

**GD:** One of the Research Analysts on the fundamental credit coverage team (and/or a member of his or her household) has a long position in the common equity securities of this issuer. 

**GE:** One of the Research Analysts on the fundamental equity coverage team (and/or a member of his or her household) has a long position in the common equity securities of this issuer. 

**H:** This issuer beneficially owns more than 5% of any class of common equity securities of Barclays PLC. 

28 September 2026 

4 

Barclays | Roche 

**I:** Barclays Bank PLC and/or an affiliate is party to an agreement with this issuer for the provision of financial services to Barclays Bank PLC and/or an affiliate. 

**J:** Barclays Bank PLC and/or an affiliate is a liquidity provider and/or trades regularly in the securities of this issuer and/or in any related derivatives. 

**K:** Barclays Bank PLC and/or an affiliate has received non-investment banking related compensation (including compensation for brokerage services, if applicable) from this issuer within the past 12 months. 

**L:** This issuer is, or during the past 12 months has been, an investment banking client of Barclays Bank PLC and/or an affiliate. 

**M:** This issuer is, or during the past 12 months has been, a non-investment banking client (securities related services) of Barclays Bank PLC and/or an affiliate. 

**N:** This issuer is, or during the past 12 months has been, a non-investment banking client (non-securities related services) of Barclays Bank PLC and/or an affiliate. 

**O:** Not in use. 

**P:** Not in use. 

**Q:** Barclays Bank PLC and/or an affiliate is a Corporate Broker to this issuer. 

**R:** Not in use. 

**S:** This issuer is a Corporate Broker to Barclays PLC. 

**T:** Barclays Bank PLC and/or an affiliate is providing investor engagement services to this issuer. 

### **Risk Disclosure(s)** 

Master limited partnerships (MLPs) are pass-through entities structured as publicly listed partnerships. For tax purposes, distributions to MLP unit holders may be treated as a return of principal. Investors should consult their own tax advisors before investing in MLP units. 

### **Disclosure(s) regarding Information Sources** 

Bloomberg® is a trademark and service mark of Bloomberg Finance L.P. and its affiliates (collectively “Bloomberg”) and the Bloomberg Indices are trademarks of Bloomberg. Bloomberg or Bloomberg’s licensors own all proprietary rights in the Bloomberg Indices. Bloomberg does not approve or endorse this material, or guarantee the accuracy or completeness of any information herein, or make any warranty, express or implied, as to the results to be obtained therefrom and, to the maximum extent allowed by law, Bloomberg shall have no liability or responsibility for injury or damages arising in connection therewith. 

### **Guide to the Barclays Fundamental Equity Research Rating System:** 

Our coverage analysts use a relative rating system in which they rate stocks as Overweight, Equal Weight or Underweight (see definitions below) relative to other companies covered by the analyst or a team of analysts that are deemed to be in the same industry (the "industry coverage universe"). In addition to the stock rating, we provide industry views which rate the outlook for the industry coverage universe as Positive, Neutral or Negative (see definitions below). A rating system using terms such as buy, hold and sell is not the equivalent of our rating system. Investors should carefully read the entire research report including the definitions of all ratings and not infer its contents from ratings alone. 

### **Stock Rating** 

**Overweight** - The stock is expected to outperform the unweighted expected total return of the industry coverage universe over a 12-month investment horizon. 

**Equal Weight** - The stock is expected to perform in line with the unweighted expected total return of the industry coverage universe over a 12-month investment horizon. 

**Underweight** - The stock is expected to underperform the unweighted expected total return of the industry coverage universe over a 12-month investment horizon. 

**Rating Suspended** - The rating and target price have been suspended temporarily due to market events that made coverage impracticable or to comply with applicable regulations and/or firm policies in certain circumstances including where the Investment Bank of Barclays Bank PLC is acting in an advisory capacity in a merger or strategic transaction involving the company. 

### **Industry View** 

**Positive** - industry coverage universe fundamentals/valuations are improving. 

**Neutral** - industry coverage universe fundamentals/valuations are steady, neither improving nor deteriorating. 

**Negative** - industry coverage universe fundamentals/valuations are deteriorating. 

Below is the list of companies that constitute the "industry coverage universe": 

**European Pharmaceuticals, Biotechnology & Life Sciences** argenx (ARGX.BR) AstraZeneca (AZN.L) Bachem Holding AG (BANB.S) Bayer AG (BAYGn.DE) bioMérieux (BIOX.PA) Diasorin S.P.A (DIAS.MI) Galderma (GALD.S) Genmab A/S (GMAB.CO) Grifols SA (GRLS.MC) GSK plc (GSK.L) H Lundbeck A/S (HLUNb.CO) Hikma Pharmaceuticals PLC (HIK.L) Ipsen SA (IPN.PA) Lonza Group AG (LONN.S) Merck KGaA (MRCG.DE) Novartis (NOVN.S) Novo Nordisk (NOVOb.CO) Polypeptide Group AG (PPGN.S) Recordati (RECI.MI) Roche (ROPC.S) Sandoz AG (SDZ.S) Sanofi (SASY.PA) Sartorius AG (SATG_p.DE) Sartorius Stedim Biotech (STDM.PA) 

28 September 2026 

5 

Barclays | Roche 

Swedish Orphan Biovitrum (SOBIV.ST) 

UCB SA (UCB.BR) 

### **Distribution of Ratings:** 

Barclays Equity Research has 1790 companies under coverage. 

52% have been assigned an Overweight rating which, for purposes of mandatory regulatory disclosures, is classified as a Buy rating; 47% of companies with this rating are investment banking clients of the Firm; 65% of the issuers with this rating have received financial services from the Firm. 

33% have been assigned an Equal Weight rating which, for purposes of mandatory regulatory disclosures, is classified as a Hold rating; 39% of companies with this rating are investment banking clients of the Firm; 59% of the issuers with this rating have received financial services from the Firm. 14% have been assigned an Underweight rating which, for purposes of mandatory regulatory disclosures, is classified as a Sell rating; 32% of companies with this rating are investment banking clients of the Firm; 57% of the issuers with this rating have received financial services from the Firm. 

### **Guide to the Barclays Research Price Target:** 

Each analyst has a single price target on the stocks that they cover. The price target represents that analyst's expectation of where the stock will trade in the next 12 months. Upside/downside scenarios, where provided, represent potential upside/potential downside to each analyst's price target over the same 12-month period. 

### **Types of investment recommendations produced by Barclays Equity Research:** 

In addition to any ratings assigned under Barclays’ formal rating systems, this publication may contain investment recommendations in the form of trade ideas, thematic screens, scorecards or portfolio recommendations that have been produced by analysts within Equity Research. Any such investment recommendations shall remain open until they are subsequently amended, rebalanced or closed in a future research report. 

Barclays may also re-distribute equity research reports produced by third-party research providers that contain recommendations that differ from and/or conflict with those published by Barclays’ Equity Research Department. 

### **Disclosure of other investment recommendations produced by Barclays Equity Research:** 

Barclays Equity Research may have published other investment recommendations in respect of the same securities/instruments recommended in this research report during the preceding 12 months. To view all investment recommendations published by Barclays Equity Research in the preceding 12 months please refer to https://live.barcap.com/go/research/Recommendations. 

### **Legal entities involved in producing Barclays Research:** 

Barclays Bank PLC (Barclays, UK) 

Barclays Capital Inc. (BCI, US) 

Barclays Bank Ireland PLC, Frankfurt Branch (BBI, Frankfurt) Barclays Bank Ireland PLC, Paris Branch (BBI, Paris) Barclays Bank Ireland PLC, Milan Branch (BBI, Milan) Barclays Securities Japan Limited (BSJL, Japan) Barclays Bank PLC, Hong Kong Branch (Barclays Bank, Hong Kong) Barclays Bank Mexico, S.A. (BBMX, Mexico) Barclays Capital Casa de Bolsa, S.A. de C.V. (BCCB, Mexico) Barclays Securities (India) Private Limited (BSIPL, India) Barclays Bank PLC, Singapore Branch (Barclays Bank, Singapore) Barclays Bank PLC, DIFC Branch (Barclays Bank, DIFC) 

28 September 2026 

6 

Barclays | Roche 

## **Roche (ROP SE / ROPC.S)** 

Stock Rating: **OVERWEIGHT** Industry View: **NEUTRAL** Closing Price: **CHF 360.30** (25-Sep-2026) 

### **Rating and Price Target Chart (as of 25-Sep-2026)** 



<!-- Start of picture text -->
450<br>400<br>350<br>300<br>250<br>200<br>Jan-2024 Jul-2024 Jan-2025 Jul-2025 Jan-2026 Jul-2026<br>Closing Price Target Price Rating Change<br><!-- End of picture text -->

Source: LSEG Data & Analytics, Bloomberg, Barclays Research 

Link to Barclays Live for interactive charting 

|**Publication**|**Closing**|**Rating**|**Adjusted**|**Currency**|
|---|---|---|---|---|
|**Date**|**Price***||**Price Target**||
|07-Sep-2026|356.50||430.00|CHF|
|29-Jan-2026|338.30||410.00|CHF|
|06-Jan-2026|328.20|Overweight|390.00|CHF|
|24-Apr-2025|262.30||275.00|CHF|
|30-Jan-2025|285.20||290.00|CHF|
|25-Jul-2024|273.50||275.00|CHF|
|24-Apr-2024|222.20||230.00|CHF|
|01-Feb-2024|233.50||250.00|CHF|
|27-Oct-2023|237.25||260.00|CHF|



On 28-Sep-2023, prior to any intra-day change that may have been published, the rating for this security was Equal Weight, and the adjusted price target was 270.00 CHF. 

Source: Bloomberg, Barclays Research 

*This is the closing price referenced in the publication, which may not be the last available closing price at the time of publication. Historical stock prices and price targets may have been adjusted for stock splits and dividends. 

**A:** Barclays Bank PLC and/or an affiliate has been lead manager or co-lead manager of a publicly disclosed offer of securities of Roche in the previous 12 months. 

**D:** Barclays Bank PLC and/or an affiliate has received compensation for investment banking services from Roche in the past 12 months. 

**J:** Barclays Bank PLC and/or an affiliate is a liquidity provider and/or trades regularly in the securities by Roche and/or in any related derivatives. **K:** Barclays Bank PLC and/or an affiliate has received non-investment banking related compensation (including compensation for brokerage services, if applicable) from Roche within the past 12 months. 

**L:** Roche is, or during the past 12 months has been, an investment banking client of Barclays Bank PLC and/or an affiliate. 

28 September 2026 

7 

Barclays | Roche 

**M:** Roche is, or during the past 12 months has been, a non-investment banking client (securities related services) of Barclays Bank PLC and/or an affiliate. 

**N:** Roche is, or during the past 12 months has been, a non-investment banking client (non-securities related services) of Barclays Bank PLC and/or an affiliate. 

**Valuation Methodology:** We set our ROG PT at SFr430, based on 18x 2028E Core EPS. Our target multiple is a c.34% premium to the current marketcap weighted large-cap 2028E sector multiple of c.14x, and a c.20% premium to the c.15.0x multiple we expect the sector to trade at in the next 18 months. We argue for a premium basis on ROG's strong 28-32E Core EPS CAGR (5.1% vs. sector median of 4.0%), ROG's more sustainable growth beyond 2031 (given more limited LOE pressure), and the longevity of the growth outlook for ROG's Diagnostics business, which isn't subject to LOEs in the same way a Pharma business is. 

**Risks which May Impede the Achievement of the Barclays Research Valuation and Price Target:** Downside: (1) Disappointing pipeline data for key pipeline assets. (2) Slower-than-expected launches for on-market product, due to competition and/or payer pushback. For instance Vabysmo sales declining further as funding issues continues and it loses market share to HD Eylea or Hemlibra losing share to Mim8 from NOVOB. (3) Faster erosions than we model for key assets as they face loss of exclusivity. 

### **Disclaimer:** 

This publication has been produced by Barclays Research Department in the Investment Bank of Barclays Bank PLC and/or one or more of its affiliates (collectively and each individually, "Barclays"). 

It has been prepared for institutional investors and not for retail investors. It has been distributed by one or more Barclays affiliated legal entities listed below or by an independent and non-affiliated third-party entity (as may be communicated to you by such third-party entity in its communications with you). It is provided for information purposes only, and Barclays makes no express or implied warranties, and expressly disclaims all warranties of merchantability or fitness for a particular purpose or use with respect to any data included in this publication. Barclays may provide research to certain categories of recipients that do not use it for investment purposes, including public and private companies in covered industries, media organisations, regulators, and academic institutions that use such research for their own internal informational, news gathering, regulatory or academic purposes. To the extent that this publication states on the front page that it is intended for institutional investors and is not subject to all of the independence and disclosure standards applicable to debt research reports prepared for retail investors under U.S. FINRA Rule 2242, it is an “institutional debt research report” and distribution to retail investors is strictly prohibited. Media organisations are prohibited from re-publishing any opinion or recommendation concerning a debt issuer or debt security contained in any Barclays institutional debt research report. Any recipients that do not want to continue receiving Barclays institutional debt research reports should contact debtresearch@barclays.com. Unless clients have agreed to receive “institutional debt research reports” as required by US FINRA Rule 2242, they will not receive any such reports that may be co-authored by non-debt research analysts. Eligible clients may get access to such cross asset reports by contacting debtresearch@barclays.com. Barclays will not treat unauthorized recipients of this report as its clients and accepts no liability for use by them of the contents which may not be suitable for their personal use. Prices shown are indicative and Barclays is not offering to buy or sell or soliciting offers to buy or sell any financial instrument. 

Without limiting any of the foregoing and to the extent permitted by law, in no event shall Barclays, nor any affiliate, nor any of their respective officers, directors, partners, or employees have any liability for (a) any special, punitive, indirect, or consequential damages; or (b) any lost profits, lost revenue, loss of anticipated savings or loss of opportunity or other financial loss, even if notified of the possibility of such damages, arising from any use of this publication or its contents. 

Other than disclosures relating to Barclays, the information contained in this publication (including third-party data) has been obtained from sources that Barclays Research believes to be reliable, but Barclays does not represent or warrant that it is accurate or complete. Third-party data, including third-party forecasts and predictions, is provided for information purposes only, has not been adopted or endorsed by Barclays, and does not represent the views or opinions of Barclays. Presentations by Third-Party Speakers: Any views or opinions expressed by third-party speakers during a Barclays-hosted event are solely those of the speaker and do not represent the views or opinions of Barclays. Barclays is not responsible for, and makes no warranties whatsoever as to, the information or opinions contained in any written, electronic, audio or video presentations by any thirdparty speakers, and such presentations have not been adopted or endorsed by Barclays and do not represent the views or opinions of Barclays. Content from third-party presentations is provided for information purposes only and has not been independently verified by Barclays for its accuracy or completeness. 

The views in this publication are solely and exclusively those of the authoring analyst(s) and are subject to change, and Barclays Research has no obligation to update its opinions or the information in this publication. Unless otherwise disclosed herein, the analysts who authored this report have not received any compensation from the subject companies in the past 12 months. If this publication contains recommendations, they are general recommendations that were prepared independently of any other interests, including those of Barclays and/or its affiliates, and/or the subject companies. This publication does not contain personal investment recommendations or investment advice or take into account the individual financial circumstances or investment objectives of the clients who receive it. Barclays is not a fiduciary to any recipient of this publication. The securities and other investments discussed herein may not be suitable for all investors and may not be available for purchase in all jurisdictions. The United States imposed sanctions on certain Chinese companies (https://ofac.treasury.gov/sanctions-programs-and-country-information/chinese-militarycompanies-sanctions), which may restrict U.S. persons from purchasing securities issued by those companies. Investors must independently evaluate the merits and risks of the investments discussed herein, including any sanctions restrictions that may apply, consult any independent advisors they believe necessary, and exercise independent judgment with regard to any investment decision. The value of and income from any investment may fluctuate from day to day as a result of changes in relevant economic markets (including changes in market liquidity). The information herein is not intended to predict actual results, which may differ substantially from those reflected. Past performance is not necessarily indicative of future results. The information provided does not constitute a financial benchmark and should not be used as a submission or contribution of input data for the purposes of determining a financial benchmark. 

This publication is not investment company sales literature as defined by Section 270.24(b) of the US Investment Company Act of 1940, nor is it intended to constitute an offer, promotion or recommendation of, and should not be viewed as marketing (including, without limitation, for the purposes of the UK Alternative Investment Fund Managers Regulations 2013 (SI 2013/1773) or AIFMD (Directive 2011/61)) or pre-marketing (including, without limitation, for the purposes of Directive (EU) 2019/1160) of the securities, products or issuers that are the subject of this report. 

28 September 2026 

8 

Barclays | Roche 

**Third Party Distribution:** Any views expressed in this communication are solely those of Barclays and have not been adopted or endorsed by any third party distributor. 

**United Kingdom:** This document is being distributed (1) only by or with the approval of an authorised person (Barclays Bank PLC) or (2) to, and is directed at (a) persons in the United Kingdom having professional experience in matters relating to investments and who fall within the definition of "investment professionals" in Article 19(5) of the Financial Services and Markets Act 2000 (Financial Promotion) Order 2005 (the "Order"); or (b) high net worth companies, unincorporated associations and partnerships and trustees of high value trusts as described in Article 49(2) of the Order; or (c) other persons to whom it may otherwise lawfully be communicated (all such persons being "Relevant Persons"). Any investment or investment activity to which this communication relates is only available to and will only be engaged in with Relevant Persons. Any other persons who receive this communication should not rely on or act upon it. Barclays Bank PLC is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority and is a member of the London Stock Exchange. 

**European Economic Area (“EEA”):** This material is being distributed to any “Authorised User” located in a Restricted EEA Country by Barclays Bank Ireland PLC. The Restricted EEA Countries are Austria, Bulgaria, Estonia, Finland, Hungary, Iceland, Liechtenstein, Lithuania, Luxembourg, Malta, Portugal, Romania, Slovakia and Slovenia. For any other “Authorised User” located in a country of the European Economic Area, this material is being distributed by Barclays Bank PLC. Barclays Bank Ireland PLC is a bank authorised by the Central Bank of Ireland whose registered office is at 1 Molesworth Street, Dublin 2, Ireland. Barclays Bank PLC is not registered in France with the Autorité des marchés financiers or the Autorité de contrôle prudentiel. Authorised User means each individual associated with the Client who is notified by the Client to Barclays and authorised to use the Research Services. The Restricted EEA Countries will be amended if required. 

**Finland:** Notwithstanding Finland’s status as a Restricted EEA Country, Research Services may also be provided by Barclays Bank PLC where permitted by the terms of its cross-border license. 

**Americas:** The Investment Bank of Barclays Bank PLC undertakes U.S. securities business in the name of its wholly owned subsidiary Barclays Capital Inc., a FINRA and SIPC member. Barclays Capital Inc., a U.S. registered broker/dealer, is distributing this material in the United States and, in connection therewith accepts responsibility for its contents. Any U.S. person wishing to effect a transaction in any security discussed herein should do so only by contacting a representative of Barclays Capital Inc. in the U.S. at 745 Seventh Avenue, New York, New York 10019. 

Non-U.S. persons should contact and execute transactions through a Barclays Bank PLC branch or affiliate in their home jurisdiction unless local regulations permit otherwise. 

This material is distributed in Canada by Barclays Capital Canada Inc., a registered investment dealer, a Dealer Member of Canadian Investment Regulatory Organization (www.ciro.ca), and a Member of the Canadian Investor Protection Fund (CIPF). 

This material is distributed in Mexico by Barclays Bank Mexico, S.A. and/or Barclays Capital Casa de Bolsa, S.A. de C.V. This material is distributed in the Cayman Islands and in the Bahamas by Barclays Capital Inc., which it is not licensed or registered to conduct and does not conduct business in, from or within those jurisdictions and has not filed this material with any regulatory body in those jurisdictions. 

**Japan:** This material is being distributed to institutional investors in Japan by Barclays Securities Japan Limited. Barclays Securities Japan Limited is a joint-stock company incorporated in Japan with registered office of 6-10-1 Roppongi, Minato-ku, Tokyo 106-6131, Japan. It is a subsidiary of Barclays Bank PLC and a registered financial instruments firm regulated by the Financial Services Agency of Japan. Registered Number: Kanto Zaimukyokucho (kinsho) No. 143. 

**Asia Pacific (excluding Japan):** Barclays Bank PLC, Hong Kong Branch is distributing this material in Hong Kong as an authorised institution regulated by the Hong Kong Monetary Authority. Registered Office: 41/F, Cheung Kong Center, 2 Queen's Road Central, Hong Kong. 

All Indian securities-related research and other equity research produced by Barclays’ Investment Bank are distributed in India by Barclays Securities (India) Private Limited (BSIPL). BSIPL is a company incorporated under the Companies Act, 1956 having CIN U67120MH2006PTC161063. BSIPL is registered and regulated by the Securities and Exchange Board of India (SEBI) as a Research Analyst: INH000001519; Portfolio Manager INP000002585; Stock Broker INZ000269539 (member of NSE and BSE); Depository Participant with the National Securities & Depositories Limited (NSDL): DP ID: IN-DPNSDL-478-2020; Investment Adviser: INA000000391. BSIPL is also registered as a Mutual Fund Advisor having AMFI ARN No. 53308. The registered office of BSIPL is at Nirlon Knowledge Park, 9th floor, Block B-6, Off. Western Express Highway, Goregaon (East), Mumbai – 400063, India. Telephone No: +91 22 61754000 Fax number: +91 22 61754099. Any other reports produced by Barclays’ Investment Bank are distributed in India by Barclays Bank PLC, India Branch, an associate of BSIPL in India that is registered with Reserve Bank of India (RBI) as a Banking Company under the provisions of The Banking Regulation Act, 1949 (Regn No BOM43) and registered with SEBI as Merchant Banker (Regn No INM000002129) and also as Banker to the Issue (Regn No INBI00000950). Barclays Investments and Loans (India) Limited, registered with RBI as Non Banking Financial Company (Regn No RBI CoR-07-00258), and Barclays Wealth Trustees (India) Private Limited, registered with Registrar of Companies (CIN U93000MH2008PTC188438), are associates of BSIPL in India that are not authorised to distribute any reports produced by Barclays’ Investment Bank. 

This material is distributed in Singapore by the Singapore Branch of Barclays Bank PLC, a bank licensed in Singapore by the Monetary Authority of Singapore. For matters in connection with this material, recipients in Singapore may contact the Singapore branch of Barclays Bank PLC, whose registered address is 10 Marina Boulevard, #23-01 Marina Bay Financial Centre Tower 2, Singapore 018983. 

This material, where distributed to persons in Australia, is produced or provided by Barclays Bank PLC. 

This communication is directed at persons who are a “Wholesale Client” as defined by the Australian Corporations Act 2001. 

Please note that the Australian Securities and Investments Commission (ASIC) has provided certain exemptions to Barclays Bank PLC (BBPLC) under paragraph 911A(2)(l) of the Corporations Act 2001 from the requirement to hold an Australian financial services licence (AFSL) in respect of financial services provided to Australian Wholesale Clients, on the basis that BBPLC is authorised by the Prudential Regulation Authority of the United Kingdom (PRA) and regulated by the Financial Conduct Authority (FCA) of the United Kingdom and the PRA under United Kingdom laws. The United Kingdom has laws which differ from Australian laws. To the extent that this communication involves the provision of financial services by BBPLC to Australian Wholesale Clients, BBPLC relies on the relevant exemption from the requirement to hold an AFSL. Accordingly, BBPLC does not hold an AFSL. 

This communication may be distributed to you by either: (i) Barclays Bank PLC directly, (ii) Barrenjoey Markets Pty Limited (ACN 636 976 059, “Barrenjoey”), the holder of Australian Financial Services Licence (AFSL) 521800, a non-affiliated third party distributor, where clearly identified to you 

28 September 2026 

9 

Barclays | Roche 

by Barrenjoey. Barrenjoey is not an agent of Barclays Bank PLC or (iii) such other non-affiliated third-party distributor(s) as may be clearly identified to you. Such non-affiliated third-party distributor(s) are not agents of Barclays Bank PLC. 

This material, where distributed in New Zealand, is produced or provided by Barclays Bank PLC. Barclays Bank PLC is not registered, filed with or approved by any New Zealand regulatory authority. This material is not provided under or in accordance with the Financial Markets Conduct Act of 2013 (“FMCA”), and is not a disclosure document or “financial advice” under the FMCA. This material is distributed to you by either: (i) Barclays Bank PLC directly or (ii) Barrenjoey Markets Pty Limited (“Barrenjoey”), a non-affiliated third party distributor, where clearly identified to you by Barrenjoey. Barrenjoey is not an agent of Barclays Bank PLC. This material may only be distributed to “wholesale investors” that meet the “investment business”, “investment activity”, “large”, or “government agency” criteria specified in Schedule 1 of the FMCA. 

**Middle East:** Nothing herein should be considered investment advice as defined in the Israeli Regulation of Investment Advisory, Investment Marketing and Portfolio Management Law, 1995 (“Advisory Law”). This document is being made to eligible clients (as defined under the Advisory Law) only. Barclays Israeli branch previously held an investment marketing license with the Israel Securities Authority but it cancelled such license on 30/11/2014 as it solely provides its services to eligible clients pursuant to available exemptions under the Advisory Law, therefore a license with the Israel Securities Authority is not required. Accordingly, Barclays does not maintain an insurance coverage pursuant to the Advisory Law. 

This material is distributed in the United Arab Emirates (including the Dubai International Financial Centre) and Qatar by Barclays Bank PLC. Barclays Bank PLC in the Dubai International Financial Centre (Registered No. 0060) is regulated by the Dubai Financial Services Authority (DFSA). Principal place of business in the Dubai International Financial Centre: The Gate Village, Building 4, Level 4, PO Box 506504, Dubai, United Arab Emirates. Barclays Bank PLC-DIFC Branch, may only undertake the financial services activities that fall within the scope of its existing DFSA licence. Related financial products or services are only available to Professional Clients, as defined by the Dubai Financial Services Authority. Barclays Bank PLC in the UAE is regulated by the Central Bank of the UAE and is licensed to conduct business activities as a branch of a commercial bank incorporated outside the UAE in Dubai (Licence No.: 13/1844/2008, Registered Office: Building No. 6, Burj Dubai Business Hub, Sheikh Zayed Road, Dubai City) and Abu Dhabi (Licence No.: 13/952/2008, Registered Office: Al Jazira Towers, Hamdan Street, PO Box 2734, Abu Dhabi). This material does not constitute or form part of any offer to issue or sell, or any solicitation of any offer to subscribe for or purchase, any securities or investment products in the UAE (including the Dubai International Financial Centre) and accordingly should not be construed as such. Furthermore, this information is being made available on the basis that the recipient acknowledges and understands that the entities and securities to which it may relate have not been approved, licensed by or registered with the UAE Central Bank, the Dubai Financial Services Authority or any other relevant licensing authority or governmental agency in the UAE. The content of this report has not been approved by or filed with the UAE Central Bank or Dubai Financial Services Authority. Barclays Bank PLC in the Qatar Financial Centre (Registered No. 00018) is authorised by the Qatar Financial Centre Regulatory Authority (QFCRA). Barclays Bank PLC-QFC Branch may only undertake the regulated activities that fall within the scope of its existing QFCRA licence. Principal place of business in Qatar: Qatar Financial Centre, Office 1002, 10th Floor, QFC Tower, Diplomatic Area, West Bay, PO Box 15891, Doha, Qatar. Related financial products or services are only available to Business Customers as defined by the Qatar Financial Centre Regulatory Authority. 

**Russia:** This material is not intended for investors who are not Qualified Investors according to the laws of the Russian Federation as it might contain information about or description of the features of financial instruments not admitted for public offering and/or circulation in the Russian Federation and thus not eligible for non-Qualified Investors. If you are not a Qualified Investor according to the laws of the Russian Federation, please dispose of any copy of this material in your possession. 

**Sustainable Investing Related Research:** There is currently no globally accepted framework or definition (legal, regulatory or otherwise) of, nor market consensus as to what constitutes a ‘sustainable’, ‘ESG’, ‘green’, ‘climate-friendly’ or an equivalent company, investment, strategy or consideration or what precise attributes are required to be eligible to be categorised by such terms. This means there are different ways to evaluate a company or an investment and so different values may be placed on certain sustainability credentials as well as adverse ESG-related impacts of companies and ESG controversies. The evolving nature of sustainable investing considerations, models and methodologies means it can be challenging to definitively and universally classify a company or investment under a sustainable investing label and there may be areas where such companies and investments could improve or where adverse ESG-related impacts or ESG controversies exist. The evolving nature of sustainable finance related regulations and the development of jurisdiction-specific regulatory criteria also means that there is likely to be a degree of divergence as to the interpretation of such terms in the market. We expect industry guidance, market practice, and regulations in this field to continue to evolve. 

Any information, data, image, or other content including from a third party source contained, referred to herein or used for whatsoever purpose by Barclays or a third party (“Information”), in relation to any actual or potential ‘ESG’, ‘sustainable' or equivalent objective, issue, factor or consideration is not intended to be relied upon for ESG or sustainability classification, regulatory regime or industry initiative purposes (“ESG Regimes”), unless otherwise stated. Nothing in these materials, including any images included therein, is intended to convey, suggest or indicate that Barclays considers or represents any product, service, person or body mentioned in these materials as meeting or qualifying for any ESG or sustainability classification, label or similar standards that may exist under ESG Regimes. Barclays has not conducted any assessment of compliance with ESG Regimes. Parties are reminded to make their own assessments for these purposes. 

**IRS Circular 230 Prepared Materials Disclaimer:** Barclays does not provide tax advice and nothing contained herein should be construed to be tax advice. Please be advised that any discussion of U.S. tax matters contained herein (including any attachments) (i) is not intended or written to be used, and cannot be used, by you for the purpose of avoiding U.S. tax-related penalties; and (ii) was written to support the promotion or marketing of the transactions or other matters addressed herein. Accordingly, you should seek advice based on your particular circumstances from an independent tax advisor. 

© Copyright Barclays Bank PLC (2026). All rights reserved. No part of this publication may be reproduced or redistributed in any manner without the prior written permission of Barclays. Barclays Bank PLC is registered in England No. 1026167. Registered office 1 Churchill Place, London, E14 5HP. Additional information regarding this publication will be furnished upon request. 

BRND2026 

28 September 2026 

10 

