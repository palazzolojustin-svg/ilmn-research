10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

### Seeking Alpha” 

Transcripts Healthcare 

# Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript 

Jul 23, 2026, 3 ~~:~~ 31 PM ET | Thermo Fisher Scientific Inc ~~.~~ (TMO) Stock, TMO ~~:~~ CA Stock 

Q SA Transcripts 162 ~~.~~ 44K Followers 

## Q2: 2026 ~~-0~~ 7 ~~-~~ 23 Earnings Summary 

EPS of $6 ~~.~~ 03 beats by $0 ~~.~~ 32 | Revenue of $11 ~~.~~ 99B (1 ~~0.~~ 49% Y/Y) beats by $294 ~~.~~ 43M 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call July 23, 2026 8:30 AM EDT 

Company Participants 

Rafael Tejada ~~-~~ Vice President of Investor Relations Marc Casper ~~-~~ Chairman & CEO James Meyer ~~-~~ Senior VP & CFO 

##### Conference Call Participants 

Michael Ryskin ~~-~~ BofA Securities, Research Division Tycho Peterson ~~-~~ Jefferies LLC, Research Division Jack Meehan ~~-~~ Operon Research, LLC Matthew Larew ~~-~~ William Blair & Company L ~~.~~ L ~~.~~ C. ~~,~~ Research Division Daniel Arias ~~-~~ Stifel, Nicolaus & Company, Incorporated, Research Division Daniel Brennan ~~-~~ TD Cowen, Research Division Patrick Donnelly ~~-~~ Citigroup Inc ~~.~~ Exchange Research Luke Sergott ~~-~~ Barclays Bank PLC, Research Division 

###### Presentation 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

1/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

#### Operator 

Good morning, ladies and gentlemen, and welcome to the Thermo Fisher Scientific 2026 Second Quarter Conference Call ~~.~~ [Operator Instructions] | would like to introduce our moderator for the call, Mr ~~.~~ Rafael Tejada, Vice President, Investor Relations ~~.~~ 

Mr ~~.~~ Tejada, you may begin the call ~~.~~ 

##### Rafael Tejada 

Vice President of Investor Relations 

Good morning, and thank youforjoining us ~~.~~ On the call with me today is Marc Casper, our Chairman and Chief Executive Officer; and Jim Meyer, Senior Vice President and Chief Financial Officer ~~.~~ Please note this call is being webcast live and will be archived on the Investors section of our website, thermofisher.com, under the heading News, Events & Presentations until October 20, 2026 ~~.~~ A copy of the press release of our second quarter earnings is available in the Investors section of our website under the heading Financials ~~.~~ So before we begin, let me briefly cover our safe harbor statement ~~.~~ 

Various remarks that we may make about the company's future expectations, plans and prospects constitute forward ~~-l~~ ooking statements within the meaning of applicable securities laws ~~.~~ Actual results may differ materially from those indicated by these forward ~~-l~~ ooking statements as a result of various risks and uncertainties, including those discussed in the company's most recent reports on Form 10 ~~-~~ K and Form 10 ~~-~~ Q under the heading Risk Factors ~~.~~ These forward ~~-l~~ ooking statements are based on our current expectations and speak only as of the date they are made ~~.~~ 

While we may elect to update forward ~~-l~~ ooking statements at some point in the future, we specifically disclaim any obligation to do so, even in the event of new information, future developments, or otherwise ~~.~~ Also, during this call, we will be referring to certain financial measures not prepared in accordance with generally accepted accounting principles or GAAP ~~.~~ 

Areconciliation of these no ~~n-~~ GAAP financial measures to the most directly comparable GAAP measures is available in the press release of our second quarter earnings and also in the Investors section of our website under the heading Financials ~~.~~ 

So with that, I'll now turn the call over to Marc. 

#### Marc Casper 

Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

2/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha Thank you, Raf ~~.~~ Good morning, everyone, and thanks for joining us today for our second quarter call ~~.~~ As you saw in our press release, we delivered an outstanding quarter ~~.~~ Customer activity across our end markets continued to strengthen ~~.~~ Our proven growth strategy is enhancing our capabilities, further advancing our trusted partner status with customers and continuing to drive share gain ~~.~~ And we're continuing to actively manage the company, leveraging our global scale and strength of our PPI Business System to create value for our stakeholders and build an even brighter future for our company ~~.~~ 

To start, let me recap the second quarter financial results. Our revenue grew 10% to $11 ~~.~~ 99 billion ~~.~~ Adjusted operating income grew 15% to $2 ~~.~~ 73 billion ~~.~~ Adjusted operating margin expanded by 90 basis points to 22.8%, and we grew adjusted EPS by 13% to $6 ~~.~~ 03 per share ~~.~~ Turning to our performance by end market ~~.~~ It was good to see customer activity continue to strengthen across our end markets during the second quarter ~~.~~ Our team's excellent execution enabled us to capitalize on these opportunities and deliver outstanding performance in the quarter. 

Let me provide some additional details ~~.~~ Starting with pharma and biotech ~~.~~ We delivered mid ~~-s~~ ingle ~~-d~~ igit growth during the quarter ~~.~~ Performance was led by our bioproduction and clinical research businesses as well as our research and safety market channel. In academic and government, we grew low single digits in the second quarter, driven by our chromatography and mass spectrometry business. In industrial and applied, we delivered mid ~~-s~~ ingle ~~-d~~ igit growth during the quarter ~~.~~ Performance was led by our electron microscopy and chemical analysis business as well as the research and safety market channel ~~.~~ Finally, in diagnostics and health care, we grew in the mid ~~-s~~ ingle digits in the quarter, driven by our health care market channel and immunodiagnostics business. 

Overall, it was great to see both sequential improvement and strong revenue growth across each of our end markets ~~.~~ Let me now provide some highlights on the execution of our growth strategy this quarter ~~.~~ As a reminder, our growth strategy consists of 3 pillars: high ~~-~~ impact innovation, our trusted partner status with customers, and our unparalleled commercial engine ~~.~~ Starting with the first pillar of our growth strategy, it was another excellent quarter of high ~~-~~ impact innovation. Our innovation enables customers to accelerate scientific discovery and advance their important work ~~.~~ 

http ~~s:~~ //seekingalpha ~~.~~ com/article/4924749- ~~t~~ hermo-f ~~i~~ sher- ~~sc~~ ientific ~~-~~ in ~~c-~~ tmo ~~-~~ q2 ~~-2~~ 026- ~~e~~ arnings- ~~ca~~ ll- ~~t~~ ranscript 

3/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

During the quarter, we launched a number of new technologies across our business that strengthened our industry leadership ~~.~~ At this year's American Society of Mass Spectrometry Conference, we launched next ~~-~~ generation Orbitrap platforms and Al ~~-~~ driven capabilities that enable new scientific discoveries and deeper insights ~~.~~ These will help scientists solve increasingly complex analytical challenges with greater speed and confidence. 

This was highlighted by the launch of our Thermo Scientific Orbitrap Tribrid Apex Mass Spectrometer ~~.~~ It enables scientists to study complex biology across multiomics, structural biology, biopharmaceutical characterization, and small molecule analysis to help accelerate research across a broad range of scientific applications ~~.~~ We also introduced the Thermo Scientific Orbitrap Excedion Mass Spectrometer, which enables scientists to reduce drug development risk and accelerate time to market for our pharma and biotech customers. Another highlight this quarter was the launch of our Thermo Scientific Vanquish Amplify UHPLC system, which helps scientists analyze highly sensitive biological molecules with less sample loss and better reproducibility, enabling greater confidence in method development through quality control ~~.~~ This is an important addition to our liquid chromatography offering ~~.~~ 

These innovations are complemented by our expanding suite of A ~~l-~~ powered software, including new solutions that deliver smarter workflows and accelerate proteomics research. Another example of our high ~~-~~ impact innovation is in Life Science Solutions, where we introduced the Applied Biosystems PowerFlex Thermal Cycler, a next ~~-~~ generation PCR platform that helps molecular biology laboratories improve workflow flexibility, increase productivity, and enhance reproducibility. It was an outstanding quarter of innovation, and we're pleased with the adoption we're seeing from our customers. 

Let me now cover the remaining 2 pillars of our growth strategy, our industry ~~-~~ leading commercial capabilities and trusted partner status that enable our customer success ~~.~~ During the quarter, we continued to strengthen our position in both of these areas ~~.~~ In April, we opened our flagship U ~~.~~ S ~~.~~ Bioprocess Design Center in Massachusetts ~~.~~ This new facility expands our global network of collaborative innovation centers, where we work side ~~-~~ by ~~-~~ side with pharma and biotech customers to accelerate drug development, optimize manufacturing processes, and help bring li ~~fe~~ -changing therapies to patients faster ~~.~~ 

http ~~s:~~ //seekingalpha ~~.~~ com/article/4924749- ~~t~~ hermo-f ~~i~~ sher- ~~sc~~ ientific ~~-~~ in ~~c-~~ tmo ~~-~~ q2 ~~-2~~ 026- ~~e~~ arnings- ~~ca~~ ll- ~~t~~ ranscript 

4/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

To advance population scale research, we announceda strategic collaboration with Precision Health Research, Singapore to support their population health study ~~.~~ By combining our integrated proteomics capabilities, including our Olink technology with our Orbitrap Astral mass spectrometry platform, we're continuing to help advance precision medicine through one of the world's leading biobank initiatives ~~.~~ These examples provide a unique opportunity for us to engage with our customers, helping them solve current challenges, accelerate innovation, and move science forward ~~.~~ 

Wrapping up on the growth strategy, we made great progress during the quarter, continuing to strengthen our leadership position. Turning to capital deployment ~~.~~ We continue to successfully execute our disciplined approach to capital deployment, which is a combination of strategic M&A and returning capital to our shareholders ~~.~~ Let me start with an update on our recently closed acquisitions ~~.~~ First, we're very pleased with the progress we're making since completing the acquisition of Clario in late March. 

Clario's market ~~-l~~ eading digital endpoint data solutions enhance our ability to deliver even deeper clinical insights to our pharma and biotech customers. This outstanding strategic fit further strengthens our position as the trusted partner to our pharma and biotech customers, delivering important benefits that enable their success and help improve the productivity of the drug development process. The business delivered a strong second quarter ~~.~~ The integration is progressing smoothly and the funnel of revenue synergies is building nicely. We also continue to see great performance from our filtration and separation business ~~.~~ The integration continues to progress well. Customer feedback has been very positive, and we're excited about the long ~~-~~ term impact these capabilities will have for our customers and for our company ~~.~~ 

Both of these acquisitions demonstrate how our disciplined M&A strategy is creating value for our customers and shareholders ~~.~~ And finally, you saw our announcement in late April that we entered into an agreement to divest our microbiology business ~~.~~ This transaction, which we expect to close in the third quarter, reflects our active management of the company. We deployed the anticipated net proceeds from this transaction to repurchase $1 billion of our shares in the second quarter. As you know, our capital deployment strategy continues to prioritize strategic M&A complemented by return of capital to our shareholders ~~.~~ We continue to have an active pipeline of M&A opportunities in our highly fragmented industry ~~.~~ 

http ~~s:~~ //seekingalpha ~~.~~ com/article/4924749- ~~t~~ hermo-f ~~i~~ sher- ~~sc~~ ientific ~~-~~ in ~~c-~~ tmo ~~-~~ q2 ~~-2~~ 026- ~~e~~ arnings- ~~ca~~ ll- ~~t~~ ranscript 

5/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Now let me spend a few minutes on our PPI Business System, which engages and inspires our colleagues to find a better way every day ~~.~~ PPI enabled another quarter of outstanding execution, which you can see in our strong profitability and free cash flow ~~.~~ Through PPI, we're continually improving quality, productivity, and customer allegiance while creating capacity to invest in innovation and strengthen our leadership position ~~.~~ We are actively deploying Al across the company to further accelerate PPI's impact ~~.~~ PPI enables outstanding execution today and positions us to create even greater value over the long term. Before | turn to guidance, I'd like to highlight the latest updates to our CSR efforts, and they're now available. | encourage you to visit our website to learn more about our performance and the progress we're making towards our long ~~-~~ term goals. As you'll see on the website, we continue to execute our net zero road map, increasing the use of renewable electricity ~~.~~ 

We also increased the number of zero waste certified sites as well as expanded the reach of our STEM education programs ~~.~~ These programs benefit more than 185,000 students annually and help to inspire the next generation of innovators. Now I'd like to review our updated 2026 guidance at a high level ~~.~~ We are raising our guidance for the full year on the top and bottom line reflecting our strong operational performance in the second quarter and increased outlook for the second half of the year, and we're also incorporating the expected impact of the pending divestiture of our microbiology business. We are raising our revenue guidance to a new range of $47.4 billion to $48.1 billion, representing 6% to 8% reported revenue growth over 2025 ~~.~~ 

Our expectation for full year organic revenue growth has increased to about 4% ~~.~~ Our guidance range remains 3% to 4%, and we now expect to deliver at the upper end of that range. We're also increasing our adjusted earnings per share guidance to be in the range of $24.93 to $25 ~~.~~ 33, which now represents 9% to 11% growth over 2025 and a $0 ~~.~~ 25 increase from our previous guidance at the midpoint ~~.~~ Jim will take you through the details in his remarks ~~.~~ So to summarize our key takeaways, we delivered outstanding performance in Q2 with a clean top and bottom line beat with organic revenue growth of 5% and adjusted EPS growth of 13% ~~.~~ It's great to see customer activity continue to strengthen across our end markets ~~.~~ 

We're raising our full year revenue and adjusted EPS guidance ~~.~~ Our proven growth strategy is resonating more than ever with our customers and driving meaningful share gain. Our recently closed acquisitions are performing very well. And at the halfway point in the year, we're well positioned to deliver a great 2026 and build an even brighter future for our company. 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

6/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

With that, I'll turn the call over to Jim ~~.~~ 

#### James Meyer 

Senior VP & CFO 

Thank you, Marc, and good morning, everyone ~~.~~ I'll take you through an overview of our second quarter results for the total company and then provide color on our 4 business segments and conclude with details on our updated guidance for the year ~~.~~ Before | get into the specifics of our financial performance, I'll provide a high ~~-l~~ evel view of how the second quarter played out versus our expectations at the time of our last earnings call ~~.~~ As you saw in our press release, we delivered an outstanding quarter with 5% organic revenue growth and 13% growth in adjusted earnings per share ~~.~~ 

These results are significantly ahead of the assumptions included in our previous guidance on both the top and bottom line ~~.~~ This reflects excellent execution by our team and stronger customer activity across our end markets. Q2 revenue was approximately $300 million ahead of our previous guidance, including 2% stronger organic revenue growth, a higher contribution from acquisitions and favorability from foreign exchange ~~.~~ Adjusted EPS was $0 ~~.~~ 30 ahead of our previous guidance, driven by the expected pull ~~-~~ through from our revenue beat, strong cost productivity, and excellent performance from our acquisitions, including Clario. 

So a very strong quarter of execution by the team, delivering results well ahead of our guidance and positioning us incredibly well at the halfway point of the year. Let me now provide you with some details on our performance ~~.~~ Starting with earnings per share ~~.~~ In the quarter, adjusted EPS grew by 13% to $6 ~~.~~ 03 ~~.~~ GAAP EPS in the quarter was $4 ~~.~~ 68, up 9% from Q2 last year ~~.~~ On the top line, Q2 reported revenue grew 10% year ~~-~~ over ~~-~~ year. The components of our reported revenue change included 5% organic growth, a 5% contribution from acquisition and a slight tailwind from foreign exchange ~~.~~ 

Turning to our organic revenue performance by geography ~~.~~ In Q2, North America grew low single digits, Europe grew high single digits, and Asia Pacific grew high single digits with China growing low single digits ~~.~~ With respect to our operational performance, we delivered $2.73 billion of adjusted operating income in the quarter, an increase of 15% year ~~-~~ over ~~-~~ year and adjusted operating margin was 22 ~~.~~ 8%, 90 basis points higher than Q2 last year ~~.~~ In the quarter, we continued to deliver strong productivity and generated favorable volume leverage. This enabled us to offset the impact of unfavorable mix and fund strategic investments to further advance our industry leadership ~~.~~ Total company adjusted gross margin in the quarter was 41 ~~.~~ 4% ~~.~~ 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

7124 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha Moving on to the details of the P&L ~~.~~ Adjusted SG&A in the quarter was 15 ~~.~~ 6% of revenue ~~.~~ R&D expense was $360 million in Q2, reflecting our ongoing investments in high ~~-~~ impact innovation ~~.~~ R&D as a percent of our manufacturing revenue was 6 ~~.~~ 9% in the quarter ~~.~~ Looking at our results below the line, Q2 net interest expense was $190 million ~~.~~ The adjusted tax rate in Q2 was 11.6% and average diluted shares were 371 million in Q2, 7 million lower year ~~-o~~ ver ~~-y~~ ear, driven by share repurchases net of option dilution ~~.~~ Turning to free cash flow and the balance sheet. Year ~~-t~~ o ~~-~~ date cash flow from operations was $3 ~~.~~ 3 billion, and free cash flow was $2 ~~.~~ 5 billion after investing $800 million of net capital expenditures. In Q2, we also deployed $1.2 billion of capital to shareholders through $1 billion of share buybacks and approximately $175 million of dividends. 

We ended the quarter with $4 ~~.~~ 1 billion of cash and equivalents and $42 ~~.~~ 5 billion of total debt. Our leverage ratio at the end of the quarter was 3.6x gross debt to adjusted EBITDA and 3 ~~.~~ 3x on a net debt basis ~~.~~ Concluding my comments on our total company performance, adjusted ROIC was 10 ~~.~~ 9% ~~.~~ Now I'll provide some color on the performance of our 4 business segments ~~.~~ In Life Sciences Solutions, Q2 reported revenue increased 13% versus the prior year quarter and organic revenue growth was 3%. Growth in this segment was led by our bioproduction business, which had another quarter of excellent organic growth ~~.~~ Q2 adjusted operating income for Life Sciences Solutions increased 13% and adjusted operating margin was 37.0%, up 20 basis points versus the prior year quarter ~~.~~ 

During Q2, we delivered very strong productivity, which was partially offset by the expected impact from the acquisition of our filtration and separation business and unfavorable mix ~~.~~ In the Analytical Instruments segment, both reported revenue and organic revenue increased 7% versus the prior year quarter ~~.~~ We delivered good growth across all 3 businesses, led by our electron microscopy business ~~.~~ In this segment, Q2 adjusted operating income increased 30% and adjusted operating margin was 23 ~~.~~ 0%, up 420 basis points versus the year ago quarter ~~.~~ In the quarter, we delivered strong productivity, generated good volume leverage, and benefited from the impact of foreign exchange and favorable mix. 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

8/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Turning to Specialty Diagnostics ~~.~~ In Q2, reported revenue grew 6% year ~~-~~ over ~~-~~ year and organic revenue grew 5% ~~.~~ Growth in this segment was led by our health care market channel as well as our immunodiagnostics and transplant diagnostics businesses ~~.~~ Q2 adjusted operating income for Specialty Diagnostics increased 9% and adjusted operating margin was 27.7%, 70 basis points higher than Q2 2025. During the quarter, favorable volume leverage and good productivity were partially offset by unfavorable mix ~~.~~ Finally, in the Laboratory Products and Biopharma Services segment, reported revenue increased 12% and organic revenue growth was 5%. In Q2, growth in this segment was led by our research and safety market channel and our clinical research business ~~.~~ 

Q2 adjusted operating income in this segment increased 13% and adjusted operating margin was 14 ~~.~~ 0%, 20 basis points higher than the prior year quarter ~~.~~ In the quarter, good productivity and strong performance from the recently acquired Clario business were partially offset by unfavorable mix and strategic investments ~~.~~ Turning to guidance ~~.~~ As Marc outlined, we're raising our 2026 full year guidance to reflect the strength of our performance in Q2 and an improved outlook for the second half of the year, while also incorporating the expected impact of the announced divestiture of our microbiology business. We now expect revenue to be in the range of $47.4 billion to $48.1 billion and adjusted EPS to be in the range of $24 ~~.~~ 93 to $25 ~~.3~~ 3, now representing 9% to 11% adjusted EPS growth. Let me walk through key assumptions underlying our updated full year guidance ~~.~~ 

For organic revenue growth, our expectation has increased to about 4% for the year ~~.~~ Our guidance range remains 3% to 4%, and we now expect to deliver at the upper end of that range. The increase in our full year organic revenue growth outlook includes all of the Q2 overperformance plus a modest improvement to the second half ~~.~~ Updating for FX, we now expect a $200 million revenue tailwind from foreign exchange, which is $100 million lower than our previous guidance ~~.~~ Our updated guidance also incorporates the expected impact of the pending divestiture of our microbiology business, which we expect to close in the third quarter ~~.~~ As a reminder, the business had revenue of $645 million in 2025, with roughly 1/4 of that revenue selling through our channel businesses. 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

9/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha We'll retain our channel relationship and continue selling these products after the divestiture ~~.~~ With an expected Q3 close, the divestiture reduces 2026 revenue by approximately $200 million, net of the retained channel business and reduces 2026 adjusted EPS by $0.05 ~~.~~ We continue to expect the transaction to be dilutive to adjusted EPS by approximately $0 ~~.~~ 15 in the first full year following the close ~~.~~ In aggregate for adjusted EPS, we are increasing the midpoint of our full year guidance by $0.25 comprised of the following ~~:~~ $0 ~~.~~ 30 from the strong performance in Q2, $0.05 from an increase to our revenue outlook for the second half of the year, partially offset by the impact of the divestiture of our microbiology business of $0.05 and a second half headwind from recent changes in FX rates of $0 ~~.~~ 05 ~~.~~ 

Embedded in the guide is stronger performance from our acquisitions on both the top and bottom line compared to our previous guidance ~~.~~ Acquisitions are now expected to contribute $1.6 billion of revenue and $0.32 of adjusted EPS for the year. In terms of adjusted operating income margins, our guide has increased to 80 basis points of expansion. We are continuing to actively manage the company and drive excellent operational performance, enabling us to increase our top and bottom line guidance for the year ~~.~~ To help you with your modeling, here are a few additional assumptions within the updated guide. We continue to expect approximately $660 million of net interest expense in 2026 ~~.~~ 

We continue to assume that the adjusted income tax rate will be 11 ~~.~~ 5%. In terms of free cash flow, we continue to expect that to be in the range of $6.9 billion to $7 ~~.~~ 4 billion for the year, including between $1 ~~.~~ 9 billion and $2 ~~.~~ 1 billion of net capital expenditures ~~.~~ In terms of capital deployment, we're assuming $4 billion of share buybacks with $3 billion completed in January and an additional $1 billion completed in the second quarter ~~.~~ The second quarter share repurchase represents the use of expected net proceeds from the pending microbiology divestiture ~~.~~ We elected to use the proceeds for share repurchases and to complete the repurchase ahead of the transaction close based on an assessment of our valuation at that time ~~.~~ And we're assuming that we'll return approximately $700 million of capital to shareholders this year through dividends ~~.~~ 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

10/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

We estimate that full year average diluted share count will be between 370 million and 373 million shares. Now let me provide some color on phasing for the remainder of the year ~~.~~ We grew 3% organically in the first half in total and expect that to step up to 4% for the second half with both quarters being similar in terms of organic revenue growth. And we expect Q3 adjusted EPS to be $0 ~~.~~ 35 to $0 ~~.~~ 40 higher than in Q2. So to conclude, we executed very well to deliver an outstanding second quarter, and we are raising our full year outlook on the top and bottom line ~~.~~ 

With that, I'll turn the call back to Raf ~~.~~ 

##### Rafael Tejada 

Vice President of Investor Relations 

Thank you, Jim. Operator, we're ready for the Q&A portion of the call. 

Questio ~~n-~~ an ~~d-~~ Answer Session 

##### Operator 

[Operator Instructions] Your first question comes from the line of Michael Ryskin with Bank of America ~~.~~ 

##### Michael Ryskin 

BofA Securities, Research Division 

Congrats on a very strong print ~~.~~ Marc, maybe I'll start with a high ~~-l~~ evel one to you. You called out a couple of times in the prepared remarks, customer activity continues to strengthen, end markets continue to strengthen ~~.~~ You called out share gains a few times ~~.~~ It seems like it was a pretty broad ~~-~~ based beat in the quarter across segments, across end markets ~~.~~ But maybe if you could just drill in on 1 or 2 things that are maybe driving that, whether it's pharma and biotech ora little bit more stability in academic markets ~~.~~ Would just love to get a better sense on where you saw some of the big improvement from where we stood 3 months ago, especially as you look into the second half of the year ~~.~~ 

#### Marc Casper 

Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

11/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Yes, Mike, thanks for the question. It's good to have a good quarter behind us and a strong first half ~~.~~ So when | think about our end markets, as the way you described it, customer activity actually picked up across our end markets. And if you recall, what we said during the course of this year is we expected that activity would pick up from the 2025 levels as this year progressed ~~.~~ And we saw that getting to that level in Q2 with a much better set of activity. Very encouraging to see the continued progression in pharma and biotech customer base ~~.~~ 

Definitely good momentum continues in pharma, but also biotech, clearly, we saw spending pick up. We've talked a lot about how activity had been picking up. But now it's good to see that's translating into the revenue as well ~~.~~ And across the various segments, you saw that trend across broadly. But our biggest end market, about 60% of our revenue, really progressing in a nice direction ~~.~~ 

##### Michael Ryskin 

BofA Securities, Research Division 

Okay. And Jim, maybe just drilling in a little bit on the guide ~~.~~ Encouraging to see the full year organic raise and you kind of bumped up the second halfa little bit, but | got a comment towards the end there where you said you expect kind of similar organic growth between 3Q and 4Q. | think we were expecting 4Q to be a little bit higher previously because of the days tailwind ~~.~~ Is this just some conservatism as you're kind of looking out to the rest of the year, keeping something in the back pocket ~~?~~ Or is there anything else that's notable in terms of phasing we should be keeping in mind ~~?~~ 

#### James Meyer 

Senior VP & CFO 

Yes, Mike, thanks for the question. So we look at it, we grew 3% in the first half, and we're stepping it up to 4% in the second half, and that includes a modest improvement to the outlook for the second half. And right now, we've outlined the way we see the quarterly phasing playing out, which has really not meaningfully changed versus our original assumption ~~.~~ 

##### Operator 

The next question comes from the line of Tycho Peterson with Jefferies ~~.~~ 

#### Tycho Peterson 

Jefferies LLC, Research Division 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

12/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Nice quarter. Maybe just starting on the services side ~~.~~ Curious, any incremental color you can provide on PPD ~~.~~ We've obviously seen pretty strong book- ~~t~~ o- ~~b~~ ills from some of the peers ~~.~~ And it sounds like maybe some of the biotech funding starting to really convert there ~~.~~ So any metrics on PPD, anything on Clario that you can give usa little more specifically ~~?~~ And then similarly with Patheon, just curious what you saw in the quarter ~~.~~ 

#### Marc Casper 

#### Chairman & CEO 

Tycho, thanks for the question. So clinical research really had an excellent quarter ~~.~~ Strong organic growth in revenue, strong organic growth in authorizations. Business is doing very well in the market, and the market conditions are improving. So you have really both good results in the quarter and encouraging progression going forward, which is largely as we expected it would be playing out. So it's good to see that translating ~~.~~ Clario had a very good quarter ~~.~~ Obviously, it doesn't show up in our organic results, but our first full quarter of ownership of the business was very strong. It had good performance on its authorizations, its revenue growth, earnings ~~.~~ So really a nice contribution. 

And it was good to see both that and with our combination with our filtration and separation business we were able to raise our contribution from acquisitions for the full year on both the revenue and earnings line. So that's very positive. When| think about a couple of other highlights within our broader services business, accelerated drug development, incredibly well received ~~.~~ And that really shows up in our biotech customers where you have ~~--~~ where a customer can get their arms around the whole program from how they outsource their development of the actual medicine through the scale ~~-~~ up of that medicine as well as designing the clinical trials and the interplay between those activities allows you to save time and cost. And that's been very compelling and has really helped us drive very strong authorizations ~~.~~ When| think about the performance of our pharma services or what you would call the Patheon business, we had modest growth in the quarter, in line with our expectations ~~.~~ 

The second half, as we've talked about all year, will be stronger for that business just based on when we're actually shipping the activity ~~.~~ And that business obviously has benefited earlier in the year from a number of wins around reshoring that has been embedded in the outlook for the business ~~.~~ So | feel very good about the position for Pharma Services in terms of how we execute commercially and what the outlook looks like for the coming quarters and years ahead ~~.~~ 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

13/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

#### Tycho Peterson 

Jefferies LLC, Research Division 

Great ~~.~~ And then just a follo ~~w-~~ up on the revised outlook for the back half of the year ~~.~~ | guess, where else are you feeling better across the portfolio? What's kind of leading to the incremental uptake? 

#### Marc Casper 

#### Chairman & CEO 

Yes ~~.~~ So when | think about the quarter, right, we took all of the beat in Q2, embedded that in our outlook. And then we increased our organic revenue growth modestly, but did increase it ~~.~~ It's really driven by ~~--~~ that the forward look is really driven by pharma and biotech. It was nice to see in the quarter that academic and government returned to growth ~~.~~ And we saw the U ~~.~~ S ~~.~~ slightly positive, and those things are very, very good ~~.~~ But we still think the market is going through a stabilization period ~~.~~ So we didn't change the outlook for academic and government ~~.~~ We really focused it on pharma and biotech ~~.~~ And then obviously, we'll see if we see the very positive trends in academic and government sustain, and that would obviously be an upside over time ~~.~~ 

##### Operator 

The next question comes from the line of Jack Meehan with Operon Research. 

##### Jack Meehan 

#### Operon Research, LLC 

| wanted to get a little bit more color on your thoughts on pharma, biotech spending patterns. | got a lot of questions this week about inventory levels, trade, tariff reshoring dynamics ~~.~~ As you look at your customer class and product portfolio, how are those things progressing? Anything that stands out? 

#### Marc Casper 

Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

14/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Yes, Jack, thanks for the question ~~.~~ Clean quarter, right ~~?~~ When | think about business progressed nicely ~~.~~ And as we look to the second half for pharma and biotech, we actually think it will be a little better even though we sawa nice step ~~-~~ up in the quarter ~~.~~ For us, we had broad ~~-~~ based momentum and bioproduction had a really excellent quarter ~~.~~ It's nice to see the continued momentum in that business, very strong growth. Obviously, we talked about clinical research with Tycho's question. And in addition, research and safety market channel had a very strong performance. 

So there really was not a lot of ~~--~~ as you parse through all of the details, it was just a clean, good quarter and actually quite encouraging to see biotech picking up as well ~~.~~ Again, we're not surprised by it ~~.~~ And | think how Jim articulated in our Investor Day, the progression for the stepping up of growth in our business. The big drivers are recovery in biotech and recovery in academic and government ~~.~~ You saw the real signs of the biotech recovery in the results. You saw a good quarter in academic and government. We're not calling yet that that's the new level yet, but it's progressing in a nice direction ~~.~~ 

##### Jack Meehan 

#### Operon Research, LLC 

Great ~~.~~ Can you dig a little bit more into the channel for me ~~?~~ On the research and safety side, it seems like it stepped up. How much of that do you think is just market versus share? And on the health care market side, it seems like that rebounded versus what you put up in the first quarter. Just anything you would call there, was it timing or something else ~~?~~ 

#### Marc Casper 

#### Chairman & CEO 

Yes ~~.~~ So if | think about ~~--~~ let's do health care first ~~.~~ The first half of the year was representative for the health care market channel ~~.~~ The first quarter had very specific headwinds. The second quarter was incredibly strong. | actually think the average of the 2 is the right way to think about health care market channel ~~.~~ They're doing a good job ~~.~~ The business is well positioned ~~.~~ So | feel good about the performance there ~~.~~ So that one is really just take the average of the 2 quarters when we report our results in the Q ~~.~~ When| think about research and safety market channel, you see really 2 dynamics ~~.~~ 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

15/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Really very strong competitive position serving pharma and biotech ~~.~~ And as demand picks up there, that's good ~~.~~ Wins also with account wins also drives some of that performance ~~.~~ So| think it's ~~--~~ the wins are really the share gain part, the market improvement shows up broadly. So that business is doing quite well and a better quarter in academic and government helps that business, but not really the big driver, if you will, of the step ~~-~~ up ~~.~~ 

#### Operator 

Your next question comes from the line of Matt Larew with William Blair. 

Matthew Larew 

William Blair & Company L.L.C., Research Division 

The biggest delta versus our model was on analytical instruments and acknowledging that the comparable was easy, that certainly stood out ~~.~~ You've had a number of product launches across the category in the last 12 months. You also have referenced interest on sort of the autonomous lab, lab in the loop side ~~.~~ But then perhaps as biotech activity or just pharma activity has picked up, maybe that's an area that dollars have been allocated to ~~.~~ Just curious if you think through the various moving pieces, how do all those kind of play into the performance in the quarter ~~?~~ 

#### Marc Casper 

Chairman & CEO 

Matt, thanks for the question ~~.~~ So in terms of analytical instruments, really a very nice quarter, high single ~~-d~~ igit growth ~~.~~ All 3 businesses delivered strong growth in the quarter ~~.~~ So it was really nice to see that. When | think about the drivers, innovation is the most important driver ~~.~~ We launched a suite of products, we had a great American Society of Mass Spectrometry Conference in June with 2 mass spectrometers, a number of Al ~~-~~ enabled software offerings that really help customers have greater insights into their research ~~.~~ We saw strong adoption of our hig ~~h-~~ end instrumentation broadly and especially actually globally in the academic customer set ~~.~~ 

http ~~s:~~ //seekingalpha ~~.~~ com/article/4924749- ~~t~~ hermo-f ~~i~~ sher- ~~sc~~ ientific ~~-~~ in ~~c-~~ tmo ~~-~~ q2 ~~-2~~ 026- ~~e~~ arnings- ~~ca~~ ll- ~~t~~ ranscript 

16/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

So you've heard me say in the past that irrespective of funding environments, if you have really relevant innovation, customers get money ~~.~~ And we saw that show up very nicely ~~.~~ We also had a very important launch in our UHPLC product offering, which bodes well for the future ~~.~~ And those are really the biggest drivers ~~.~~ And then within electron microscopy, another really good quarter ~~.~~ Semiconductor, we play a key enabling role there and as well as advanced materials, and we sawa very strong growth in our business and very strong bookings growth as well. So a very nice performance for Analytical Instruments in Q2 ~~.~~ 

###### Matthew Larew 

William Blair & Company L.L.C., Research Division 

Okay. Great. And then China was up low single digits, and it has obviously been down for some time ~~.~~ But Marc, you've been in China in March, and | know you left more positive. | just would be curious if you could dig a little bit into what you've seen there and how much you think maybe you're kind of at a turning or inflection point for that geography ~~.~~ 

#### Marc Casper 

Chairman & CEO 

Yes. So when| think about China, as a reminder, it's about 7.5% of our revenue. We grew in the low single digits, great to return to growth in the business, really driven by a blend of pharma and biotech and industrial and applied markets ~~.~~ So those were both very strong. Academic and government within China remains quite muted, not different than what we've seen, but not improving either ~~.~~ And so what we're doing is capitalizing on where the money is, and it's nice to see the team deliver growth, and that obviously helped contribute to our overall growth in the overall performance of the company ~~.~~ 

I'll be spending more time again in China in the second half of the year ~~.~~ I'm looking forward to that and spendinga lot of time with customers and government relations topics as well and continue to stay close to what's going on there ~~.~~ But the team is doing a good job, and | feel good about that progressinga little bit better, but still not ~~--~~ it's not accretive to our organic growth as a company yet, but we're taking the steps to put ourselves in a good position ~~.~~ 

#### Operator 

The next question comes from the line of Dan Arias with Stifel ~~.~~ 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

17/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

Daniel Arias 

Stifel, Nicolaus & Company, Incorporated, Research Division 

Marc, you called out chemical analysis is doing well ~~.~~ That's been one of the areas that people just had some concern broadly across the space. Can you maybe just touch on that ~~?~~ What's doing well ~~?~~ And then how do you feel about the macro sensitive parts of the business at this point? Obviously, still choppy out there globally. 

#### Marc Casper 

Chairman & CEO 

Yes. So Dan, thanks for the question ~~.~~ | haven't done a chemical analysis question in a long time, so it makes me happy ~~.~~ It's nice to have a good quarter in the business ~~.~~ It's not a huge business, but we have some really key technologies. The 2 drivers of the growth were, | would say, the higher commodity prices ~~.~~ You saw that in the demand for industrial customers that are commodity sensitive. So that was good. 

And we also saw an increase in demand for safety and security applications as well, given the amount of conflict going on in the world, not surprised that that's picked up. For us, it's largely radiation and explosive detection, and we saw good demand there ~~.~~ So market conditions are getting better, and the team is doing a good job ~~.~~ 

Daniel Arias 

Stifel, Nicolaus & Company, Incorporated, Research Division 

Okay. And then maybe back on pharma services and Patheon specifically ~~.~~ Is it right to say that the stronger back half also includes some sequential strengthening each quarter just based on the booking timing? | mean it sounded like 4Q could end up being the strongest quarter of the year just given the way that revenues are expected to fall ~~.~~ | just want to make sure that that's the right assumption ~~.~~ 

#### James Meyer 

Senior VP & CFO 

Yes, Dan, | wouldn't reach that assumption ~~.~~ We've been saying all along, the second half steps up versus the first half ~~.~~ First half was low single ~~-d~~ igit growth and then it steps up meaningfully in the second half ~~.~~ It's all aligned to production schedules and with customer campaigns, but it doesn't necessarily imply that the fourth quarter grows over the third quarter. 

#### Operator 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

18/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

The next question comes from the line of Dan Brennan with TD Cowen ~~.~~ 

###### Daniel Brennan 

TD Cowen, Research Division 

Congrats on the quarter ~~.~~ Maybe just on the bioproduction business, you've had a few really good organic growth quarters there from the Qs, which we could see. You're growing above market, it appears ~~.~~ So just any color about where that above ~~-~~ market growth is coming from ~~?~~ And obviously, your largest peer saw some customer delays ~~.~~ I'm wondering, did you see any delays at all this quarter or anything expected in the back half ~~?~~ 

#### Marc Casper 

Chairman & CEO 

Dan, thanks for the question ~~.~~ The business had a really strong quarter ~~.~~ It's performing well. It's a very well ~~-~~ positioned business, right ~~?~~ And we havea differentiated set of capabilities that span the upstream and downstream workflow ~~.~~ And as a reminder, we're a leader in cell culture media and singl ~~e-~~ use technologies ~~.~~ We have a growing position in purification and obviously, through the acquisition of Solventum's filtration and separation business, we have a nice position in filtration as well ~~.~~ So when | think about the quarter, we had good strength in our business and the team did a good job broadly across ~~.~~ 

While it doesn't show up in our organic growth in the quarter, filtration and separation business is doing very well. And demand has been strong, and we're actually increasing capacity, which will bode well for the future of that business ~~.~~ So broad ~~-~~ based, very good, and we're looking forward to our competitive position and doing a great job for our customers in serving that market ~~.~~ 

###### Daniel Brennan 

TD Cowen, Research Division 

Great. Maybe I'll just stick on pharma, just kind of large pharma ~~.~~ Could you just zoom out a little bit, Marc ~~?~~ | mean there's been so much noise in the past few years with IRA, MEN, reshoring, now Al, can you just kind of speak maybe just broadly across your business, kind of what you saw in the quarter maybe versus first half? Like, are things changing there ~~?~~ Is the tone getting better ~~?~~ Like, did your updated guide leave room for upside potentially depending upon what the trends are there? 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

19/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

#### Marc Casper 

#### Chairman & CEO 

It's a good multipart question, Dan ~~.~~ So what | would say is when | think about large pharma, | interact with these executives regularly. And | think ~~--~~ | was having breakfast yesterday with one of our key customers ~~.~~ And just ~~--~~ there's a lot of excitement about their pipelines, right? And the discussion is about what's the strategy to help them accelerate their innovation? How do they do it productively ~~?~~ Why are we investing where we're investing? How do they can deploy our capabilities to help them? Our trusted partner status, | mean, it sounds cool, but the reality is that's how we work with these customers every single day to help them be successful. And this is quite a positive tone. 

For those customers that have larger exclusivity cliffs that come up, they're really working their pipeline, and we're helping them with that ~~.~~ So it's really quite an encouraging time ~~.~~ They have their arms around the macro, right, in terms of things like the IRA and MFNs and tariffs and these different factors ~~.~~ And we've said for a while that our customers felt like they were going to navigate that successfully ~~.~~ And | think they feel very good about what the outlook is ~~.~~ And so it's an exciting time in serving that customer base. 

#### Operator 

The next question comes from the line of Patrick Donnelly with Citi ~~.~~ 

##### Patrick Donnelly 

Citigroup Inc. Exchange Research 

Marc, maybe one for you ~~.~~ You touched a little bit on the academic, government market, but | wanted to drill in a bit ~~.~~ How would you characterize where we are in that cycle ~~?~~ It sounds like things have improved at least a little bit. What are you seeing and how those customer conversations are evolving? Is it certain areas of instrumentation more than others? Would love to dive into that aca/gov piece a bit more ~~.~~ 

#### Marc Casper 

Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

20/24 

10/10/26, 9:38 PM 

9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha Sure. So let me start at a high level, and then I'll click downa little bit, right ~~?~~ So Patrick, when| think about it, we had low single ~~-d~~ igit growth in the quarter ~~.~~ So it was nice to have a positive quarter, really driven most significantly by chromatography and mass spectrometry and the launches of products over the last year, we saw strong adoption globally for those products ~~.~~ It's a very important set of research tools ~~.~~ And as you know, if you're an academic researcher, if you don't have the best tools, then effectively, it's very hard to have the cuttin ~~g-~~ edge publications and breakthrough research because another scientist elsewhere has a better tool ~~.~~ 

So you've seen money deployed in that area. From a geographic perspective, we actually had a very strong quarter in Europe ~~.~~ U ~~.~~ S ~~.~~ returned to growth. China, as | mentioned on the China commentary, was more muted environment, not relative to the past, but kind of at the same level ~~.~~ And when| think about the second half, we're not calling a new trend based on Q2, we're very encouraged by it, but we'd like to see the activity continue to be more broad ~~-~~ based before we say that, that one is behind us ~~.~~ There's good support in the government. | spent enough time with Congress to know that in the U ~~.~~ S ~~.~~ around supporting academic research, there's very good support for that. So | feel good about the market stabilizing ~~.~~ And | think our customers are getting their arms around ~~--~~ it's less about the headlines than it is actually about funding flow and the funding flow is improving ~~.~~ So | feel good about the slow stabilization of that end market. 

##### Patrick Donnelly 

#### Citigroup Inc. Exchange Research 

Okay. That's helpful. And then maybe just a follo ~~w-~~ up on PPD ~~.~~ It sounds like things are trending pretty well there. Can you just talk about, | guess, the visibility given the recent bookings, how you're thinking about the second half improvement there ~~?~~ And are you starting to see that earl ~~y-~~ stage biotech pick up? Obviously, the funding has been healthier for a good stretch here ~~.~~ It would seem to be lagging in terms of when it shows up for the group overall ~~.~~ Are you starting to see any signals that, that piece could pick up and just the PPD visibility overall ~~?~~ 

#### Marc Casper 

#### Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

21/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

So harder for me to comment on the group overall ~~.~~ We've seen biotech activity pick up for a few quarters now, actually in our authorization ~~.~~ So that's actually been strong for us ~~.~~ And there's ~~--~~ for simplicity, a 6 ~~-~~ month lag or so from authorizations to revenue, and it varies a little bit ~~.~~ But ~~--~~ so that's picked up. Authorizations have been strong for a while now in the business ~~.~~ 

And actually, the business is performing as we expected, and that's a good thing ~~.~~ We expected to have a really good year in clinical research, and that's actually playing out that way. So that's very encouraging ~~.~~ And there'll be a lot of excitement around the Clario capabilities from our endpoint data business, and that's gone well in the first full quarter of ownership ~~.~~ And there's a lot of customer interest in that because whether you're using our CRO or anybody else's CRO, it's really a great set of capabilities that can enable great clinical research ~~.~~ So a good time for that business ~~.~~ 

##### Rafael Tejada 

Vice President of Investor Relations 

Operator, we'll take one more question. 

##### Operator 

The last question comes from the line of Luke Sergott with Barclays ~~.~~ 

Luke Sergott 

Barclays Bank PLC, Research Division 

| just want to kind of touch back on the bioprocessing piece ~~.~~ So | mean, like the ~~--~~ especially given what we've seen from your larger peers right now on the downstream side and issues with resins and pushouts ~~.~~ | know you guys are ~~--~~ have a bunch of launches coming up ~~.~~ You're underappreciated there on the downstream side. Can you just talk about what the competitive dynamic looks like ~~?~~ Any early wins or increased interest on some of the newer portfolio you have on that side ~~?~~ 

#### Marc Casper 

Chairman & CEO 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749- ~~th~~ ermo-f ~~is~~ her- ~~sc~~ ientific ~~-i~~ nc ~~-~~ tmo ~~-q~~ 2 ~~-2~~ 026- ~~ea~~ rnings-c ~~al~~ l- ~~tr~~ anscript 

22/24 

10/10/26, 9:38 PM Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha Yes ~~.~~ There are a number of fine players in the bioproduction space ~~.~~ The bioproduction space is a great space, right ~~?~~ It's a key enabling technology, especially moving more towards singl ~~e-~~ use for the pharmaceutical and biotech industry, and we play a key role ~~.~~ We've launched a number of innovative technologies, whether it's our DynaDrive singl ~~e-~~ use bioreactors, which is getting more and more standardized across the CDMO landscape. That's a super important indicator because it basically says that it drives efficient production of medicines, but it's also being adopted in the innovative pharmaceutical companies ~~.~~ But CDMOs that they make all their money, including our own, on how well you run your operations, DynaDrive is quickly becoming the favorite technology, and that bodes well for the follo ~~w-~~ on consumable stream that comes from that as well. 

So that's gone well ~~.~~ And our resin business is doing well, right? It's a smaller business ~~.~~ It's won a lot of new molecules over time, and we're doing well there ~~.~~ That's another area where technology has driven differentiation ~~.~~ And from a filtration perspective, kind of a different strategy ~~.~~ The legacy 3M business was always well respected as a very good technology business ~~.~~ But our commercial reach to this customer base and the relationships that we have has been allowing for a lot of trials of the technology ~~.~~ Effectively, customers want to see it. They're aware of it, but now they're interested because they ~~--~~ our customers know us asa really reliable supplier, and we'll help them enable their success. So thank you for the question, Luke. 

So let me wrap up the call ~~.~~ First, I'd like to thank everyone for participating today ~~.~~ We're pleased to deliver an outstanding quarter ~~.~~ We're on track to deliver a strong year as we continue to create value for our stakeholders and build an even brighter future for our company ~~.~~ We look forward to updating you as the year progresses ~~.~~ And as always, thank you for your support of Thermo Fisher Scientific ~~.~~ Have a good day, everyone. 

##### Operator 

This concludes today's call ~~.~~ Thank you for attending ~~.~~ You may now disconnect ~~.~~ 

Read more current TMO analysis and news 

View all earnings call transcripts 

http ~~s:~~ //seekingalpha ~~.~~ com/article/4924749- ~~t~~ hermo-f ~~i~~ sher- ~~sc~~ ientific ~~-~~ in ~~c-~~ tmo ~~-~~ q2 ~~-2~~ 026- ~~e~~ arnings- ~~ca~~ ll- ~~t~~ ranscript 

23/24 

10/10/26, 9:38 PM 

Thermo Fisher Scientific Inc. (TMO) Q2 2026 Earnings Call Transcript | Seeking Alpha 

COMMENTS 

Sort by Newest v 

: 

If you type a company or ETF ticker symbol in capital letters we will automatically link to the symbol page. You can remove the link by deleting the $ in the comment. 

https ~~:~~ //seekingalpha ~~.~~ com/article/4924749-t ~~h~~ ermo-fi ~~s~~ her-s ~~ci~~ entific- ~~i~~ nc ~~-t~~ mo- ~~q2~~ - ~~20~~ 26-e ~~ar~~ nings-ca ~~ll~~ -t ~~ra~~ nscript 

24/24 

